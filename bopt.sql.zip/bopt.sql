-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2020 at 06:50 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bopt`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_master`
--

CREATE TABLE `account_master` (
  `id` int(10) NOT NULL,
  `account_name` varchar(500) NOT NULL,
  `account_code` varchar(20) NOT NULL,
  `account_type` varchar(50) NOT NULL,
  `account_desc` varchar(500) NOT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_master`
--

INSERT INTO `account_master` (`id`, `account_name`, `account_code`, `account_type`, `account_desc`, `created_at`) VALUES
(1, 'Cash in Hand', '07/003', 'Assets', 'Cash in Hand', '0000-00-00 00:00:00'),
(2, 'OTHER CURRENT ASSETS', '08/006', 'Assets', 'OTHER CURRENT ASSETS', '0000-00-00 00:00:00'),
(3, 'STOCK-IN-HAND', '07/001', 'Assets', 'STOCK-IN-HAND', '0000-00-00 00:00:00'),
(4, 'Land', '04/001', 'Assets', 'Land', '0000-00-00 00:00:00'),
(5, 'Buildings', '04/003', 'Assets', 'Buildings', '0000-00-00 00:00:00'),
(6, 'Plant & Machinery', '04/008', 'Assets', 'Plant & Machinery', '0000-00-00 00:00:00'),
(7, 'Office Equipment', '04/010', 'Assets', 'Office Equipment', '0000-00-00 00:00:00'),
(8, 'Audio Visual Equipment', '04/011', 'Assets', 'Audio Visual Equipment', '0000-00-00 00:00:00'),
(9, 'Computers & Accessories', '04/012', 'Assets', 'Computers & Accessories', '0000-00-00 00:00:00'),
(10, 'Furniture,Fixtures&Fittings', '04/013', 'Assets', 'Furniture, Fixtures & Fittings', '0000-00-00 00:00:00'),
(11, 'Vehicles', '04/014', 'Assets', 'Vehicles', '0000-00-00 00:00:00'),
(12, 'Library Books & Scientific Journals', '04/015', 'Assets', 'Library Books & Scientific Journals', '0000-00-00 00:00:00'),
(13, 'Miscellaneous Equipments', '04/021', 'Assets', 'Miscellaneous Equipments', '0000-00-00 00:00:00'),
(14, 'Capital Work in Progress', '04/017', 'Assets', 'Capital Work in Progress', '0000-00-00 00:00:00'),
(15, 'ADVANCE TO STAFF', '08/001', 'Expenses', 'ADVANCE TO STAFF', '0000-00-00 00:00:00'),
(16, 'ADVANCE TO OTHERS', '08/002', 'Expenses', 'ADVANCE TO OTHERS', '0000-00-00 00:00:00'),
(17, 'ADVANCES FIXED ASSETS', '08/003', 'Expenses', 'ADVANCES FIXED ASSETS', '0000-00-00 00:00:00'),
(18, 'PREPAID EXPNESES', '08/004', 'Expenses', 'PREPAID EXPNESES', '0000-00-00 00:00:00'),
(19, 'Basic Pay', '15/001', 'Expenses', 'Basic Pay', '0000-00-00 00:00:00'),
(20, 'Allowance', '15/013', 'Expenses', 'Allowance', '0000-00-00 00:00:00'),
(21, 'LTC Leave Encashment', '15/007', 'Expenses', 'LTC Leave Encashment', '0000-00-00 00:00:00'),
(22, 'Others', '15/012', 'Expenses', 'Others', '0000-00-00 00:00:00'),
(23, 'C. BONUS', '15/002', 'Expenses', 'C. BONUS', '0000-00-00 00:00:00'),
(24, 'Contribution to Provident Fund', '15/003', 'Expenses', 'Contribution to Provident Fund', '0000-00-00 00:00:00'),
(25, 'Contribution to Other Funds', '15/004', 'Expenses', 'Contribution to Other Funds', '0000-00-00 00:00:00'),
(26, 'Reimbursement Grants', '15/005', 'Expenses', 'Reimbursement Grants', '0000-00-00 00:00:00'),
(27, 'Medical', '15/008', 'Expenses', 'Medical', '0000-00-00 00:00:00'),
(28, 'Tuition Fees/CEA', '15/009', 'Expenses', 'Tuition Fees/CEA', '0000-00-00 00:00:00'),
(29, 'Other Special Expenses', '15/011', 'Expenses', 'Other Special Expenses', '0000-00-00 00:00:00'),
(30, 'RETIREMENT AND TERMINAL BENEFITS', '15/006', 'Expenses', 'RETIREMENT AND TERMINAL BENEFITS', '0000-00-00 00:00:00'),
(31, 'FEES AND HONORARIUM', '15/010', 'Expenses', 'FEES AND HONORARIUM', '0000-00-00 00:00:00'),
(32, 'AUDIT FEE', '17/003', 'Expenses', 'AUDIT FEE', '0000-00-00 00:00:00'),
(33, 'Expenses', '17/014', 'Expenses', 'Expenses', '0000-00-00 00:00:00'),
(34, 'Water Expenses', '17/002', 'Expenses', 'Water Expenses', '0000-00-00 00:00:00'),
(35, 'Electricity&Generator', '17/001', 'Expenses', 'Electricity&Generator', '0000-00-00 00:00:00'),
(36, 'Vechiles', '18/001', 'Expenses', 'Vechiles', '0000-00-00 00:00:00'),
(37, 'Rates, Rent & Taxes and Expenses', '17/004', 'Expenses', 'Rates, Rent & Taxes and Expenses', '0000-00-00 00:00:00'),
(38, 'Security', '17/014', 'Expenses', 'Security', '0000-00-00 00:00:00'),
(39, 'COMMUNICATION', '17/006', 'Expenses', 'COMMUNICATION', '0000-00-00 00:00:00'),
(40, 'Postage & Telegrams', '17/005', 'Expenses', 'Postage & Telegrams', '0000-00-00 00:00:00'),
(41, 'TA/DA', '17/008', 'Expenses', 'TA/DA', '0000-00-00 00:00:00'),
(42, 'ADVERTISEMENTS & PUBLICITY', '17/012', 'Expenses', 'ADVERTISEMENTS & PUBLICITY', '0000-00-00 00:00:00'),
(43, 'DEPRECIATIOIN', '04/001', 'Expenses', 'DEPRECIATIOIN', '0000-00-00 00:00:00'),
(44, 'CLEANING MATERIAL', '19/008', 'Expenses', 'CLEANING MATERIAL', '0000-00-00 00:00:00'),
(45, 'MAINTENANCE OF BUILDINGS', '19/001', 'Expenses', 'MAINTENANCE OF BUILDINGS', '0000-00-00 00:00:00'),
(46, 'Estate', '19/011', 'Expenses', 'Estate', '0000-00-00 00:00:00'),
(47, 'Works', '19/012', 'Expenses', 'Works', '0000-00-00 00:00:00'),
(48, 'HORTICULTURE & GARDENING', '19/010', 'Expenses', 'HORTICULTURE & GARDENING', '0000-00-00 00:00:00'),
(49, 'MAINTENANCE', '19/004', 'Expenses', 'MAINTENANCE', '0000-00-00 00:00:00'),
(50, 'Maintenance of Plant & Machinery', '19/003', 'Expenses', 'Maintenance of Plant & Machinery', '0000-00-00 00:00:00'),
(51, 'Maintenance of Computers', '19/005', 'Expenses', 'Maintenance of Computers', '0000-00-00 00:00:00'),
(52, 'Taxi-Staff', '18/003', 'Expenses', 'Taxi-Staff', '0000-00-00 00:00:00'),
(53, 'Other Vehicles', '18/002', 'Expenses', 'Other Vehicles', '0000-00-00 00:00:00'),
(54, 'MAINTENANCE OF FURNITURES', '19/002', 'Expenses', 'MAINTENANCE OF FURNITURES', '0000-00-00 00:00:00'),
(55, 'MAINTENANCE OF BOOKS', '19/009', 'Expenses', 'MAINTENANCE OF BOOKS', '0000-00-00 00:00:00'),
(56, 'MAINTENANCE OF AUDIO VISUAL EQUIPMENTS', '19/007', 'Expenses', 'MAINTENANCE OF AUDIO VISUAL EQUIPMENTS', '0000-00-00 00:00:00'),
(57, 'PRIOR PERIOD ACADEMIC EXPENSES', '22/001', 'Expenses', 'PRIOR PERIOD ACADEMIC EXPENSES', '0000-00-00 00:00:00'),
(58, 'PROVISION', '03/002', 'Expenses', 'PROVISION', '0000-00-00 00:00:00'),
(59, 'Roads & Bridges', '04/004', 'Expenses', 'Roads & Bridges', '0000-00-00 00:00:00'),
(60, 'Tubewells & Water Supply', '04/005', 'Expenses', 'Tubewells & Water Supply', '0000-00-00 00:00:00'),
(61, 'Sewerage & Drainage', '04/006', 'Expenses', 'Sewerage & Drainage', '0000-00-00 00:00:00'),
(62, 'ElectricalInstallation&Equipments', '04/007', 'Expenses', 'Electrical Installation & Equipments', '0000-00-00 00:00:00'),
(63, 'INTEREST ON INVESTMENTS', '11/001', 'Income', 'INTEREST ON INVESTMENTS', '0000-00-00 00:00:00'),
(64, 'On savings Accounts with scheduled banks', '12/001', 'Income', 'On savings Accounts with scheduled banks', '0000-00-00 00:00:00'),
(65, 'Other Income', '13/001', 'Income', 'Other Income', '0000-00-00 00:00:00'),
(66, 'Recovery of Leave Salary & Pension Contribution', '13/005', 'Income', 'Recovery of Leave Salary & Pension Contribution', '0000-00-00 00:00:00'),
(67, 'Other Miscellaneous Income and ID card', '09/003', 'Income', 'Other Miscellaneous Income and ID card', '0000-00-00 00:00:00'),
(68, 'Others Incomes', '13/004', 'Income', 'Others Incomes', '0000-00-00 00:00:00'),
(69, 'Prior Period Indirect Income', '14/001', 'Income', 'Prior Period Indirect Income', '0000-00-00 00:00:00'),
(70, 'GRANT IN AID', '10/001', 'Income', 'GRANT IN AID', '0000-00-00 00:00:00'),
(71, 'PRIOR PERIOD INCOME', '14/003', 'Income', 'PRIOR PERIOD INCOME', '0000-00-00 00:00:00'),
(72, 'ACADEMIC RECEIPTS', '09/001', 'Income', 'ACADEMIC RECEIPTS', '0000-00-00 00:00:00'),
(73, 'PRIOR PERIOD EXPENSE', '22/004', 'Income', 'PRIOR PERIOD EXPENSE', '0000-00-00 00:00:00'),
(74, 'Liability for Administrative Charges', '03/005', 'Liabilities', 'Liability for Administrative Charges', '0000-00-00 00:00:00'),
(75, 'Liability for Tution fees/CEA and Arrear DA', '03/006', 'Liabilities', 'Liability for Tution fees/CEA and Arrear DA', '0000-00-00 00:00:00'),
(76, 'LIABILITY', '03/003', 'Liabilities', 'LIABILITY', '0000-00-00 00:00:00'),
(77, 'Intangible Assets', '04/018', 'Assets', 'Intangible Assets', '0000-00-00 00:00:00'),
(78, 'Small Value Assets', '04/016', 'Assets', 'Small Value Assets', '0000-00-00 00:00:00'),
(80, 'Grant & Subsidies', '4S/000', 'income', 'Receipt for stipend', '2020-01-09 09:31:41'),
(81, 'Interest Earned Ã‚Â For Stipend', '5S', 'income', 'interest on savings account', '2020-01-09 09:32:42'),
(82, 'Other Income For Stipend', '6S/408', 'income', 'Time barred cheques', '2020-01-09 09:34:53'),
(83, 'Administrative and general expenses  For Stipend', '7S/308', 'income', 'other administrative expenses', '2020-01-09 09:35:48'),
(84, 'Finance Cost for Stipend', '8S', 'income', 'Bank charges', '2020-01-09 09:36:37');

-- --------------------------------------------------------

--
-- Table structure for table `account_opening_balance`
--

CREATE TABLE `account_opening_balance` (
  `id` int(11) NOT NULL,
  `group_code` varchar(255) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `account_code` varchar(255) DEFAULT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `opening_balance` varchar(255) DEFAULT NULL,
  `month_yr` varchar(255) DEFAULT NULL,
  `financial_year` varchar(255) DEFAULT NULL,
  `cr_amount` varchar(255) DEFAULT NULL,
  `dr_amount` varchar(255) DEFAULT NULL,
  `closing_balance` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_opening_balance`
--

INSERT INTO `account_opening_balance` (`id`, `group_code`, `group_name`, `account_code`, `account_name`, `opening_balance`, `month_yr`, `financial_year`, `cr_amount`, `dr_amount`, `closing_balance`) VALUES
(1, '03/003', 'LIABILITY', '03/003/001', 'Liability for  leased line/ Internet charges', '0', '01/2020', '2019-2020', '0', '0', '0'),
(2, '03/003', 'LIABILITY', '03/003/002', 'Liability for Telephone Charges', '10000', '01/2020', '2019-2020', '0', '0', '10000'),
(3, '03/003', 'LIABILITY', '03/003/003', 'Liability for Books & Scientific Journals', '0', '01/2020', '2019-2020', '0', '0', '0'),
(4, '03/003', 'LIABILITY', '03/003/004', 'Liability for AMC of Software', '0', '01/2020', '2019-2020', '0', '0', '0'),
(5, '03/003', 'LIABILITY', '03/003/005', 'Liability for NATS Portals', '0', '01/2020', '2019-2020', '0', '0', '0'),
(6, '03/003', 'LIABILITY', '03/003/006', 'Liability for AMC of ACs', '0', '01/2020', '2019-2020', '0', '0', '0'),
(7, '03/003', 'LIABILITY', '03/003/007', 'Liability for AMC of Computer & Pheriperials', '0', '01/2020', '2019-2020', '0', '0', '0'),
(8, '03/003', 'LIABILITY', '03/003/008', 'Liability for AMC of Office Equipments', '25000', '01/2020', '2019-2020', '0', '0', '25000'),
(9, '03/003', 'LIABILITY', '03/003/009', 'Liability for Suppliers Bills', '20000', '01/2020', '2019-2020', '0', '0', '20000'),
(10, '03/003', 'LIABILITY', '03/003/010', 'Liability for others', '0', '01/2020', '2019-2020', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `arear_calc_master`
--

CREATE TABLE `arear_calc_master` (
  `id` int(11) NOT NULL,
  `head_id` int(11) DEFAULT NULL,
  `emp_code` varchar(50) DEFAULT NULL,
  `emp_name` varchar(200) DEFAULT NULL,
  `emp_desig` varchar(200) DEFAULT NULL,
  `emp_basic` varchar(50) DEFAULT NULL,
  `old_rate` varchar(50) DEFAULT NULL,
  `new_rate` varchar(50) DEFAULT NULL,
  `old_ta_rate` varchar(50) DEFAULT NULL,
  `new_ta_rate` varchar(50) DEFAULT NULL,
  `recv_amt` varchar(50) DEFAULT NULL,
  `enhanced_amt` varchar(50) DEFAULT NULL,
  `da_arrerar` varchar(50) DEFAULT NULL,
  `rcv_nps_amount` varchar(50) DEFAULT '0',
  `enhnc_nps_amount` varchar(50) DEFAULT '0',
  `nps_amount` varchar(50) DEFAULT '0',
  `rcv_ta_on_da_amount` varchar(50) DEFAULT NULL,
  `enhnc_ta_on_da_amount` varchar(50) DEFAULT NULL,
  `ta_on_da_arrear` varchar(50) NOT NULL DEFAULT 'NULL',
  `left_ta_on_da_amt` varchar(50) DEFAULT NULL,
  `recv_p_tax` varchar(50) DEFAULT NULL,
  `enhnc_p_tax` varchar(50) DEFAULT NULL,
  `p_tax_amt` varchar(50) DEFAULT NULL,
  `total_arrear` varchar(50) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arear_calc_master`
--

INSERT INTO `arear_calc_master` (`id`, `head_id`, `emp_code`, `emp_name`, `emp_desig`, `emp_basic`, `old_rate`, `new_rate`, `old_ta_rate`, `new_ta_rate`, `recv_amt`, `enhanced_amt`, `da_arrerar`, `rcv_nps_amount`, `enhnc_nps_amount`, `nps_amount`, `rcv_ta_on_da_amount`, `enhnc_ta_on_da_amount`, `ta_on_da_arrear`, `left_ta_on_da_amt`, `recv_p_tax`, `enhnc_p_tax`, `p_tax_amt`, `total_arrear`, `from_date`, `to_date`, `created_at`, `updated_at`) VALUES
(1, 2, '6678', 'ANINDYA  BHATTACHARYA', 'SKILL DEVELOPMENT OFFICER', '0', '12', '17', '12', '17', '30996', '43911', '12915', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '13455', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(2, 2, '1471', 'ASHIM  GHOSH', 'STENO GRADE I', '0', '12', '17', '12', '17', '11352', '16082', '4730', '10595', '11068', '473', '1296', '1836', '540', '0', '600', '600', '0', '4797', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(3, 2, '7883', 'ABHIJIT  CHAKRABORTY', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '9648', '13668', '4020', '9006', '9408', '402', '1296', '1836', '540', '0', '600', '600', '0', '4158', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(4, 2, '6928', 'ABHIJIT  DATTA', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '9648', '13668', '4020', '9006', '9408', '402', '1296', '1836', '540', '0', '600', '600', '0', '4158', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(6, 2, '6654', 'CHIRANJIB  CHAKRABORTY', 'PA TO DIRECTOR', '0', '12', '17', '12', '17', '16632', '23562', '6930', '15522', '16215', '693', '1296', '1836', '540', '0', '600', '600', '0', '6777', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(7, 2, '3020', 'DIPA  BISWAS', 'JUNIOR ACCOUNTANT', '0', '12', '17', '12', '17', '17640', '24990', '7350', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '7890', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(8, 2, '4078', 'DEEPAK', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '9180', '13005', '3825', '8568', '8952', '384', '1296', '1836', '540', '0', '450', '600', '150', '3831', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(9, 2, '1964', 'KAILASH NATH MISHRA', 'AAO', '0', '12', '17', '12', '17', '23400', '33150', '9750', '21840', '22815', '975', '2592', '3672', '1080', '0', '600', '600', '0', '9855', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(10, 2, '1530', 'KAMINEDI CHANDRA MOULI', 'ASSISTANT DIRECTOR', '0', '12', '17', '12', '17', '24120', '34170', '10050', '22512', '23517', '1005', '2592', '3672', '1080', '0', '600', '600', '0', '10125', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(11, 2, '1132', 'KALYAN  SARDAR', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '9648', '13668', '4020', '9006', '9408', '402', '1296', '1836', '540', '0', '600', '600', '0', '4158', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(12, 2, '1521', 'NAMRATA  KUMARI', 'STENO GRADE II', '0', '12', '17', '12', '17', '11304', '16014', '4710', '10551', '11022', '471', '1296', '1836', '540', '0', '600', '600', '0', '4779', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(13, 2, '2301', 'KAMAL KUMAR BAICHI', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '13896', '19686', '5790', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6330', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(14, 2, '4154', 'PUJA  SONI', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '8290', '11744', '3454', '7737', '8082', '345', '950', '1346', '396', '0', '400', '400', '0', '3505', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(15, 2, '7216', 'PARTHA  BASAK', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '13104', '18564', '5460', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6000', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(16, 2, '9456', 'PALAN CHANDRA MAL', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '11196', '15861', '4665', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '5205', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(19, 2, '9556', 'SHASHIKANT  SAHU', 'GENERAL ASSISTANT', '0', '12', '17', '12', '17', '10512', '14892', '4380', '9810', '10248', '438', '1296', '1836', '540', '0', '600', '600', '0', '4482', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(20, 2, '6840', 'RISHIKESH  KUMAR', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '9180', '13005', '3825', '8568', '8952', '384', '1296', '1836', '540', '0', '450', '600', '150', '3831', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(21, 2, '4238', 'AMIR  KHUSRU', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '8820', '12495', '3675', '8232', '8601', '369', '1296', '1836', '540', '0', '450', '450', '0', '3846', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(22, 2, '4202', 'CHANDRIKA  PASWAN', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '13104', '18564', '5460', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6000', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(23, 2, '3377', 'RAKESH KUMAR SHAW', 'OFFICE SUPERINTENDENT', '0', '12', '17', '12', '17', '14364', '20349', '5985', '13407', '14004', '597', '1296', '1836', '540', '0', '600', '600', '0', '5928', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(24, 2, '3716', 'RITESH KUMAR SINGH', 'JUNIOR TRANSLATOR', '0', '12', '17', '12', '17', '13392', '18972', '5580', '12499', '13057', '558', '1296', '1836', '540', '0', '600', '600', '0', '5562', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(26, 2, '8237', 'SAMIR KUMAR DAS', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '13104', '18564', '5460', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6000', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(27, 2, '1384', 'SOMJIT  BANERJEE', 'ANALYST', '0', '12', '17', '12', '17', '17136', '24276', '7140', '15993', '16707', '714', '1296', '1836', '540', '0', '600', '600', '0', '6966', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(28, 2, '5024', 'SUBRATA  MUKHERJEE', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '8820', '12495', '3675', '8232', '8601', '369', '1296', '1836', '540', '0', '450', '450', '0', '3846', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(29, 2, '4702', 'SUCHAND  DUTTA', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '13104', '18564', '5460', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6000', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(30, 2, '7657', 'SUSHMITA  GHOSH', 'ASSISTANT DIRECTOR', '0', '12', '17', '12', '17', '23400', '33150', '9750', '21840', '22815', '975', '2592', '3672', '1080', '0', '600', '600', '0', '9855', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(31, 2, '5752', 'SWAPNA  DUTTA', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '11196', '15861', '4665', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '5205', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(32, 2, '9792', 'TRIDEB  KAYAL', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '7164', '10149', '2985', '6687', '6984', '297', '972', '1377', '405', '0', '450', '450', '0', '3093', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(33, 2, '4452', 'SYED MOHAMMED EJAZ AHMED', 'DIRECTOR', '0', '12', '17', '12', '17', '45648', '64668', '19020', '0', '0', '0', '2592', '3672', '1080', '0', '600', '600', '0', '20100', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(34, 2, '3181', 'AMIT KUMAR DEY', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '10044', '14229', '4185', '9375', '9792', '417', '1296', '1836', '540', '0', '600', '600', '0', '4308', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(35, 2, '4042', 'CHATLA RAJA RAO', 'DEPUTY DIRECTOR', '0', '12', '17', '12', '17', '31824', '45084', '13260', '29703', '31029', '1326', '2592', '3672', '1080', '0', '600', '600', '0', '13014', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(36, 2, '1466', 'SATYA BRATA MANNA', 'UPPER DIVISION CLERK', '0', '12', '17', '12', '17', '13104', '18564', '5460', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6000', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(37, 2, '9574', 'SAJAL  OJHA', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '8820', '12495', '3675', '8232', '8601', '369', '1296', '1836', '540', '0', '450', '450', '0', '3846', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(38, 2, '4921', 'SWAPAN KUMAR DIKSHIT', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '13104', '18564', '5460', '0', '0', '0', '1296', '1836', '540', '0', '600', '600', '0', '6000', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(39, 2, '5408', 'ARUNAVA  CHAKRABORTY', 'ASSISTANT DIRECTOR', '0', '12', '17', '12', '17', '31824', '45084', '13260', '29703', '31029', '1326', '2592', '3672', '1080', '0', '600', '600', '0', '13014', '2019-07-01', '2019-09-30', '2019-09-30', NULL),
(40, 2, '3986', 'ARKA  NASKAR', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '7164', '10149', '2985', '6687', '6984', '297', '486', '690', '204', '0', '450', '450', '0', '2892', '2019-07-01', '2019-09-30', '2019-10-31', NULL),
(41, 2, '7166', 'PANCHANAN  DAS', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '7740', '10965', '3225', '7224', '7548', '324', '486', '690', '204', '0', '450', '450', '0', '3105', '2019-07-01', '2019-09-30', '2019-10-31', NULL),
(42, 2, '9232', 'RAHUL  RANJAN', 'LOWER DIVISION CLERK', '0', '12', '17', '12', '17', '7164', '10149', '2985', '6687', '6984', '297', '486', '690', '204', '0', '450', '450', '0', '2892', '2019-07-01', '2019-09-30', '2019-10-31', NULL),
(43, 2, '1651', 'SAKET  KRISHNAN', 'MULTI TASKING STAFF', '0', '12', '17', '12', '17', '6480', '9180', '2700', '6048', '6318', '270', '486', '690', '204', '0', '450', '450', '0', '2634', '2019-07-01', '2019-09-30', '2019-10-31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `asset_masters`
--

CREATE TABLE `asset_masters` (
  `id` int(11) NOT NULL,
  `head_name` varchar(200) DEFAULT NULL,
  `account_code` varchar(50) DEFAULT NULL,
  `asset_type` varchar(180) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `asset_masters`
--

INSERT INTO `asset_masters` (`id`, `head_name`, `account_code`, `asset_type`, `created_at`, `updated_at`) VALUES
(1, 'Land', '04/001', 'tangible', '2019-12-19 17:52:26', NULL),
(2, 'Site Development', '0', 'tangible', '2019-12-19 19:06:19', NULL),
(3, 'Buildings', '04/003', 'tangible', '2019-12-19 19:06:19', NULL),
(4, 'Roads And Bridges', '04/004', 'tangible', '2019-12-19 19:06:19', NULL),
(5, 'Tubewells And Water Supply', '04/005', 'tangible', '2019-12-19 19:06:19', NULL),
(6, 'Sewerage And Drainage', '04/006', 'tangible', '2019-12-19 19:06:19', NULL),
(7, 'Electrical installation and equipment', '	04/007', 'tangible', '2019-12-19 19:06:19', NULL),
(8, 'Plant & Machinery', '04/008', 'tangible', '2019-12-19 19:06:19', NULL),
(9, 'Scientific And Laboratory', '0', 'tangible', '2019-12-19 19:06:19', NULL),
(10, 'Office Equipment', '04/010', 'tangible', '2019-12-19 19:06:19', NULL),
(11, 'Audio Visual Equipment', '04/011', 'tangible', '2019-12-19 19:06:19', NULL),
(12, 'Computer And Peripherals', '04/012', 'tangible', '2019-12-19 19:06:19', NULL),
(13, 'Furniture, Fixture and Assets', '04/013', 'tangible', '2019-12-19 19:06:19', NULL),
(14, 'Vehicles', '04/014', 'tangible', '2019-12-19 19:06:19', NULL),
(15, 'Lib. Books & Scientific Journals', '04/015', 'tangible', '2019-12-19 19:06:19', NULL),
(16, 'Small Value Assets', '04/016', 'tangible', '2019-12-19 19:06:19', NULL),
(17, 'Capital Work in Progress', '04/017', 'tangible', '2019-12-19 19:06:19', NULL),
(18, 'Computer Software', '04/018', 'intangible', '2019-12-19 19:06:19', NULL),
(19, 'E-journals', '0', 'intangible', '2019-12-19 19:06:19', NULL),
(20, 'Patents', '0', 'intangible', '2019-12-19 19:06:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `balance_posting`
--

CREATE TABLE `balance_posting` (
  `id` int(11) NOT NULL,
  `group_code` varchar(255) DEFAULT NULL,
  `transaction_code` varchar(255) DEFAULT NULL,
  `dr_amount` varchar(255) DEFAULT NULL,
  `cr_amount` varchar(255) NOT NULL,
  `opening_balance` varchar(255) DEFAULT NULL,
  `closing_balance` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `balance_posting`
--

INSERT INTO `balance_posting` (`id`, `group_code`, `transaction_code`, `dr_amount`, `cr_amount`, `opening_balance`, `closing_balance`, `month`, `created_date`) VALUES
(1, '03/003', '03/003/010', '21600', '21600', '90400', '133600', '02/2020', '2020-02-10'),
(2, '07/003', '07/003/003', '0', '15500', '66800', '82300', '02/2020', '2020-02-10'),
(3, '17/003', '17/003/005', '21600', '0', '45200', '66800', '02/2020', '2020-02-10'),
(4, '03/003', '03/003/009', '15500', '15500', '0', '31000', '02/2020', '2020-02-10'),
(5, '19/001', '19/001/004', '15500', '0', '0', '15500', '02/2020', '2020-02-10');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `swift_code` varchar(255) DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `bank_status` varchar(10) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id`, `bank_name`, `branch_name`, `ifsc_code`, `swift_code`, `updated_at`, `created_at`, `bank_status`) VALUES
(7, '14', 'Sonagiri Bhopal', 'SBIN0030442', '462005019', '2019-07-05 02:32:14.000000', '2019-07-05 02:32:14.000000', 'active'),
(8, '14', 'Salt Lake', 'SBIN0001612', '700002145', '2019-07-05 03:26:53.000000', '2019-07-05 03:26:53.000000', 'active'),
(9, '14', 'S K Medical Hospital Campus Muzaffarpur', 'SBIN0010082', '842002015', '2019-07-05 03:29:00.000000', '2019-07-05 03:29:00.000000', ''),
(10, '14', 'Teghoria Raghunathpur, Kolkata', 'SBIN0008735', '700002183', '2019-07-05 03:31:05.000000', '2019-07-05 03:31:05.000000', 'active'),
(11, '14', 'Bijoyganj Bazar', 'SBIN0010541', '700002339', '2019-07-05 03:32:05.000000', '2019-07-05 03:32:05.000000', 'active'),
(12, '14', 'Purnea', 'SBIN0000159', '854002102', '2019-07-05 03:33:17.000000', '2019-07-05 03:33:17.000000', 'active'),
(13, '14', 'Sector 19, Faridabad', 'SBIN0051172', '110007076', '2019-07-05 04:01:14.000000', '2019-07-05 04:01:14.000000', ''),
(14, '14', 'Halisahar Station Road', 'SBIN0012463', '700002357', '2019-07-05 03:36:36.000000', '2019-07-05 03:36:36.000000', 'active'),
(15, '9', 'Salt Lake City', 'IOBA0000893', '700020029', '2019-07-05 03:37:27.000000', '2019-07-05 03:37:27.000000', 'active'),
(16, '9', 'Garia', 'IOBA0001426', '700020034', '2019-07-05 03:38:25.000000', '2019-07-05 03:38:25.000000', 'active'),
(17, '17', 'Sreebhumi', 'UTBI0SRBA17', '700027137', '2019-07-05 03:39:33.000000', '2019-07-05 03:39:33.000000', 'active'),
(18, '17', 'Birati', 'UTBI0BRTF60', '700027250', '2019-07-05 03:40:16.000000', '2019-07-05 03:40:16.000000', 'active'),
(19, '18', 'Kalindi West', 'UTBI0KLWA43', '700027201', '2019-12-09 04:03:00.000000', '2019-12-09 04:03:00.000000', ''),
(20, '15', 'Kolkata Dum Dum Airport', 'SYNB0009775', '700025040', '2019-07-05 03:42:16.000000', '2019-07-05 03:42:16.000000', 'active'),
(21, '1', 'Paikpara Branch', 'BARB0PAIKPA', '700012025', '2019-07-05 03:43:03.000000', '2019-07-05 03:43:03.000000', 'active'),
(22, '13', 'Jamhaita', 'PUNB0168700', '823024518', '2019-07-05 03:44:08.000000', '2019-07-05 03:44:08.000000', 'active'),
(23, '14', 'Bagh Bazar, Kolkata', 'SBIN0001652', '700002007', '2019-08-20 06:52:18.000000', '2019-08-20 06:52:18.000000', '');

-- --------------------------------------------------------

--
-- Table structure for table `bank_balance`
--

CREATE TABLE `bank_balance` (
  `id` int(11) NOT NULL,
  `voucher_no` varchar(30) DEFAULT NULL,
  `bank_id` varchar(100) DEFAULT NULL,
  `bank_branch_id` int(11) DEFAULT NULL,
  `opening_balance` varchar(30) DEFAULT NULL,
  `income` varchar(30) DEFAULT NULL,
  `expense` varchar(30) DEFAULT NULL,
  `balance_amt` varchar(30) DEFAULT NULL,
  `bank_clearance_date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_balance`
--

INSERT INTO `bank_balance` (`id`, `voucher_no`, `bank_id`, `bank_branch_id`, `opening_balance`, `income`, `expense`, `balance_amt`, `bank_clearance_date`, `created_at`) VALUES
(1, '1-2020-2021', 'State Bank of India', 2, '5000000', '0', '23600', '4976400', NULL, '2020-02-10 10:43:27'),
(2, '3-2020-2021', 'State Bank of India', 2, '4976400', '0', '21600', '4954800', NULL, '2020-02-10 10:56:51'),
(3, '5-2020-2021', 'State Bank of India', 2, '4954800', '0', '21600', '4933200', NULL, '2020-02-10 11:22:02'),
(4, '7-2020-2021', 'State Bank of India', 2, '4933200', '0', '15500', '4917700', NULL, '2020-02-10 12:33:43'),
(5, '9-2020-2021', 'State Bank of India', 2, '4917700', '0', '17280', '4900420', NULL, '2020-02-12 07:45:31'),
(6, '11-2020-2021', 'State Bank of India', 2, '4900420', '0', '1220', '4899200', NULL, '2020-02-12 09:26:29'),
(7, '13-2020-2021', 'State Bank of India', 2, '4899200', '0', '1800', '4897400', NULL, '2020-02-12 10:12:01'),
(8, '15-2020-2021', 'State Bank of India', 2, '4897400', '0', '955221', '3942179', NULL, '2020-02-13 07:51:20');

-- --------------------------------------------------------

--
-- Table structure for table `bank_masters`
--

CREATE TABLE `bank_masters` (
  `id` int(11) NOT NULL,
  `master_bank_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank_masters`
--

INSERT INTO `bank_masters` (`id`, `master_bank_name`) VALUES
(1, 'Bank of Baroda'),
(2, 'Bank of India'),
(3, 'Bank of Maharashtra'),
(4, 'Canara Bank'),
(5, 'Central Bank of India'),
(6, 'Corporation Bank'),
(7, 'Dena Bank'),
(8, 'Indian Bank'),
(9, 'Indian Overseas Bank'),
(10, 'IDBI Bank'),
(11, 'Oriental Bank of Commerce'),
(12, 'Punjab & Sindh Bank'),
(13, 'Punjab National Bank'),
(14, 'State Bank of India'),
(15, 'Syndicate Bank'),
(16, 'UCO Bank'),
(17, 'Union Bank of India'),
(18, 'United Bank of India'),
(19, 'Vijaya Bank'),
(20, 'Axis Bank'),
(21, 'Bandhan Bank'),
(22, 'Catholic Syrian Bank'),
(23, 'City Union Bank'),
(24, 'DCB Bank'),
(25, 'Dhanlaxmi Bank'),
(26, 'Federal Bank'),
(27, 'HDFC Bank'),
(28, 'ICICI Bank'),
(29, 'IDFC Bank'),
(30, 'IndusInd Bank'),
(31, 'Jammu and Kashmir Bank'),
(32, 'Karnataka Bank'),
(33, 'Karur Vysya Bank'),
(34, 'Kotak Mahindra Bank'),
(35, 'Lakshmi Vilas Bank'),
(36, 'Nainital Bank'),
(37, 'RBL Bank'),
(38, 'South Indian Bank'),
(39, 'Tamilnad Mercantile Bank'),
(40, 'YES Bank');

-- --------------------------------------------------------

--
-- Table structure for table `bank_stipend_balance`
--

CREATE TABLE `bank_stipend_balance` (
  `id` int(11) NOT NULL,
  `voucher_no` varchar(255) NOT NULL,
  `bank_id` varchar(255) NOT NULL,
  `bank_branch_id` int(11) NOT NULL,
  `opening_balance` varchar(255) NOT NULL,
  `income` varchar(255) NOT NULL,
  `expense` varchar(255) NOT NULL,
  `balance_amt` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank_stipend_balance`
--

INSERT INTO `bank_stipend_balance` (`id`, `voucher_no`, `bank_id`, `bank_branch_id`, `opening_balance`, `income`, `expense`, `balance_amt`, `created_at`) VALUES
(1, '16-01-2020-38S', 'State Bank of India', 1, '0', '0', '0', '0', '2020-01-16 09:57:39'),
(2, '16-01-2020-39S', 'State Bank of India', 1, '0', '10000000', '0', '10000000', '2020-01-16 10:00:44'),
(3, '12345689', 'State Bank of India', 1, '10000000', '0', '226422206', '-216422206', '2020-01-16 10:04:22');

-- --------------------------------------------------------

--
-- Table structure for table `bs_schedule_master`
--

CREATE TABLE `bs_schedule_master` (
  `id` int(11) NOT NULL,
  `particulars` varchar(180) DEFAULT NULL,
  `schedule` varchar(11) DEFAULT NULL,
  `particular_type` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bs_schedule_master`
--

INSERT INTO `bs_schedule_master` (`id`, `particulars`, `schedule`, `particular_type`, `created_at`) VALUES
(1, 'Corpus/Capital Fund', '01', 'income', '2019-12-05 11:32:56'),
(2, 'Designated/Earmarked/Endowment Funds', '02', 'income', '2019-12-05 11:33:40'),
(3, 'Current Liabilities & Provisions', '03', 'income', '2019-12-05 11:34:13'),
(4, 'Fixed Assets', '04', 'expense', '2019-12-05 11:34:49'),
(5, 'Investments from Earmarked/Endowment Funds', '05', 'expense', '2019-12-05 11:35:14'),
(6, 'Investments/Others', '06', 'expense', '2019-12-05 11:35:46'),
(7, 'Current Assets', '07', 'expense', '2019-12-05 11:36:35'),
(8, 'Loans, Advances & Deposits', '08', 'expense', '2019-12-05 11:37:06');

-- --------------------------------------------------------

--
-- Table structure for table `cash_balance`
--

CREATE TABLE `cash_balance` (
  `id` int(11) NOT NULL,
  `voucher_no` varchar(50) DEFAULT NULL,
  `opening_balance` varchar(50) DEFAULT NULL,
  `income` varchar(50) DEFAULT NULL,
  `expense` varchar(50) DEFAULT NULL,
  `balance_amt` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cash_balance`
--

INSERT INTO `cash_balance` (`id`, `voucher_no`, `opening_balance`, `income`, `expense`, `balance_amt`, `created_at`, `updated_at`) VALUES
(1, '12-2019-2020', '100000', '2000', '0', '49960897', '2019-12-13 08:53:32', NULL),
(2, '17-12-2019-23R', '49960897', '500', '0', '49961397', '2019-12-17 06:07:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cast`
--

CREATE TABLE `cast` (
  `id` int(11) NOT NULL,
  `cast_id` varchar(55) DEFAULT NULL,
  `cast_name` varchar(255) NOT NULL,
  `cast_status` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cast`
--

INSERT INTO `cast` (`id`, `cast_id`, `cast_name`, `cast_status`) VALUES
(1, NULL, 'GENERAL', 'active'),
(2, NULL, 'OTHER BACKWARD CLASS', 'inactive'),
(4, NULL, 'SCHEDULE TRIBE', 'active'),
(5, NULL, 'ECONOMICALLY BACKWARD CLASS', 'inactive'),
(6, NULL, 'SCHEDULE CASTE', 'inactive'),
(7, NULL, 'OTHER BACKWARD CLASS', 'active'),
(8, NULL, 'SCHEDULE CASTE', 'active'),
(9, NULL, 'ECONOMICALLY BACKWARD CLASS', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(200) DEFAULT NULL,
  `cat_code` varchar(12) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`, `cat_code`, `created_at`, `updated_at`) VALUES
(1, 'Office Equipment', 'C001', '0000-00-00 00:00:00', '2020-02-13 01:10:55'),
(2, 'Furniture, Fixtures & Fittings', 'C002', '0000-00-00 00:00:00', '2020-02-13 01:11:03'),
(3, 'Computer and Accessories', 'C003', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Intangible Assets', 'C004', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Plant & Machinery', 'C005', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Vehicles', 'C006', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Library Books', 'C007', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Audio Visual Equipment', 'C008', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Electrical Installation & Equipments', 'C009', '0000-00-00 00:00:00', '2020-02-13 01:10:31'),
(10, 'Tube wells & Water Supply', 'C010', '0000-00-00 00:00:00', '2020-02-13 01:11:51'),
(11, 'Sewerage & Drainage', 'C011', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `coa_master`
--

CREATE TABLE `coa_master` (
  `id` int(10) NOT NULL,
  `coa_code` varchar(10) DEFAULT NULL,
  `head_name` varchar(150) NOT NULL,
  `account_tool` varchar(10) NOT NULL,
  `account_type` varchar(20) DEFAULT NULL,
  `account_name` varchar(500) NOT NULL,
  `account_reflect_on` varchar(30) DEFAULT NULL,
  `coa_remarks` varchar(200) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coa_master`
--

INSERT INTO `coa_master` (`id`, `coa_code`, `head_name`, `account_tool`, `account_type`, `account_name`, `account_reflect_on`, `coa_remarks`, `created_at`) VALUES
(1, '07/003/001', 'In current Accounts', 'debit', 'Assets', 'Cash In Hand', 'PL', 'In current Accounts', '0000-00-00 00:00:00'),
(2, '07/003/002', 'In Term Deposit Accounts', 'debit', 'Assets', 'Cash In Hand', 'PL', 'In Term Deposit Accounts', '0000-00-00 00:00:00'),
(3, '07/003/003', 'In Savings Accounts', 'debit', 'Assets', 'Cash In Hand', 'PL', 'In Savings Accounts', '0000-00-00 00:00:00'),
(4, '08/001/001', ' LTC Advances', 'debit', 'Assets', 'ADVANCE TO STAFF', 'PL', ' LTC Advances', '0000-00-00 00:00:00'),
(5, '08/001/002', ' Festival Advance to Staff', 'debit', 'Assets', 'ADVANCE TO STAFF', 'PL', ' Festival Advance to Staff', '0000-00-00 00:00:00'),
(6, '08/001/003', 'Temporary duty Advance', 'debit', 'Assets', 'ADVANCE TO STAFF', 'PL', 'Temporary duty Advance', '0000-00-00 00:00:00'),
(7, '08/001/004', 'Medical Advance', 'debit', 'Assets', 'ADVANCE TO STAFF', 'PL', 'Medical Advance', '0000-00-00 00:00:00'),
(8, '08/001/005', 'Others(Non Interest  Bearing)', 'debit', 'Assets', 'ADVANCE TO STAFF', 'PL', 'Others(Non Interest  Bearing)', '0000-00-00 00:00:00'),
(9, '08/002/001', 'Computer Advance', 'debit', 'Assets', 'ADVANCE TO OTHERS', 'PL', 'Computer Advance', '0000-00-00 00:00:00'),
(10, '08/002/002', 'House Building Advance', 'debit', 'Assets', 'ADVANCE TO OTHERS', 'PL', 'House Building Advance', '0000-00-00 00:00:00'),
(11, '08/002/003', 'Others(Interest  Bearing)', 'debit', 'Assets', 'ADVANCE TO OTHERS', 'PL', 'Others(Interest  Bearing)', '0000-00-00 00:00:00'),
(12, '08/003/001', ' Advance Capital A/c - Civil Works', 'debit', 'Assets', 'ADVANCES FIXED ASSETS', 'PL', ' Advance Capital A/c - Civil Works', '0000-00-00 00:00:00'),
(13, '08/003/002', 'Advance  Capital A/c- Equipment ', 'debit', 'Assets', 'ADVANCES FIXED ASSETS', 'PL', 'Advance  Capital A/c- Equipment ', '0000-00-00 00:00:00'),
(14, '08/003/003', 'Others', 'debit', 'Assets', 'ADVANCES FIXED ASSETS', 'PL', 'Others', '0000-00-00 00:00:00'),
(15, '08/006/001', ' HBA -Interest Accrued(HIA)', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', ' HBA -Interest Accrued(HIA)', '0000-00-00 00:00:00'),
(16, '08/006/002', 'Other Interests Accrued', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Other Interests Accrued', '0000-00-00 00:00:00'),
(17, '08/006/003', ' Others(  Other than Interest)', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', ' Others(  Other than Interest)', '0000-00-00 00:00:00'),
(18, '08/006/004', 'Bank Charges Receivable From SBI ', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Bank Charges Receivable From SBI ', '0000-00-00 00:00:00'),
(19, '08/006/005', 'Income Tax Receivable', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Income Tax Receivable', '0000-00-00 00:00:00'),
(20, '08/006/006', 'Post Master for Franking Machine', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Post Master for Franking Machine', '0000-00-00 00:00:00'),
(21, '08/006/007', 'Receivable From Deposit A/c', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Receivable From Deposit A/c', '0000-00-00 00:00:00'),
(22, '08/006/008', 'Receivable From NPS Tier-l', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Receivable From NPS Tier-l', '0000-00-00 00:00:00'),
(23, '08/006/009', 'Others', 'debit', 'Assets', 'OTHER CURRENT ASSETS', 'PL', 'Others', '0000-00-00 00:00:00'),
(24, '07/001/005', 'Building Material (Stock)', 'debit', 'Assets', 'STOCK-IN-HAND', 'PL', 'Building Material (Stock)', '0000-00-00 00:00:00'),
(25, '07/001/001', 'Cleaning Material (Stock)', 'debit', 'Assets', 'STOCK-IN-HAND', 'PL', 'Cleaning Material (Stock)', '0000-00-00 00:00:00'),
(26, '07/001/006', 'Electrical Material (Stock)', 'debit', 'Assets', 'STOCK-IN-HAND', 'PL', 'Electrical Material (Stock)', '0000-00-00 00:00:00'),
(27, '07/001/007', 'Stationery (Stock)', 'debit', 'Assets', 'STOCK-IN-HAND', 'PL', 'Stationery (Stock)', '0000-00-00 00:00:00'),
(28, '07/001/009', 'Others', 'debit', 'Assets', 'STOCK-IN-HAND', 'PL', 'Others', '0000-00-00 00:00:00'),
(29, '08/004/002', 'Prepaid AMC', 'debit', 'Assets', 'PREPAID EXPNESES', 'PL', 'Prepaid AMC', '0000-00-00 00:00:00'),
(30, '08/004/001', 'Prepaid Insurance  of Vehicles', 'debit', 'Assets', 'PREPAID EXPNESES', 'PL', 'Prepaid Insurance  of Vehicles', '0000-00-00 00:00:00'),
(31, '08/004/003', 'Others', 'debit', 'Assets', 'PREPAID EXPNESES', 'PL', 'Others', '0000-00-00 00:00:00'),
(32, '11/001/001', 'Interest on Investment - Banks', 'credit', 'Income', 'INTEREST ON INVESTMENTS', 'PL', 'Interest on Investment - Banks', '0000-00-00 00:00:00'),
(33, '11/001/002', 'Interest on Investment - Govt. Securities', 'credit', 'Income', 'INTEREST ON INVESTMENTS', 'PL', 'Interest on Investment - Govt. Securities', '0000-00-00 00:00:00'),
(34, '11/001/003', ' Interest on Securities - Bonds & Debentures', 'credit', 'Income', 'INTEREST ON INVESTMENTS', 'PL', ' Interest on Securities - Bonds & Debentures', '0000-00-00 00:00:00'),
(35, '12/001/001', 'Interest on Savings- Banks', 'credit', 'Income', 'INTEREST ON SAVING ACCOUNTS', 'PL', 'Interest on Savings- Banks', '0000-00-00 00:00:00'),
(36, '13/001/001', 'Rent  from Guest House/Room', 'credit', 'Income', 'Other Income', 'PL', 'Rent  from Guest House/Room', '0000-00-00 00:00:00'),
(37, '13/001/002', 'Rent from  Staff Quarters', 'credit', 'Income', 'Other Income', 'PL', 'Rent from  Staff Quarters', '0000-00-00 00:00:00'),
(38, '13/001/003', ' Staff Car Charges', 'credit', 'Income', 'Other Income', 'PL', ' Staff Car Charges', '0000-00-00 00:00:00'),
(39, '13/001/005', 'Water/Electricity etc. Recovered', 'credit', 'Income', 'Other Income', 'PL', 'Water/Electricity etc. Recovered', '0000-00-00 00:00:00'),
(40, '13/004/008', 'Gratuity Contribution Receipts', 'credit', 'Income', 'Recovery of Leave Salary & Pen', 'PL', 'Gratuity Contribution Receipts', '0000-00-00 00:00:00'),
(41, '13/004/009', '  Leave Salary Contribution Receipts', 'credit', 'Income', 'Recovery of Leave Salary & Pen', 'PL', '  Leave Salary Contribution Receipts', '0000-00-00 00:00:00'),
(42, '13/004/010', 'Leave Salary & Pension Contribution Receipts', 'credit', 'Income', 'Recovery of Leave Salary & Pen', 'PL', 'Leave Salary & Pension Contribution Receipts', '0000-00-00 00:00:00'),
(43, '13/004/011', 'Pension Contribution Receipts', 'credit', 'Income', 'Recovery of Leave Salary & Pen', 'PL', 'Pension Contribution Receipts', '0000-00-00 00:00:00'),
(44, '09/003/001', 'ID Card Charges', 'credit', 'Income', ' Other Miscellaneous Income an', 'PL', 'ID Card Charges', '0000-00-00 00:00:00'),
(45, '09/003/002', ' Loss of Staff I Card', 'credit', 'Income', ' Other Miscellaneous Income an', 'PL', ' Loss of Staff I Card', '0000-00-00 00:00:00'),
(46, '09/003/003', ' Other Miscellaneous Income', 'credit', 'Income', ' Other Miscellaneous Income an', 'PL', ' Other Miscellaneous Income', '0000-00-00 00:00:00'),
(47, '13/004/004', '  Recruitment Application Fee', 'credit', 'Income', ' Others Incomes', 'PL', '  Recruitment Application Fee', '0000-00-00 00:00:00'),
(48, '13/004/012', ' Refund of Pay & Allowances', 'credit', 'Income', ' Others Incomes', 'PL', ' Refund of Pay & Allowances', '0000-00-00 00:00:00'),
(49, '13/004/002', ' RTI Charges', 'credit', 'Income', ' Others Incomes', 'PL', ' RTI Charges', '0000-00-00 00:00:00'),
(50, '13/004/005', 'Sale of Tender Forms', 'credit', 'Income', ' Others Incomes', 'PL', 'Sale of Tender Forms', '0000-00-00 00:00:00'),
(51, '13/004/005', 'Sale of Waste Paper/ Unserviceable Stores', 'credit', 'Income', ' Others Incomes', 'PL', 'Sale of Waste Paper/ Unserviceable Stores', '0000-00-00 00:00:00'),
(52, '13/004/006', 'Surplus on Sale/Disposal of Assets', 'credit', 'Income', ' Others Incomes', 'PL', 'Surplus on Sale/Disposal of Assets', '0000-00-00 00:00:00'),
(53, '13/004/013', ' Others', 'credit', 'Income', ' Others Incomes', 'PL', ' Others', '0000-00-00 00:00:00'),
(54, '15/001/001', 'Prior Period Income', 'credit', 'Income', 'Prior Period Indirect Income', 'PL', 'Prior Period Income', '0000-00-00 00:00:00'),
(55, '10/001/001', ' Govt. of  India', 'credit', 'Income', 'GRANT IN AID', 'PL', ' Govt. of  India', '0000-00-00 00:00:00'),
(56, '10/001/002', ' Others', 'credit', 'Income', 'GRANT IN AID', 'PL', ' Others', '0000-00-00 00:00:00'),
(57, '09/001/007', 'Registration Fee for Workshops', 'credit', 'Income', ' ACADEMIC RECEIPTS', 'PL', 'Registration Fee for Workshops', '0000-00-00 00:00:00'),
(58, '14/004/001', 'Prior Period Income', 'credit', 'Income', 'PRIOR PERIOD INCOME', 'PL', 'Prior Period Income', '0000-00-00 00:00:00'),
(59, '03/005/001', 'Liability for Administrative Charges', 'credit', 'Liability', ' Liability for Administrative ', 'PL', 'Liability for Administrative Charges', '0000-00-00 00:00:00'),
(60, '03/006/001', ' Liability for Tution fees/CEA', 'credit', 'Liability', 'Liability for Tution fees/CEA ', 'PL', ' Liability for Tution fees/CEA', '0000-00-00 00:00:00'),
(61, '03/006/002', 'Liability for Arrear DA', 'credit', 'LIABILITY', 'Liability for Tution fees/CEA ', 'PL', 'Liability for Arrear DA', '0000-00-00 00:00:00'),
(62, '03/003/001', 'Liability for  leased line/ Internet charges', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for  leased line/ Internet charges', '0000-00-00 00:00:00'),
(63, '03/003/002', 'Liability for Telephone Charges', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for Telephone Charges', '0000-00-00 00:00:00'),
(64, '03/003/003', ' Liability for Books & Scientific Journals', 'credit', 'LIABILITY', 'LIABILITY', 'PL', ' Liability for Books & Scientific Journals', '0000-00-00 00:00:00'),
(65, '03/003/004', 'Liability for AMC of Software', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for AMC of Software', '0000-00-00 00:00:00'),
(66, '03/003/005', '  Liability for NATS Portals', 'credit', 'LIABILITY', 'LIABILITY', 'PL', '  Liability for NATS Portals', '0000-00-00 00:00:00'),
(67, '03/003/006', ' Liability for AMC of ACs', 'credit', 'LIABILITY', 'LIABILITY', 'PL', ' Liability for AMC of ACs', '0000-00-00 00:00:00'),
(68, '03/003/007', 'Liability for AMC of Computer & Pheriperials', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for AMC of Computer & Pheriperials', '0000-00-00 00:00:00'),
(69, '03/003/008', 'Liability for AMC of Office Equipments', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for AMC of Office Equipments', '0000-00-00 00:00:00'),
(70, '03/003/009', 'Liability for Suppliers Bills', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for Suppliers Bills', '0000-00-00 00:00:00'),
(71, '03/003/010', 'Liability for others', 'credit', 'LIABILITY', 'LIABILITY', 'PL', 'Liability for others', '0000-00-00 00:00:00'),
(72, '03/002/001', 'Provision for Audit Fee', 'credit', 'Provisions', 'PROVISION ', 'PL', 'Provision for Audit Fee', '0000-00-00 00:00:00'),
(73, '03/002/002', ' Provision for Others', 'credit', 'Provisions', 'PROVISION ', 'PL', ' Provision for Others', '0000-00-00 00:00:00'),
(74, '15/001/001', ' Basic Pay', 'debit', 'Expense', 'Basic Pay', 'PL', ' Basic Pay', '0000-00-00 00:00:00'),
(75, '15/002/001', 'Conveyance Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'Conveyance Allowance', '0000-00-00 00:00:00'),
(76, '15/002/002', 'Dearness Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'Dearness Allowance', '0000-00-00 00:00:00'),
(77, '15/001/002', 'Dearness Pay', 'debit', 'Expense', 'Basic Pay', 'PL', 'Dearness Pay', '0000-00-00 00:00:00'),
(78, '15/002/003', 'Deputation Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'Deputation Allowance', '0000-00-00 00:00:00'),
(79, '15/002/004', 'House Rent Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'House Rent Allowance', '0000-00-00 00:00:00'),
(80, '15/001/003', ' Interim Relief', 'debit', 'Expense', 'Basic Pay', 'PL', ' Interim Relief', '0000-00-00 00:00:00'),
(81, '15/007/001', '  LTC Leave Encashment', 'debit', 'Expense', ' LTC Leave Encashment', 'PL', '  LTC Leave Encashment', '0000-00-00 00:00:00'),
(82, '15/011/001', 'Misc Refunds', 'debit', 'Expense', 'Others', 'PL', 'Misc Refunds', '0000-00-00 00:00:00'),
(83, '15/002/005', 'Other Salary Linked Allowances', 'debit', 'Expense', 'Allowance', 'PL', 'Other Salary Linked Allowances', '0000-00-00 00:00:00'),
(84, '15/002/006', 'Overtime Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'Overtime Allowance', '0000-00-00 00:00:00'),
(85, '15/001/004', ' Personal Pay', 'debit', 'Expense', 'Basic Pay', 'PL', ' Personal Pay', '0000-00-00 00:00:00'),
(86, '15/011/002', 'Salary Temporary Status', 'debit', 'Expense', 'Others', 'PL', 'Salary Temporary Status', '0000-00-00 00:00:00'),
(87, '15/011/003', 'Special Pay', 'debit', 'Expense', 'Others', 'PL', 'Special Pay', '0000-00-00 00:00:00'),
(88, '15/002/009', 'TA on first Appointment', 'debit', 'Expense', 'Allowance', 'PL', 'TA on first Appointment', '0000-00-00 00:00:00'),
(89, '15/002/007', 'Transport Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'Transport Allowance', '0000-00-00 00:00:00'),
(90, '15/002/008', 'Washing Allowance', 'debit', 'Expense', 'Allowance', 'PL', 'Washing Allowance', '0000-00-00 00:00:00'),
(91, '15/011/002', 'Others', 'debit', 'Expense', 'Others', 'PL', 'Others', '0000-00-00 00:00:00'),
(92, '15/003/001', 'Employer\'s Contribution to Provident Fund', 'debit', 'Expense', 'Contribution to Provident Fund', 'PL', 'Employer\'s Contribution to Provident Fund', '0000-00-00 00:00:00'),
(93, '15/004/001', 'Employer\'s Contribution to Other Funds', 'debit', 'Expense', 'Contribution to Other Funds', 'PL', 'Employer\'s Contribution to Other Funds', '0000-00-00 00:00:00'),
(94, '15/002/009', 'Bonus to Daily Wage Staff', 'debit', 'Expense', 'Allowance', 'PL', 'Bonus to Daily Wage Staff', '0000-00-00 00:00:00'),
(95, '15/002/010', ' Bonus to Regular Staff', 'debit', 'Expense', 'Allowance', 'PL', ' Bonus to Regular Staff', '0000-00-00 00:00:00'),
(96, '15/002/011', 'Bonus to Temporary Status Staff', 'debit', 'Expense', 'Allowance', 'PL', 'Bonus to Temporary Status Staff', '0000-00-00 00:00:00'),
(97, '15/005/001', 'Grants to Staff Club', 'debit', 'Expense', 'Reimbursement  Grants', 'PL', 'Grants to Staff Club', '0000-00-00 00:00:00'),
(98, '15/001/005', 'Leave Travel Concession', 'debit', 'Expense', 'Basic Pay', 'PL', 'Leave Travel Concession', '0000-00-00 00:00:00'),
(99, '15/008/001', 'Medical Reimbursement', 'debit', 'Expense', ' Medical', 'PL', 'Medical Reimbursement', '0000-00-00 00:00:00'),
(100, '15/005/003', 'Reimbursement of News Paper Expenses', 'debit', 'Expense', 'Reimbursement  others', 'PL', 'Reimbursement of News Paper Expenses', '0000-00-00 00:00:00'),
(101, '15/009/001', ' Reimbursement of Tuition Fees/CEA', 'debit', 'Expense', 'Tuition Fees/CEA', 'PL', ' Reimbursement of Tuition Fees/CEA', '0000-00-00 00:00:00'),
(102, '15/005/004', 'Reimbursement of telephone bills', 'debit', 'Expense', 'Reimbursement  others', 'PL', 'Reimbursement of telephone bills', '0000-00-00 00:00:00'),
(103, '15/011/001', ' Special Lectures & Training to Staff', 'debit', 'Expense', 'Other Special Expenses', 'PL', ' Special Lectures & Training to Staff', '0000-00-00 00:00:00'),
(104, '15/011/002', 'Others', 'debit', 'Expense', 'Other Special Expenses', 'PL', 'Others', '0000-00-00 00:00:00'),
(105, '15/006/001', ' Deposit Linked Insurance Payment', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', ' Deposit Linked Insurance Payment', '0000-00-00 00:00:00'),
(106, '15/006/002', 'Medical Allowance to Retired Employee', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', 'Medical Allowance to Retired Employee', '0000-00-00 00:00:00'),
(107, '15/006/003', ' Payment of Gratuity', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', ' Payment of Gratuity', '0000-00-00 00:00:00'),
(108, '15/006/004', 'Payment of Leave Encashment', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', 'Payment of Leave Encashment', '0000-00-00 00:00:00'),
(109, '15/006/005', 'Payment of Pension', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', 'Payment of Pension', '0000-00-00 00:00:00'),
(110, '15/006/006', ' Travel to Hometown on Retirement', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', ' Travel to Hometown on Retirement', '0000-00-00 00:00:00'),
(111, '15/006/007', ' Employer\'s Contribution to New Pension Scheme (2004)', 'debit', 'Expense', 'RETIREMENT AND TERMINAL BENEFI', 'PL', ' Employer\'s Contribution to New Pension Scheme (2004)', '0000-00-00 00:00:00'),
(112, '15/010/001', 'Consultancy Fees', 'debit', 'Expense', 'FEES AND HONORARIUM', 'PL', 'Consultancy Fees', '0000-00-00 00:00:00'),
(113, '15/010/002', 'Honorarium/Sitting Fee  to Members of different committees', 'debit', 'Expense', 'FEES AND HONORARIUM', 'PL', 'Honorarium/Sitting Fee  to Members of different committees', '0000-00-00 00:00:00'),
(114, '15/010/003', ' Honorarium to Staff', 'debit', 'Expense', 'FEES AND HONORARIUM', 'PL', ' Honorarium to Staff', '0000-00-00 00:00:00'),
(115, '15/011/003', 'Leave  Salary & Pension Contribution Payments', 'debit', 'Expense', 'Other Special Expenses', 'PL', 'Leave  Salary & Pension Contribution Payments', '0000-00-00 00:00:00'),
(116, '17/003/004', '  Auditor\'s Remuneration (C&AG)', 'debit', 'Expense', 'AUDIT FEE', 'PL', '  Auditor\'s Remuneration (C&AG)', '0000-00-00 00:00:00'),
(117, '17/003/005', 'Internal Auditor', 'debit', 'Expense', 'AUDIT FEE', 'PL', 'Internal Auditor', '0000-00-00 00:00:00'),
(118, '17/003/006', 'Others', 'debit', 'Expense', 'AUDIT FEE', 'PL', 'Others', '0000-00-00 00:00:00'),
(119, '17/014/001', ' Honorarium to Resource Persons', 'debit', 'Expense', 'Expenses', 'PL', ' Honorarium to Resource Persons', '0000-00-00 00:00:00'),
(120, '17/014/002', 'Participant Cost ', 'debit', 'Expense', 'Expenses', 'PL', 'Participant Cost ', '0000-00-00 00:00:00'),
(121, '17/014/003', 'Posters/Banners/Booklet for Seminar/Workshop', 'debit', 'Expense', 'Expenses', 'PL', 'Posters/Banners/Booklet for Seminar/Workshop', '0000-00-00 00:00:00'),
(122, '17/014/004', 'Running Expenses for Workshop & Equipments', 'debit', 'Expense', 'Expenses', 'PL', 'Running Expenses for Workshop & Equipments', '0000-00-00 00:00:00'),
(123, '17/014/005', 'Seminars/Symposia/Workshop', 'debit', 'Expense', 'Expenses', 'PL', 'Seminars/Symposia/Workshop', '0000-00-00 00:00:00'),
(124, '17/014/006', 'TA/DA to Participants', 'debit', 'Expense', 'Expenses', 'PL', 'TA/DA to Participants', '0000-00-00 00:00:00'),
(125, '17/014/007', '  TA/Honorarium  to Resource Persons', 'debit', 'Expense', 'Expenses', 'PL', '  TA/Honorarium  to Resource Persons', '0000-00-00 00:00:00'),
(126, '17/014/008', 'Working Expenses', 'debit', 'Expense', 'Expenses', 'PL', 'Working Expenses', '0000-00-00 00:00:00'),
(127, '17/014/009', 'Payment to Resource agency', 'debit', 'Expense', 'Expenses', 'PL', 'Payment to Resource agency', '0000-00-00 00:00:00'),
(128, '17/014/010', 'Fooding expenses', 'debit', 'Expense', 'Expenses', 'PL', 'Fooding expenses', '0000-00-00 00:00:00'),
(129, '17/014/011', 'Lodging expenses', 'debit', 'Expense', 'Expenses', 'PL', 'Lodging expenses', '0000-00-00 00:00:00'),
(130, '17/014/012', 'Hiring Charges', 'debit', 'Expense', 'Expenses', 'PL', 'Hiring Charges', '0000-00-00 00:00:00'),
(131, '17/014/013', 'Other Misc. Expenses', 'debit', 'Expense', 'Expenses', 'PL', 'Other Misc. Expenses', '0000-00-00 00:00:00'),
(132, '17/001/001', 'Electricity Expenses', 'debit', 'Expense', 'Electricity&Generator', 'PL', 'Electricity Expenses', '0000-00-00 00:00:00'),
(133, '17/001/002', 'Generator Running Expenses', 'debit', 'Expense', 'Electricity&Generator', 'PL', 'Generator Running Expenses', '0000-00-00 00:00:00'),
(134, '18/001/003', 'Insurance of Vehicles', 'debit', 'Expense', 'Vehicles', 'PL', 'Insurance of Vehicles', '0000-00-00 00:00:00'),
(135, '17/004/001', 'Rates, Rent & Taxes', 'debit', 'Expense', 'Rates, Rent & Taxes and Expenses', 'PL', 'Rates, Rent & Taxes', '0000-00-00 00:00:00'),
(136, '17/014/014', 'Security Expenses', 'debit', 'Expense', 'Expenses', 'PL', 'Security Expenses', '0000-00-00 00:00:00'),
(137, '18/001/001', 'Vehicle Running Expenses (Cost of Petrol, Etc.)', 'debit', 'Expense', 'Vehicles', 'PL', 'Vehicle Running Expenses (Cost of Petrol, Etc.)', '0000-00-00 00:00:00'),
(138, '17/002/001', 'Water Expenses', 'debit', 'Expense', 'Water Expenses', 'PL', 'Water Expenses', '0000-00-00 00:00:00'),
(139, '17/006/001', ' Internet Connectivity Charges', 'debit', 'Expense', 'COMMUNICATION', 'PL', ' Internet Connectivity Charges', '0000-00-00 00:00:00'),
(140, '17/005/001', 'Postage & Telegrams Expenses', 'debit', 'Expense', 'Postage & Telegrams', 'PL', 'Postage & Telegrams Expenses', '0000-00-00 00:00:00'),
(141, '17/006/002', '  Telephone Expenses', 'debit', 'Expense', 'COMMUNICATION', 'PL', '  Telephone Expenses', '0000-00-00 00:00:00'),
(142, '17/008/001', 'TA/DA Members of Advisory Committee,BOG,SFC.etc', 'debit', 'Expense', ' TA/DA', 'PL', 'TA/DA Members of Advisory Committee,BOG,SFC.etc', '0000-00-00 00:00:00'),
(143, '17/008/002', 'TA/DA members of Selection Committee/Board', 'debit', 'Expense', ' TA/DA', 'PL', 'TA/DA members of Selection Committee/Board', '0000-00-00 00:00:00'),
(144, '17/008/003', 'TA on Appointment/Called for Interview/Tests', 'debit', 'Expense', ' TA/DA', 'PL', 'TA on Appointment/Called for Interview/Tests', '0000-00-00 00:00:00'),
(145, '17/012/001', 'Advertisement Expenses', 'debit', 'Expense', 'ADVERTISEMENTS & PUBLICITY', 'PL', 'Advertisement Expenses', '0000-00-00 00:00:00'),
(146, '17/014/015', 'Arbitration Award Payments', 'debit', 'Expense', 'Security', 'PL', 'Arbitration Award Payments', '0000-00-00 00:00:00'),
(147, '17/014/016', 'Legal Expenses', 'debit', 'Expense', 'Security', 'PL', 'Legal Expenses', '0000-00-00 00:00:00'),
(148, '17/014/017', 'Daily Wages', 'debit', 'Expense', 'Security', 'PL', 'Daily Wages', '0000-00-00 00:00:00'),
(149, '04/001/001', 'DepreciationExpenses', 'debit', 'Expense', 'DEPRECIATIOIN', 'PL', 'DepreciationExpenses', '0000-00-00 00:00:00'),
(150, '17/014/018', 'Entertainment Expenses', 'debit', 'Expense', 'Security', 'PL', 'Entertainment Expenses', '0000-00-00 00:00:00'),
(151, '17/014/019', 'Local Conveyance', 'debit', 'Expense', 'Security', 'PL', 'Local Conveyance', '0000-00-00 00:00:00'),
(152, '17/014/020', ' Loss on Sale/Disposal of Assets', 'debit', 'Expense', 'Security', 'PL', ' Loss on Sale/Disposal of Assets', '0000-00-00 00:00:00'),
(153, '17/014/021', ' Newspapers & Periodicals', 'debit', 'Expense', 'Security', 'PL', ' Newspapers & Periodicals', '0000-00-00 00:00:00'),
(154, '17/014/022', ' Recruitment Expenses', 'debit', 'Expense', 'Security', 'PL', ' Recruitment Expenses', '0000-00-00 00:00:00'),
(155, '17/014/023', ' Xeroxing Charges', 'debit', 'Expense', 'Security', 'PL', ' Xeroxing Charges', '0000-00-00 00:00:00'),
(156, '17/014/024', 'Bank Charges', 'debit', 'Expense', 'Security', 'PL', 'Bank Charges', '0000-00-00 00:00:00'),
(157, '17/014/025', 'BOG/EC/FC/AC/Court Meeting Expenses/Other Committee Expenses\n         ', 'debit', 'Expense', 'Security', 'PL', 'BOG/EC/FC/AC/Court Meeting Expenses/Other Committee Expenses\n         ', '0000-00-00 00:00:00'),
(158, '17/014/026', 'Conservancy Expenses', 'debit', 'Expense', 'Security', 'PL', 'Conservancy Expenses', '0000-00-00 00:00:00'),
(159, '17/014/027', ' Liveries ', 'debit', 'Expense', 'Security', 'PL', ' Liveries ', '0000-00-00 00:00:00'),
(160, '17/014/028', 'Local Conveyance', 'debit', 'Expense', 'Security', 'PL', 'Local Conveyance', '0000-00-00 00:00:00'),
(161, '17/014/029', ' Newspapers & Periodicals', 'debit', 'Expense', 'Security', 'PL', ' Newspapers & Periodicals', '0000-00-00 00:00:00'),
(162, '17/014/030', ' Printing of Forms & registers', 'debit', 'Expense', 'Security', 'PL', ' Printing of Forms & registers', '0000-00-00 00:00:00'),
(163, '17/014/031', 'Purchase of Stationery', 'debit', 'Expense', 'Security', 'PL', 'Purchase of Stationery', '0000-00-00 00:00:00'),
(164, '17/014/032', 'Xeroxing Charges', 'debit', 'Expense', 'Security', 'PL', 'Xeroxing Charges', '0000-00-00 00:00:00'),
(165, '19/008/001', 'Purchase of Cleaning Material', 'debit', 'Expense', 'CLEANING MATERIAL', 'PL', 'Purchase of Cleaning Material', '0000-00-00 00:00:00'),
(166, '19/001/001', 'Guest House Maintenance', 'debit', 'Expense', 'MAINTENANCE OF BUILDINGS', 'PL', 'Guest House Maintenance', '0000-00-00 00:00:00'),
(167, '19/001/002', 'Campus Development and Maintenance', 'debit', 'Expense', 'MAINTENANCE OF BUILDINGS', 'PL', 'Campus Development and Maintenance', '0000-00-00 00:00:00'),
(168, '19/001/003', '  Electrical Maintenance', 'debit', 'Expense', 'MAINTENANCE OF BUILDINGS', 'PL', '  Electrical Maintenance', '0000-00-00 00:00:00'),
(169, '19/011/001', ' Estate Maintenance', 'debit', 'Expense', 'Estate', 'PL', ' Estate Maintenance', '0000-00-00 00:00:00'),
(170, '19/012/001', ' Minor Works', 'debit', 'Expense', 'Works', 'PL', ' Minor Works', '0000-00-00 00:00:00'),
(171, '19/001/004', 'Repair of Buildings', 'debit', 'Expense', 'MAINTENANCE OF BUILDINGS', 'PL', 'Repair of Buildings', '0000-00-00 00:00:00'),
(172, '19/010/001', 'Horticulture Maintenance', 'debit', 'Expense', 'HORTICULTURE & GARDENING', 'PL', 'Horticulture Maintenance', '0000-00-00 00:00:00'),
(173, '19/004/001', 'Maintenance of Office Equipments', 'debit', 'Expense', 'MAINTENANCE', 'PL', 'Maintenance of Office Equipments', '0000-00-00 00:00:00'),
(174, '19/005/001', 'Maintenance of Computers', 'debit', 'Expense', 'Maintenance of Computers', 'PL', 'Maintenance of Computers', '0000-00-00 00:00:00'),
(175, '19/004/002', 'Maintenance of Electrical Equipments', 'debit', 'Expense', 'MAINTENANCE', 'PL', 'Maintenance of Electrical Equipments', '0000-00-00 00:00:00'),
(176, '19/003/001', 'Maintenance of Plant & Machinery', 'debit', 'Expense', 'Maintenance of Plant & Machine', 'PL', 'Maintenance of Plant & Machinery', '0000-00-00 00:00:00'),
(177, '19/004/003', 'Maintenance of Tubewells & Water Supply', 'debit', 'Expense', 'MAINTENANCE(others)', 'PL', 'Maintenance of Tubewells & Water Supply', '0000-00-00 00:00:00'),
(178, '19/012/001', 'Repair of Water Coolers, Ac, Fans Etc', 'debit', 'Expense', 'Works', 'PL', 'Repair of Water Coolers, Ac, Fans Etc', '0000-00-00 00:00:00'),
(179, '18/003/001', 'Hire of Taxi-Staff', 'debit', 'Expense', 'Taxi-Staff', 'PL', 'Hire of Taxi-Staff', '0000-00-00 00:00:00'),
(180, '18/001/002', 'Maintenance of Other Vehicles', 'debit', 'Expense', 'Other Vehicles', 'PL', 'Maintenance of Other Vehicles', '0000-00-00 00:00:00'),
(181, '18/001/003', '  Maintenance of Staff Cars', 'debit', 'Expense', 'Other Vehicles', 'PL', '  Maintenance of Staff Cars', '0000-00-00 00:00:00'),
(182, '19/002/001', 'Maintenance of Furniture', 'debit', 'Expense', ' MAINTENANCE OF FURNITURES', 'PL', 'Maintenance of Furniture', '0000-00-00 00:00:00'),
(183, '19/002/002', 'Repair & Polishing of Furniture', 'debit', 'Expense', ' MAINTENANCE OF FURNITURES', 'PL', 'Repair & Polishing of Furniture', '0000-00-00 00:00:00'),
(184, '19/009/001', 'Book Binding Charges', 'debit', 'Expense', 'MAINTENANCE OF BOOKS', 'PL', 'Book Binding Charges', '0000-00-00 00:00:00'),
(185, '19/007/001', ' Maintenance  of Audio Visual Equipment', 'debit', 'Expense', 'MAINTENANCE  OF AUDIO VISUAL E', 'PL', ' Maintenance  of Audio Visual Equipment', '0000-00-00 00:00:00'),
(186, '19/012/002', ' Repair of Tubewells & Water Supply', 'debit', 'Expense', 'Works', 'PL', ' Repair of Tubewells & Water Supply', '0000-00-00 00:00:00'),
(187, '22/002/001', 'Prior Period- Academic Expenses', 'debit', 'Expense', 'PRIOR PERIOD ACADEMIC EXPENSES', 'PL', 'Prior Period- Academic Expenses', '0000-00-00 00:00:00'),
(188, '22/002/002', 'Prior Period- Research Expenses', 'debit', 'Expense', 'PRIOR PERIOD ACADEMIC EXPENSES', 'PL', 'Prior Period- Research Expenses', '0000-00-00 00:00:00'),
(189, '22/003/001', 'Prior Period- Administrative Expenses', 'debit', 'Expense', 'PRIOR PERIOD ADMINISTRATIVE EXPENSES', 'PL', 'Prior Period- Administrative Expenses', '0000-00-00 00:00:00'),
(190, '22/004/001', 'Prior Period Vehicle Running Expenses', 'debit', 'Expense', 'PRIOR PERIOD TRANSPORTATION EXPENSES', 'PL', 'Prior Period Vehicle Running Expenses', '0000-00-00 00:00:00'),
(191, '22/003/002', 'Prior Period Contribution to CGHS', 'debit', 'Expense', 'PRIOR PERIOD ADMINISTRATIVE EXPENSES', 'PL', 'Prior Period Contribution to CGHS', '0000-00-00 00:00:00'),
(192, '22/001/001', 'Prior Period Establishment Expenses', 'debit', 'Expense', 'PRIOR PERIOD ESTABLISHMENT EXPENSES', 'PL', 'Prior Period Establishment Expenses', '0000-00-00 00:00:00'),
(193, '22/005/001', 'Prior Period Repairs & Maintenance', 'debit', 'Expense', 'PRIOR PERIOD REPAIRS & MAINTENANCE', 'PL', 'Prior Period Repairs & Maintenance', '0000-00-00 00:00:00'),
(194, '22/006/001', ' Prior Period Other Expenses', 'debit', 'Expense', 'PRIOR PERIOD OTHER EXPENSES', 'PL', ' Prior Period Other Expenses', '0000-00-00 00:00:00'),
(195, '03/005/001', 'Liability for Administrative Charges', 'credit', 'Liability', ' Liability for Administrative ', 'PL', 'Liability for Administrative Charges', '0000-00-00 00:00:00'),
(196, '03/006/001', 'Liability for Tution fees/CEA', 'credit', 'Liability', 'Liability for Tution fees/CEA ', 'PL', 'Liability for Tution fees/CEA', '0000-00-00 00:00:00'),
(197, '03/006/002', 'Liability for Arrear DA', 'credit', 'Liability', 'Liability for Tution fees/CEA ', 'PL', 'Liability for Arrear DA', '0000-00-00 00:00:00'),
(208, '03/002/001', 'Provision for Audit Fee', 'credit', 'Liability', 'PROVISION ', 'PL', 'Provision for Audit Fee', '0000-00-00 00:00:00'),
(209, '03/002/002', 'Provision for Others', 'credit', 'Liability', 'PROVISION ', 'PL', 'Provision for Others', '0000-00-00 00:00:00'),
(210, '04/001/001', 'Land', 'debit', 'Assets', 'Land', 'PL', 'Land', '0000-00-00 00:00:00'),
(211, '04/003/001', 'Additional Toilets', 'debit', 'Assets', 'Buildings', 'PL', 'Additional Toilets', '0000-00-00 00:00:00'),
(212, '04/003/002', 'Auditorium ', 'debit', 'Assets', 'Buildings', 'PL', 'Auditorium ', '0000-00-00 00:00:00'),
(213, '04/003/003', 'Boundary Wall', 'debit', 'Assets', 'Buildings', 'PL', 'Boundary Wall', '0000-00-00 00:00:00'),
(214, '04/003/004', 'Guest Room', 'debit', 'Assets', 'Buildings', 'PL', 'Guest Room', '0000-00-00 00:00:00'),
(215, '04/003/005', 'Office Buildings', 'debit', 'Assets', 'Buildings', 'PL', 'Office Buildings', '0000-00-00 00:00:00'),
(216, '04/003/006', 'Other Buildings', 'debit', 'Assets', 'Buildings', 'PL', 'Other Buildings', '0000-00-00 00:00:00'),
(217, '04/003/007', 'Pump House', 'debit', 'Assets', 'Buildings', 'PL', 'Pump House', '0000-00-00 00:00:00'),
(218, '04/003/008', 'Residential Buildings', 'debit', 'Assets', 'Buildings', 'PL', 'Residential Buildings', '0000-00-00 00:00:00'),
(219, '04/003/009', 'Others', 'debit', 'Assets', 'Buildings', 'PL', 'Others', '0000-00-00 00:00:00'),
(220, '04/004/001', 'Roads', 'debit', 'Assets', 'Roads & Bridges', 'PL', 'Roads', '0000-00-00 00:00:00'),
(221, '04/004/002', 'Others', 'debit', 'Assets', 'Roads & Bridges', 'PL', 'Others', '0000-00-00 00:00:00'),
(222, '04/005/001', 'Augmentation of Water Supply in campus', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Augmentation of Water Supply in campus', '0000-00-00 00:00:00'),
(223, '04/005/002', 'Overhead Water Tanks', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Overhead Water Tanks', '0000-00-00 00:00:00'),
(224, '04/005/003', 'Pumping Plant', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Pumping Plant', '0000-00-00 00:00:00'),
(225, '04/005/004', 'Tube Wells', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Tube Wells', '0000-00-00 00:00:00'),
(226, '04/005/005', 'Under Ground WaterTanks', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Under Ground WaterTanks', '0000-00-00 00:00:00'),
(227, '04/005/006', 'Water Filters(Aquaguard)', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Water Filters(Aquaguard)', '0000-00-00 00:00:00'),
(228, '04/005/007', 'Water Pumps', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Water Pumps', '0000-00-00 00:00:00'),
(229, '04/005/008', 'Water Sprinklers', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Water Sprinklers', '0000-00-00 00:00:00'),
(230, '04/005/009', 'Water Supply Distribution Mains', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Water Supply Distribution Mains', '0000-00-00 00:00:00'),
(231, '04/005/010', 'Water Supply Valves, Regulators & Tapes', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Water Supply Valves, Regulators & Tapes', '0000-00-00 00:00:00'),
(232, '04/005/011', 'Water Tanks', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Water Tanks', '0000-00-00 00:00:00'),
(233, '04/005/012', 'Others', 'debit', 'Assets', 'Tubewells & Water Supply', 'PL', 'Others', '0000-00-00 00:00:00'),
(234, '04/006/001', 'Sewerage & Drainage', 'debit', 'Assets', 'Sewerage & Drainage', 'PL', 'Sewerage & Drainage', '0000-00-00 00:00:00'),
(235, '04/006/002', 'Others', 'debit', 'Assets', 'Sewerage & Drainage', 'PL', 'Others', '0000-00-00 00:00:00'),
(236, '04/007/001', 'Air Conditioners', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Air Conditioners', '0000-00-00 00:00:00'),
(237, '04/007/002', 'Batteries', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Batteries', '0000-00-00 00:00:00'),
(238, '04/007/003', 'Ceiling Fans', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Ceiling Fans', '0000-00-00 00:00:00'),
(239, '04/007/004', 'Desert Coolers', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Desert Coolers', '0000-00-00 00:00:00'),
(240, '04/007/005', 'Dish Antenna', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Dish Antenna', '0000-00-00 00:00:00'),
(241, '04/007/006', 'Electric Kettle', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Electric Kettle', '0000-00-00 00:00:00'),
(242, '04/007/007', 'Electric Motors', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Electric Motors', '0000-00-00 00:00:00'),
(243, '04/007/008', 'Electrical Fittings', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Electrical Fittings', '0000-00-00 00:00:00'),
(244, '04/007/009', 'Electrical Installation & Equipments', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Electrical Installation & Equipments', '0000-00-00 00:00:00'),
(245, '04/007/010', 'Exhaust Fans', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Exhaust Fans', '0000-00-00 00:00:00'),
(246, '04/007/011', 'Food Processors', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Food Processors', '0000-00-00 00:00:00'),
(247, '04/007/012', 'Generators', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Generators', '0000-00-00 00:00:00'),
(248, '04/007/013', 'Heaters', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Heaters', '0000-00-00 00:00:00'),
(249, '04/007/014', 'Hot  Cases', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Hot  Cases', '0000-00-00 00:00:00'),
(250, '04/007/015', 'Internet Modem', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Internet Modem', '0000-00-00 00:00:00'),
(251, '04/007/016', 'Invertors', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Invertors', '0000-00-00 00:00:00'),
(252, '04/007/017', 'Lawn Movers/Grass Cutter', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Lawn Movers/Grass Cutter', '0000-00-00 00:00:00'),
(253, '04/007/018', 'Lifts', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Lifts', '0000-00-00 00:00:00'),
(254, '04/007/019', 'Microwaves', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Microwaves', '0000-00-00 00:00:00'),
(255, '04/007/020', 'Pedestal Fans', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Pedestal Fans', '0000-00-00 00:00:00'),
(256, '04/007/021', 'Refrigerators', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Refrigerators', '0000-00-00 00:00:00'),
(257, '04/007/022', 'Room Heaters', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Room Heaters', '0000-00-00 00:00:00'),
(258, '04/007/023', 'Shredding Machine', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Shredding Machine', '0000-00-00 00:00:00'),
(259, '04/007/024', 'Substations', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Substations', '0000-00-00 00:00:00'),
(260, '04/007/025', 'Switchyards', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Switchyards', '0000-00-00 00:00:00'),
(261, '04/007/026', 'Table Fans', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Table Fans', '0000-00-00 00:00:00'),
(262, '04/007/027', 'Table Lamps', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Table Lamps', '0000-00-00 00:00:00'),
(263, '04/007/028', 'Transformers', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Transformers', '0000-00-00 00:00:00'),
(264, '04/007/029', 'Underground Cables', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Underground Cables', '0000-00-00 00:00:00'),
(265, '04/007/030', 'Vaccum Cleaners', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Vaccum Cleaners', '0000-00-00 00:00:00'),
(266, '04/007/031', 'Voltage Stabilisers', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Voltage Stabilisers', '0000-00-00 00:00:00'),
(267, '04/007/032', 'Water Coolers', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Water Coolers', '0000-00-00 00:00:00'),
(268, '04/007/033', 'Water Geysers', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Water Geysers', '0000-00-00 00:00:00'),
(269, '04/007/034', 'Others', 'debit', 'Assets', 'ElectricalInstallation&Equipments', 'PL', 'Others', '0000-00-00 00:00:00'),
(270, '04/008/001', 'Air Conditioning Plants', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Air Conditioning Plants', '0000-00-00 00:00:00'),
(271, '04/008/002', 'Chlorination Plants', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Chlorination Plants', '0000-00-00 00:00:00'),
(272, '04/008/003', 'Fire Alarm Systems', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Fire Alarm Systems', '0000-00-00 00:00:00'),
(273, '04/008/004', 'Plant & Machinery', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Plant & Machinery', '0000-00-00 00:00:00'),
(274, '04/008/005', 'Solar Water Heating System', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Solar Water Heating System', '0000-00-00 00:00:00'),
(275, '04/008/006', 'Water Purification Plants', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Water Purification Plants', '0000-00-00 00:00:00'),
(276, '04/008/007', 'Others', 'debit', 'Assets', 'Plant & Machinery', 'PL', 'Others', '0000-00-00 00:00:00'),
(277, '04/010/001', 'Briefcases/Suitcases', 'debit', 'Assets', 'Office Equipment', 'PL', 'Briefcases/Suitcases', '0000-00-00 00:00:00'),
(278, '04/010/002', 'Cash Safe', 'debit', 'Assets', 'Office Equipment', 'PL', 'Cash Safe', '0000-00-00 00:00:00'),
(279, '04/010/003', 'Close Circuit Camera Security System', 'debit', 'Assets', 'Office Equipment', 'PL', 'Close Circuit Camera Security System', '0000-00-00 00:00:00'),
(280, '04/010/004', 'Duplicators', 'debit', 'Assets', 'Office Equipment', 'PL', 'Duplicators', '0000-00-00 00:00:00'),
(281, '04/010/005', 'EPABX', 'debit', 'Assets', 'Office Equipment', 'PL', 'EPABX', '0000-00-00 00:00:00'),
(282, '04/010/006', 'Fax Machines', 'debit', 'Assets', 'Office Equipment', 'PL', 'Fax Machines', '0000-00-00 00:00:00'),
(283, '04/010/007', 'Fire Extinguishers', 'debit', 'Assets', 'Office Equipment', 'PL', 'Fire Extinguishers', '0000-00-00 00:00:00'),
(284, '04/010/008', 'Franking Machines', 'debit', 'Assets', 'Office Equipment', 'PL', 'Franking Machines', '0000-00-00 00:00:00'),
(285, '04/010/009', 'Intercom', 'debit', 'Assets', 'Office Equipment', 'PL', 'Intercom', '0000-00-00 00:00:00'),
(286, '04/010/010', 'Mobile Phones', 'debit', 'Assets', 'Office Equipment', 'PL', 'Mobile Phones', '0000-00-00 00:00:00'),
(287, '04/010/011', 'Office Equipments', 'debit', 'Assets', 'Office Equipment', 'PL', 'Office Equipments', '0000-00-00 00:00:00'),
(288, '04/010/012', 'Paper Shredder', 'debit', 'Assets', 'Office Equipment', 'PL', 'Paper Shredder', '0000-00-00 00:00:00'),
(289, '04/010/013', 'Photocopiers', 'debit', 'Assets', 'Office Equipment', 'PL', 'Photocopiers', '0000-00-00 00:00:00'),
(290, '04/010/014', 'Calculators', 'debit', 'Assets', 'Office Equipment', 'PL', 'Calculators', '0000-00-00 00:00:00'),
(291, '04/010/015', 'Telephone System', 'debit', 'Assets', 'Office Equipment', 'PL', 'Telephone System', '0000-00-00 00:00:00'),
(292, '04/010/016', 'Vending Machine (Tea/Coffee)', 'debit', 'Assets', 'Office Equipment', 'PL', 'Vending Machine (Tea/Coffee)', '0000-00-00 00:00:00'),
(293, '04/010/017', 'Walkie Talkie', 'debit', 'Assets', 'Office Equipment', 'PL', 'Walkie Talkie', '0000-00-00 00:00:00'),
(294, '04/010/018', 'Others', 'debit', 'Assets', 'Office Equipment', 'PL', 'Others', '0000-00-00 00:00:00'),
(295, '04/010/019', 'Access Control system', 'debit', 'Assets', 'Office Equipment', 'PL', 'Access Control system', '0000-00-00 00:00:00'),
(296, '04/010/020', 'Automated Gate', 'debit', 'Assets', 'Office Equipment', 'PL', 'Automated Gate', '0000-00-00 00:00:00'),
(297, '04/011/001', 'Audio Recorders', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Audio Recorders', '0000-00-00 00:00:00'),
(298, '04/011/002', 'Audio Visual Equipments', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Audio Visual Equipments', '0000-00-00 00:00:00'),
(299, '04/011/003', 'Camcorder', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Camcorder', '0000-00-00 00:00:00'),
(300, '04/011/004', 'Camera', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Camera', '0000-00-00 00:00:00'),
(301, '04/011/005', 'LCD Projectors', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'LCD Projectors', '0000-00-00 00:00:00'),
(302, '04/011/006', 'Microphone', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Microphone', '0000-00-00 00:00:00'),
(303, '04/011/007', 'Overhead Projectors', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Overhead Projectors', '0000-00-00 00:00:00'),
(304, '04/011/008', 'Public Address Systems', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Public Address Systems', '0000-00-00 00:00:00'),
(305, '04/011/009', 'Projectors', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Projectors', '0000-00-00 00:00:00'),
(306, '04/011/010', 'Slide Projectors', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Slide Projectors', '0000-00-00 00:00:00'),
(307, '04/011/011', 'Slide Viewers', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Slide Viewers', '0000-00-00 00:00:00'),
(308, '04/011/012', 'Television Set', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Television Set', '0000-00-00 00:00:00'),
(309, '04/011/013', 'Touch Screen', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Touch Screen', '0000-00-00 00:00:00'),
(310, '04/011/014', 'VCD/ DVD Players', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'VCD/ DVD Players', '0000-00-00 00:00:00'),
(311, '04/011/015', 'Others', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Others', '0000-00-00 00:00:00'),
(312, '04/011/016', 'Interactive Board', 'debit', 'Assets', 'Audio Visual Equipment', 'PL', 'Interactive Board', '0000-00-00 00:00:00'),
(313, '04/012/001', 'Computer & Accessories', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Computer & Accessories', '0000-00-00 00:00:00'),
(314, '04/012/002', 'Computer Modems', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Computer Modems', '0000-00-00 00:00:00'),
(315, '04/012/003', 'Computers', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Computers', '0000-00-00 00:00:00'),
(316, '04/012/004', 'Digital Camera', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Digital Camera', '0000-00-00 00:00:00'),
(317, '04/012/005', 'Internet Equipment', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Internet Equipment', '0000-00-00 00:00:00'),
(318, '04/012/006', 'Internet Modem', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Internet Modem', '0000-00-00 00:00:00'),
(319, '04/012/007', 'Internet/Wi-Fi Equipment', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Internet/Wi-Fi Equipment', '0000-00-00 00:00:00'),
(320, '04/012/008', 'Pen Drive', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Pen Drive', '0000-00-00 00:00:00'),
(321, '04/012/009', 'External HDD', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'External HDD', '0000-00-00 00:00:00'),
(322, '04/012/010', 'Printers', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Printers', '0000-00-00 00:00:00'),
(323, '04/012/011', 'Scanners', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Scanners', '0000-00-00 00:00:00'),
(324, '04/012/012', 'Servers', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Servers', '0000-00-00 00:00:00'),
(325, '04/012/013', 'Think Centre/ Lap Tops', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Think Centre/ Lap Tops', '0000-00-00 00:00:00'),
(326, '04/012/014', 'UPS', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'UPS', '0000-00-00 00:00:00'),
(327, '04/012/015', 'Web Cams', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Web Cams', '0000-00-00 00:00:00'),
(328, '04/012/016', 'Work Stations', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Work Stations', '0000-00-00 00:00:00'),
(329, '04/012/017', 'Others', 'debit', 'Assets', 'Computers & Accessories', 'PL', 'Others', '0000-00-00 00:00:00'),
(330, '04/013/001', 'Almirahs', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Almirahs', '0000-00-00 00:00:00'),
(331, '04/013/002', 'Aluminium Doors & Windows', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Aluminium Doors & Windows', '0000-00-00 00:00:00'),
(332, '04/013/003', 'Beds', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Beds', '0000-00-00 00:00:00'),
(333, '04/013/004', 'Benches', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Benches', '0000-00-00 00:00:00'),
(334, '04/013/005', 'Book Cases', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Book Cases', '0000-00-00 00:00:00'),
(335, '04/013/006', 'Broadband Expansion Unit', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Broadband Expansion Unit', '0000-00-00 00:00:00'),
(336, '04/013/007', 'Cabinets', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Cabinets', '0000-00-00 00:00:00'),
(337, '04/013/008', 'Carpets', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Carpets', '0000-00-00 00:00:00'),
(338, '04/013/009', 'Cash Box', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Cash Box', '0000-00-00 00:00:00'),
(339, '04/013/010', 'Chairs', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Chairs', '0000-00-00 00:00:00'),
(340, '04/013/011', 'Chalk Boards', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Chalk Boards', '0000-00-00 00:00:00'),
(341, '04/013/012', 'Conference Table', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Conference Table', '0000-00-00 00:00:00'),
(342, '04/013/013', 'Cupboard', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Cupboard', '0000-00-00 00:00:00'),
(343, '04/013/014', 'Desk Acrylic', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Desk Acrylic', '0000-00-00 00:00:00'),
(344, '04/013/015', 'Door/Rolling shutters', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Door/Rolling shutters', '0000-00-00 00:00:00'),
(345, '04/013/016', 'Doors', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Doors', '0000-00-00 00:00:00'),
(346, '04/013/017', 'Filling Cabinets', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Filling Cabinets', '0000-00-00 00:00:00'),
(347, '04/013/018', 'Furniture, Fixtures & Fittings', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Furniture, Fixtures & Fittings', '0000-00-00 00:00:00'),
(348, '04/013/019', 'Guard  Cabins', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Guard  Cabins', '0000-00-00 00:00:00'),
(349, '04/013/020', 'Key Hang Box', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Key Hang Box', '0000-00-00 00:00:00'),
(350, '04/013/021', 'Kitchen Appliances', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Kitchen Appliances', '0000-00-00 00:00:00'),
(351, '04/013/022', 'Ladders', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Ladders', '0000-00-00 00:00:00'),
(352, '04/013/023', 'Light Fittings', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Light Fittings', '0000-00-00 00:00:00'),
(353, '04/013/024', 'Lockers', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Lockers', '0000-00-00 00:00:00'),
(354, '04/013/025', 'Mail/Letter Box', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Mail/Letter Box', '0000-00-00 00:00:00'),
(355, '04/013/026', 'Mattresses', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Mattresses', '0000-00-00 00:00:00'),
(356, '04/013/027', 'Modular Furniture', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Modular Furniture', '0000-00-00 00:00:00'),
(357, '04/013/028', 'Newspaper Stand', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Newspaper Stand', '0000-00-00 00:00:00'),
(358, '04/013/029', 'Notice Boards ', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Notice Boards ', '0000-00-00 00:00:00'),
(359, '04/013/030', 'Partition  Wooden/Aluminium', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Partition  Wooden/Aluminium', '0000-00-00 00:00:00'),
(360, '04/013/031', 'Podium', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Podium', '0000-00-00 00:00:00'),
(361, '04/013/032', 'Porta Cabins', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Porta Cabins', '0000-00-00 00:00:00'),
(362, '04/013/033', 'Racks', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Racks', '0000-00-00 00:00:00'),
(363, '04/013/034', 'Scrylic Shutters', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Scrylic Shutters', '0000-00-00 00:00:00'),
(364, '04/013/035', 'Side Racks', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Side Racks', '0000-00-00 00:00:00'),
(365, '04/013/036', 'Sign Board', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Sign Board', '0000-00-00 00:00:00'),
(366, '04/013/037', 'Slanting Writing Pad', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Slanting Writing Pad', '0000-00-00 00:00:00');
INSERT INTO `coa_master` (`id`, `coa_code`, `head_name`, `account_tool`, `account_type`, `account_name`, `account_reflect_on`, `coa_remarks`, `created_at`) VALUES
(367, '04/013/038', 'Sofas', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Sofas', '0000-00-00 00:00:00'),
(368, '04/013/039', 'Stools', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Stools', '0000-00-00 00:00:00'),
(369, '04/013/040', 'Storage Racks', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Storage Racks', '0000-00-00 00:00:00'),
(370, '04/013/041', 'Tables', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Tables', '0000-00-00 00:00:00'),
(371, '04/013/042', 'TV Trolleys', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'TV Trolleys', '0000-00-00 00:00:00'),
(372, '04/013/043', 'Venetian Blinds', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Venetian Blinds', '0000-00-00 00:00:00'),
(373, '04/013/044', 'Wall  Clocks', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Wall  Clocks', '0000-00-00 00:00:00'),
(374, '04/013/045', 'Wall-Mounted Shelves', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Wall-Mounted Shelves', '0000-00-00 00:00:00'),
(375, '04/013/046', 'Wheel Chairs', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Wheel Chairs', '0000-00-00 00:00:00'),
(376, '04/013/047', 'White/Green/Black  Board', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'White/Green/Black  Board', '0000-00-00 00:00:00'),
(377, '04/013/048', 'Window Blinds', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Window Blinds', '0000-00-00 00:00:00'),
(378, '04/013/049', 'Others', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Others', '0000-00-00 00:00:00'),
(379, '04/013/050', 'Gym Equipments', 'debit', 'Assets', 'Furniture,Fixtures&Fittings', 'PL', 'Gym Equipments', '0000-00-00 00:00:00'),
(380, '04/014/001', 'Cycles', 'debit', 'Assets', 'Vehicles', 'PL', 'Cycles', '0000-00-00 00:00:00'),
(381, '04/014/002', 'Handicapped Chairs', 'debit', 'Assets', 'Vehicles', 'PL', 'Handicapped Chairs', '0000-00-00 00:00:00'),
(382, '04/014/003', 'Motors Cars', 'debit', 'Assets', 'Vehicles', 'PL', 'Motors Cars', '0000-00-00 00:00:00'),
(383, '04/014/004', 'Vehicles', 'debit', 'Assets', 'Vehicles', 'PL', 'Vehicles', '0000-00-00 00:00:00'),
(384, '04/014/005', 'Vehicles Search Trolley Mirror', 'debit', 'Assets', 'Vehicles', 'PL', 'Vehicles Search Trolley Mirror', '0000-00-00 00:00:00'),
(385, '04/014/006', 'Others', 'debit', 'Assets', 'Vehicles', 'PL', 'Others', '0000-00-00 00:00:00'),
(386, '04/015/001', 'E-Journals', 'debit', 'Assets', 'Library Books & Scientific Jou', 'PL', 'E-Journals', '0000-00-00 00:00:00'),
(387, '04/015/002', 'Journals & Periodicals', 'debit', 'Assets', 'Library Books & Scientific Jou', 'PL', 'Journals & Periodicals', '0000-00-00 00:00:00'),
(388, '04/015/003', 'Library Books', 'debit', 'Assets', 'Library Books & Scientific Jou', 'PL', 'Library Books', '0000-00-00 00:00:00'),
(389, '04/015/004', 'Others', 'debit', 'Assets', 'Library Books & Scientific Jou', 'PL', 'Others', '0000-00-00 00:00:00'),
(390, '04/021/001', 'Other Assets', 'debit', 'Assets', 'Miscellaneous Equipments', 'PL', 'Other Assets', '0000-00-00 00:00:00'),
(391, '04/017/001', 'Additional Toilets', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'Additional Toilets', '0000-00-00 00:00:00'),
(392, '04/017/002', 'CWIP Others', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'CWIP Others', '0000-00-00 00:00:00'),
(393, '04/017/003', 'Electrical Installation CWIP', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'Electrical Installation CWIP', '0000-00-00 00:00:00'),
(394, '04/017/004', 'Overhead Tank', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'Overhead Tank', '0000-00-00 00:00:00'),
(395, '04/017/005', 'Renovation of Staff Quarters', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'Renovation of Staff Quarters', '0000-00-00 00:00:00'),
(396, '04/017/006', 'Replacement of Old Lifts', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'Replacement of Old Lifts', '0000-00-00 00:00:00'),
(397, '04/017/007', 'Others', 'debit', 'Assets', 'Capital Work in Progress', 'PL', 'Others', '0000-00-00 00:00:00'),
(398, '04/016/001', 'Almirahs - SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Almirahs - SVA', '0000-00-00 00:00:00'),
(399, '04/016/002', 'Audio Visual Equipments SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Audio Visual Equipments SVA', '0000-00-00 00:00:00'),
(400, '04/016/003', 'BED SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'BED SVA', '0000-00-00 00:00:00'),
(401, '04/016/004', 'Book Cases- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Book Cases- SVA', '0000-00-00 00:00:00'),
(402, '04/016/005', 'Chairs - SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Chairs - SVA', '0000-00-00 00:00:00'),
(403, '04/016/006', 'Computer Accessories- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Computer Accessories- SVA', '0000-00-00 00:00:00'),
(404, '04/016/007', 'Desktop Calculators - SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Desktop Calculators - SVA', '0000-00-00 00:00:00'),
(405, '04/016/008', 'Electric Fittings SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Electric Fittings SVA', '0000-00-00 00:00:00'),
(406, '04/016/009', 'Electric Kettle SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Electric Kettle SVA', '0000-00-00 00:00:00'),
(407, '04/016/010', 'Electrical Equipment SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Electrical Equipment SVA', '0000-00-00 00:00:00'),
(408, '04/016/011', 'Exhaust Fan SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Exhaust Fan SVA', '0000-00-00 00:00:00'),
(409, '04/016/012', 'Fans- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Fans- SVA', '0000-00-00 00:00:00'),
(410, '04/016/013', 'Furniture SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Furniture SVA', '0000-00-00 00:00:00'),
(411, '04/016/014', 'Heaters SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Heaters SVA', '0000-00-00 00:00:00'),
(412, '04/016/015', 'Hot Case- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Hot Case- SVA', '0000-00-00 00:00:00'),
(413, '04/016/016', 'Induction Cooktop SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Induction Cooktop SVA', '0000-00-00 00:00:00'),
(414, '04/016/017', 'Internet Modem- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Internet Modem- SVA', '0000-00-00 00:00:00'),
(415, '04/016/018', 'Inverter- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Inverter- SVA', '0000-00-00 00:00:00'),
(416, '04/016/019', 'Notice Board- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Notice Board- SVA', '0000-00-00 00:00:00'),
(417, '04/016/020', 'Pen drive- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Pen drive- SVA', '0000-00-00 00:00:00'),
(418, '04/016/021', 'Slanting Writing pad- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Slanting Writing pad- SVA', '0000-00-00 00:00:00'),
(419, '04/016/022', 'Stools SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Stools SVA', '0000-00-00 00:00:00'),
(420, '04/016/023', 'Table Lamps- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Table Lamps- SVA', '0000-00-00 00:00:00'),
(421, '04/016/024', 'Tables- SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Tables- SVA', '0000-00-00 00:00:00'),
(422, '04/016/025', 'Telephone System SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Telephone System SVA', '0000-00-00 00:00:00'),
(423, '04/016/026', 'Wall Clock- Sva', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Wall Clock- Sva', '0000-00-00 00:00:00'),
(424, '04/016/027', 'Web Cam Sva', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Web Cam Sva', '0000-00-00 00:00:00'),
(425, '04/016/028', 'Wooden Boxes SVA', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Wooden Boxes SVA', '0000-00-00 00:00:00'),
(426, '04/016/029', 'Others', 'debit', 'Assets', 'Small Value Assets', 'PL', 'Others', '0000-00-00 00:00:00'),
(427, '04/018/001', 'Computer Software', 'debit', 'Assets', 'Intangible Assets', 'PL', 'Computer Software', '0000-00-00 00:00:00'),
(428, '04/018/002', 'Websites', 'debit', 'Assets', 'Intangible Assets', 'PL', 'Websites', '0000-00-00 00:00:00'),
(429, '04/018/003', 'Portals', 'debit', 'Assets', 'Intangible Assets', 'PL', 'Portals', '0000-00-00 00:00:00'),
(430, '04/018/004', 'ERP', 'debit', 'Assets', 'Intangible Assets', 'PL', 'ERP', '0000-00-00 00:00:00'),
(431, '04/018/005', 'DMS', 'debit', 'Assets', 'Intangible Assets', 'PL', 'DMS', '0000-00-00 00:00:00'),
(432, '04/018/006', 'Cyberroam', 'debit', 'Assets', 'Intangible Assets', 'PL', 'Cyberroam', '0000-00-00 00:00:00'),
(433, '04/018/007', 'Antivirus', 'debit', 'Assets', 'Intangible Assets', 'PL', 'Antivirus', '0000-00-00 00:00:00'),
(434, '04/018/008', 'Others', 'debit', 'Assets', 'Intangible Assets', 'PL', 'Others', '0000-00-00 00:00:00'),
(435, '4S/000/001', 'Receipt for  stipend', 'credit', 'income', 'Grant & Subsidies', 'pl', 'Receipt for  stipend', NULL),
(436, '5S/001', 'Interest on savings account for stipend', 'credit', 'income', 'Interest Earned Ã‚Â For Stipend', 'pl', 'Interest on savings account for stipend', NULL),
(437, '6S/408/001', 'Time Barred Cheques for Stipend', 'credit', 'income', 'Other Income For Stipend', 'pl', 'Time Barred Cheques for Stipend', NULL),
(438, '7S/308/001', 'other Administrative Expenses and bank commission for stipend', 'credit', 'income', 'Administrative and general expenses  For Stipend', 'pl', 'other Administrative Expenses and bank commission for stipend', NULL),
(439, '8S/001', 'Bank Charges For Stipend', 'credit', 'income', 'Finance Cost for Stipend', 'pl', 'Bank Charges For Stipend', NULL),
(440, '4S/000/002', 'Interest Earned For Stipend', 'credit', 'income', 'Grant & Subsidies', 'pl', 'Interest Earned For Stipend', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `company_name` varchar(222) DEFAULT NULL,
  `company_address` varchar(1000) DEFAULT NULL,
  `company_pan` varchar(222) DEFAULT NULL,
  `company_phone` varchar(255) NOT NULL,
  `company_fax` varchar(255) DEFAULT NULL,
  `company_web` varchar(255) DEFAULT NULL,
  `company_mail` varchar(255) DEFAULT NULL,
  `company_cin` varchar(255) NOT NULL,
  `company_gstin` varchar(255) DEFAULT NULL,
  `company_cgst` varchar(255) DEFAULT NULL,
  `company_sgst` varchar(255) DEFAULT NULL,
  `company_igst` varchar(255) DEFAULT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `company_status` varchar(10) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `company_name`, `company_address`, `company_pan`, `company_phone`, `company_fax`, `company_web`, `company_mail`, `company_cin`, `company_gstin`, `company_cgst`, `company_sgst`, `company_igst`, `company_logo`, `updated_at`, `created_at`, `company_status`) VALUES
(1, 'Board of Practical Training (Eastern Region) Under Ministry of HRD, Government of India', 'Plot No. - 7, Block EA, Sector-I, Opposite Labony Estate, Salt Lake City, Kolkata-700064', 'n', '033-147852369', 'BOPT', 'www.bopter.gov.in', 'info@boter.gov.in', 'UT9788978655454679856', '23423DGD5464564557GJFD56', '1', '1', '1', 'company_logo/ciPHYGos8qpQfKv9HtaQUlB6zdu4dBuQ0jAV5RQk.png', '2019-07-16 05:41:26', '2019-04-09 03:48:27', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `company_bank`
--

CREATE TABLE `company_bank` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `micr_code` varchar(20) DEFAULT NULL,
  `opening_balance` int(11) DEFAULT NULL,
  `financial_year` varchar(20) DEFAULT NULL,
  `bank_status` varchar(10) NOT NULL DEFAULT 'active',
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `account_code` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_bank`
--

INSERT INTO `company_bank` (`id`, `bank_name`, `branch_name`, `ifsc_code`, `micr_code`, `opening_balance`, `financial_year`, `bank_status`, `updated_at`, `created_at`, `account_code`) VALUES
(1, 'Canara Bank', 'Salt Lake City, Kolkata', 'CNRB0002549', '700015036', 19969697, '2019-2020', 'active', '2019-11-06 07:47:17.177196', '2019-11-06 07:47:17.177196', '07/003/003'),
(2, 'State Bank of India', 'Salt Lake', 'SBIN0001612', '700002145', 5000000, '2019-2020', 'active', '2019-11-06 07:49:49.317963', '2019-11-06 07:49:49.317963', '07/003/003'),
(3, 'HDFC Bank', 'Kalyani', 'SBIN0015443', 'MICR98654', 1, '2019-2020', 'active', '2019-11-22 10:50:54.861553', '2019-11-22 10:50:54.861553', '07/003/001');

-- --------------------------------------------------------

--
-- Table structure for table `company_cash`
--

CREATE TABLE `company_cash` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `opening_balance` int(11) DEFAULT NULL,
  `financial_year` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company_cash`
--

INSERT INTO `company_cash` (`id`, `name`, `opening_balance`, `financial_year`, `created_at`, `updated_at`) VALUES
(1, 'Cash in hand', 100000, '2019-2020', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `company_petty`
--

CREATE TABLE `company_petty` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `opening_balance` int(11) DEFAULT NULL,
  `financial_year` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company_petty`
--

INSERT INTO `company_petty` (`id`, `name`, `opening_balance`, `financial_year`, `created_at`, `updated_at`) VALUES
(1, 'Petty Cash', 100000, '2019-2020', '2019-11-26 18:26:48', '2019-11-26 18:26:48');

-- --------------------------------------------------------

--
-- Table structure for table `dak_final_details`
--

CREATE TABLE `dak_final_details` (
  `id` int(10) NOT NULL,
  `dak_receipt_detail_id` int(10) DEFAULT NULL,
  `dak_forward_no` varchar(30) NOT NULL,
  `status` enum('receipt','forward','reject','accept','closed','open') NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  `closing_remarks` varchar(200) DEFAULT NULL,
  `closing_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dak_final_details`
--

INSERT INTO `dak_final_details` (`id`, `dak_receipt_detail_id`, `dak_forward_no`, `status`, `reason`, `closing_remarks`, `closing_date`, `created_at`, `updated_at`) VALUES
(3, 36, 'BOPT/DAK/FINAL/-2019-08-19 11:', 'accept', NULL, NULL, NULL, '2019-08-19 11:30:47', '0000-00-00 00:00:00'),
(4, 1, 'BOPT/DAK/FINAL/-2019-08-20 07:', 'closed', NULL, 'action initiated', '2019-08-19', '2019-08-20 07:13:18', '2019-08-20 07:14:32'),
(5, 37, 'BOPT/DAK/FINAL/-2019-08-21 06:', 'closed', NULL, 'test', NULL, '2019-08-21 06:43:19', '2019-08-21 06:46:16'),
(6, 10, 'BOPT/DAK/FINAL/-2019-09-02 12:', 'closed', NULL, NULL, NULL, '2019-09-02 12:09:16', '2019-09-02 12:11:04'),
(7, 11, 'BOPT/DAK/FINAL/-2019-09-02 12:', 'closed', NULL, NULL, NULL, '2019-09-02 12:09:49', '2019-09-02 12:30:17'),
(8, 54, 'BOPT/DAK/FINAL/-2019-09-30 11:', 'closed', NULL, NULL, NULL, '2019-09-30 11:49:08', '2019-09-30 11:51:39');

-- --------------------------------------------------------

--
-- Table structure for table `dak_forward_details`
--

CREATE TABLE `dak_forward_details` (
  `id` int(10) NOT NULL,
  `dak_receipt_detail_id` int(10) NOT NULL,
  `dak_forward_no` varchar(30) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `deptment_id` int(10) NOT NULL,
  `dak_status` enum('receipt','forward','reject','accept','closed','open') NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dak_forward_details`
--

INSERT INTO `dak_forward_details` (`id`, `dak_receipt_detail_id`, `dak_forward_no`, `emp_id`, `deptment_id`, `dak_status`, `updated_at`, `created_at`) VALUES
(1, 1, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'closed', '2019-08-20 07:14:33', '2019-08-16 02:10:21'),
(2, 4, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'forward', '2019-08-16 07:50:43', '2019-08-16 02:20:43'),
(3, 5, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'forward', '2019-08-16 07:58:41', '2019-08-16 02:28:41'),
(4, 6, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'forward', '2019-08-16 09:01:10', '2019-08-16 03:31:10'),
(5, 7, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'reject', '2019-08-16 09:43:13', '2019-08-16 03:42:49'),
(6, 7, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'reject', '2019-08-16 09:43:13', '2019-08-16 03:42:49'),
(7, 8, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'forward', '2019-08-16 09:20:21', '2019-08-16 03:50:21'),
(8, 7, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'forward', '2019-08-16 09:44:20', '2019-08-16 04:14:20'),
(9, 9, 'BOPT/DAK/FORWARD/-2019-08-16 0', 7657, 0, 'forward', '2019-08-16 09:45:18', '2019-08-16 04:15:18'),
(10, 10, 'BOPT/DAK/FORWARD/-2019-08-16 0', 3020, 0, 'closed', '2019-09-02 12:11:04', '2019-08-16 04:22:40'),
(11, 11, 'BOPT/DAK/FORWARD/-2019-08-16 1', 3020, 0, 'closed', '2019-09-02 12:30:17', '2019-08-16 04:35:15'),
(12, 12, 'BOPT/DAK/FORWARD/-2019-08-16 1', 1530, 0, 'forward', '2019-08-16 10:09:16', '2019-08-16 04:39:16'),
(13, 13, 'BOPT/DAK/FORWARD/-2019-08-16 1', 1530, 0, 'forward', '2019-08-16 10:17:35', '2019-08-16 04:47:35'),
(14, 14, 'BOPT/DAK/FORWARD/-2019-08-16 1', 1530, 0, 'forward', '2019-08-16 10:25:39', '2019-08-16 04:55:39'),
(15, 15, 'BOPT/DAK/FORWARD/-2019-08-16 1', 1530, 0, 'forward', '2019-08-16 10:28:58', '2019-08-16 04:58:58'),
(16, 16, 'BOPT/DAK/FORWARD/-2019-08-16 1', 1530, 0, 'forward', '2019-08-16 10:35:20', '2019-08-16 05:05:20'),
(17, 17, 'BOPT/DAK/FORWARD/-2019-08-16 1', 1530, 0, 'forward', '2019-08-16 10:43:25', '2019-08-16 05:13:25'),
(18, 18, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 10:53:31', '2019-08-16 05:23:31'),
(19, 19, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 10:58:06', '2019-08-16 05:28:06'),
(20, 20, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:02:23', '2019-08-16 05:32:23'),
(21, 21, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:11:17', '2019-08-16 05:41:17'),
(22, 22, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:16:37', '2019-08-16 05:46:37'),
(23, 23, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:20:38', '2019-08-16 05:50:38'),
(24, 24, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:24:43', '2019-08-16 05:54:43'),
(25, 25, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:27:25', '2019-08-16 05:57:25'),
(26, 26, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:31:30', '2019-08-16 06:01:30'),
(27, 27, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:34:59', '2019-08-16 06:04:59'),
(28, 28, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:42:40', '2019-08-16 06:12:40'),
(29, 29, 'BOPT/DAK/FORWARD/-2019-08-16 1', 5408, 0, 'forward', '2019-08-16 11:45:51', '2019-08-16 06:15:51'),
(30, 30, 'BOPT/DAK/FORWARD/-2019-08-16 1', 4238, 0, 'forward', '2019-08-16 12:02:33', '2019-08-16 06:32:33'),
(31, 31, 'BOPT/DAK/FORWARD/-2019-08-16 1', 4238, 0, 'forward', '2019-08-16 12:05:53', '2019-08-16 06:35:53'),
(32, 32, 'BOPT/DAK/FORWARD/-2019-08-16 1', 4238, 0, 'forward', '2019-08-16 12:07:41', '2019-08-16 06:37:41'),
(35, 36, 'BOPT/DAK/FORWARD/-2019-08-19 1', 9556, 0, 'accept', '2019-08-19 11:30:47', '2019-08-19 06:00:28'),
(36, 37, 'BOPT/DAK/FORWARD/-2019-08-21 0', 9556, 0, 'closed', '2019-08-21 06:46:16', '2019-08-21 01:13:05'),
(37, 38, 'BOPT/DAK/FORWARD/-1566467643', 9556, 0, 'reject', '2019-09-25 11:56:42', '2019-08-22 04:24:03'),
(38, 39, 'BOPT/DAK/FORWARD/-1566468477', 9556, 0, 'reject', '2019-09-25 11:57:36', '2019-08-22 04:37:57'),
(39, 34, 'BOPT/DAK/FORWARD/-1566890569', 5408, 0, 'forward', '2019-08-27 07:22:49', '2019-08-27 01:52:49'),
(40, 35, 'BOPT/DAK/FORWARD/-1566890763', 5408, 0, 'forward', '2019-08-27 07:26:03', '2019-08-27 01:56:03'),
(41, 36, 'BOPT/DAK/FORWARD/-1566891021', 5408, 0, 'forward', '2019-08-27 07:30:21', '2019-08-27 02:00:21'),
(42, 37, 'BOPT/DAK/FORWARD/-1566891549', 5408, 0, 'forward', '2019-08-27 07:39:09', '2019-08-27 02:09:09'),
(43, 38, 'BOPT/DAK/FORWARD/-1566891856', 5408, 0, 'reject', '2019-09-25 11:56:42', '2019-08-27 02:14:16'),
(44, 39, 'BOPT/DAK/FORWARD/-1566892167', 5408, 0, 'reject', '2019-09-25 11:57:36', '2019-08-27 02:19:27'),
(45, 40, 'BOPT/DAK/FORWARD/-1566892588', 5408, 0, 'forward', '2019-08-27 07:56:28', '2019-08-27 02:26:28'),
(46, 40, 'BOPT/DAK/FORWARD/-1566892589', 5408, 0, 'forward', '2019-08-27 07:56:29', '2019-08-27 02:26:29'),
(47, 41, 'BOPT/DAK/FORWARD/-1571384921', 5408, 0, 'forward', '2019-10-18 07:48:41', '2019-10-18 02:18:41'),
(48, 42, 'BOPT/DAK/FORWARD/-1571385153', 1530, 0, 'forward', '2019-10-18 07:52:33', '2019-10-18 02:22:33'),
(49, 44, 'BOPT/DAK/FORWARD/-1571385261', 1530, 0, 'forward', '2019-10-18 07:54:21', '2019-10-18 02:24:21'),
(50, 45, 'BOPT/DAK/FORWARD/-1571385482', 3020, 0, 'forward', '2019-10-18 07:58:02', '2019-10-18 02:28:02'),
(51, 46, 'BOPT/DAK/FORWARD/-1571385681', 3020, 0, 'forward', '2019-10-18 08:01:21', '2019-10-18 02:31:21'),
(52, 48, 'BOPT/DAK/FORWARD/-1571642817', 5408, 0, 'forward', '2019-10-21 07:26:57', '2019-10-21 01:56:57'),
(53, 49, 'BOPT/DAK/FORWARD/-1571643294', 1530, 0, 'forward', '2019-10-21 07:34:54', '2019-10-21 02:04:54'),
(54, 50, 'BOPT/DAK/FORWARD/-1571644055', 7657, 0, 'forward', '2019-10-21 07:47:35', '2019-10-21 02:17:35'),
(55, 51, 'BOPT/DAK/FORWARD/-1571644679', 7657, 0, 'forward', '2019-10-21 07:57:59', '2019-10-21 02:27:59'),
(56, 52, 'BOPT/DAK/FORWARD/-1571644973', 7657, 0, 'forward', '2019-10-21 08:02:53', '2019-10-21 02:32:53'),
(57, 53, 'BOPT/DAK/FORWARD/-1571648832', 3020, 0, 'forward', '2019-10-21 09:07:12', '2019-10-21 03:37:12'),
(58, 54, 'BOPT/DAK/FORWARD/-1571649228', 3020, 0, 'closed', '2019-09-30 11:51:39', '2019-10-21 03:43:48'),
(59, 55, 'BOPT/DAK/FORWARD/-1571649546', 3020, 0, 'forward', '2019-10-21 09:19:06', '2019-10-21 03:49:06'),
(60, 56, 'BOPT/DAK/FORWARD/-1571650049', 3020, 0, 'forward', '2019-10-21 09:27:29', '2019-10-21 03:57:29'),
(61, 57, 'BOPT/DAK/FORWARD/-1571650465', 3020, 0, 'forward', '2019-10-21 09:34:25', '2019-10-21 04:04:25'),
(62, 58, 'BOPT/DAK/FORWARD/-1571651582', 3020, 0, 'forward', '2019-10-21 09:53:02', '2019-10-21 04:23:02'),
(63, 59, 'BOPT/DAK/FORWARD/-1561967058', 3020, 0, 'forward', '2019-07-01 07:44:18', '2019-07-01 02:14:18'),
(64, 60, 'BOPT/DAK/FORWARD/-1561967439', 3020, 0, 'forward', '2019-07-01 07:50:39', '2019-07-01 02:20:39'),
(65, 61, 'BOPT/DAK/FORWARD/-1561967627', 3020, 0, 'forward', '2019-07-01 07:53:47', '2019-07-01 02:23:47'),
(66, 62, 'BOPT/DAK/FORWARD/-1561967874', 3020, 0, 'forward', '2019-07-01 07:57:54', '2019-07-01 02:27:54'),
(67, 63, 'BOPT/DAK/FORWARD/-1561968160', 3020, 0, 'forward', '2019-07-01 08:02:40', '2019-07-01 02:32:40'),
(68, 64, 'BOPT/DAK/FORWARD/-1561972774', 3020, 0, 'forward', '2019-07-01 09:19:34', '2019-07-01 03:49:34'),
(69, 65, 'BOPT/DAK/FORWARD/-1561973910', 7657, 0, 'forward', '2019-07-01 09:38:30', '2019-07-01 04:08:30'),
(70, 66, 'BOPT/DAK/FORWARD/-1561975175', 3377, 0, 'forward', '2019-07-01 09:59:35', '2019-07-01 04:29:35'),
(71, 67, 'BOPT/DAK/FORWARD/-1571900607', 5408, 0, 'forward', '2019-10-24 07:03:27', '2019-10-24 01:33:27'),
(72, 68, 'BOPT/DAK/FORWARD/-1571900984', 5408, 0, 'forward', '2019-10-24 07:09:44', '2019-10-24 01:39:44'),
(73, 69, 'BOPT/DAK/FORWARD/-1571901251', 7657, 0, 'forward', '2019-10-24 07:14:11', '2019-10-24 01:44:11'),
(74, 70, 'BOPT/DAK/FORWARD/-1571901637', 3020, 0, 'forward', '2019-10-24 07:20:37', '2019-10-24 01:50:37'),
(75, 71, 'BOPT/DAK/FORWARD/-1571901925', 3020, 0, 'forward', '2019-10-24 07:25:25', '2019-10-24 01:55:25'),
(76, 72, 'BOPT/DAK/FORWARD/-1571902316', 3020, 0, 'forward', '2019-10-24 07:31:56', '2019-10-24 02:01:56'),
(77, 73, 'BOPT/DAK/FORWARD/-1571902694', 3020, 0, 'forward', '2019-10-24 07:38:14', '2019-10-24 02:08:14'),
(78, 74, 'BOPT/DAK/FORWARD/-1571903195', 4238, 0, 'forward', '2019-10-24 07:46:35', '2019-10-24 02:16:35'),
(79, 75, 'BOPT/DAK/FORWARD/-1571903493', 4238, 0, 'forward', '2019-10-24 07:51:33', '2019-10-24 02:21:33'),
(80, 76, 'BOPT/DAK/FORWARD/-1571903619', 4238, 0, 'forward', '2019-10-24 07:53:39', '2019-10-24 02:23:39'),
(81, 77, 'BOPT/DAK/FORWARD/-1571903944', 4238, 0, 'forward', '2019-10-24 07:59:04', '2019-10-24 02:29:04'),
(82, 78, 'BOPT/DAK/FORWARD/-1571904454', 3377, 0, 'forward', '2019-10-24 08:07:34', '2019-10-24 02:37:34'),
(83, 79, 'BOPT/DAK/FORWARD/-1572325223', 3377, 0, 'forward', '2019-10-29 05:00:23', '2019-10-28 23:30:23'),
(84, 80, 'BOPT/DAK/FORWARD/-1572325491', 3377, 0, 'forward', '2019-10-29 05:04:51', '2019-10-28 23:34:51'),
(85, 81, 'BOPT/DAK/FORWARD/-1572325734', 3377, 0, 'forward', '2019-10-29 05:08:54', '2019-10-28 23:38:54'),
(86, 82, 'BOPT/DAK/FORWARD/-1572326000', 3377, 0, 'forward', '2019-10-29 05:13:20', '2019-10-28 23:43:20'),
(87, 83, 'BOPT/DAK/FORWARD/-1572326297', 3377, 0, 'forward', '2019-10-29 05:18:17', '2019-10-28 23:48:17'),
(88, 85, 'BOPT/DAK/FORWARD/-1572326469', 3020, 0, 'forward', '2019-10-29 05:21:09', '2019-10-28 23:51:09'),
(89, 86, 'BOPT/DAK/FORWARD/-1572326668', 3020, 0, 'forward', '2019-10-29 05:24:28', '2019-10-28 23:54:28'),
(90, 87, 'BOPT/DAK/FORWARD/-1572326891', 3181, 0, 'forward', '2019-10-29 05:28:11', '2019-10-28 23:58:11'),
(91, 88, 'BOPT/DAK/FORWARD/-1572327223', 3181, 0, 'forward', '2019-10-29 05:33:43', '2019-10-29 00:03:43'),
(92, 89, 'BOPT/DAK/FORWARD/-1572327424', 3181, 0, 'forward', '2019-10-29 05:37:04', '2019-10-29 00:07:04'),
(93, 90, 'BOPT/DAK/FORWARD/-1572327833', 5408, 0, 'forward', '2019-10-29 05:43:53', '2019-10-29 00:13:53'),
(94, 91, 'BOPT/DAK/FORWARD/-1572328598', 5408, 0, 'forward', '2019-10-29 05:56:38', '2019-10-29 00:26:38'),
(95, 92, 'BOPT/DAK/FORWARD/-1572329191', 5408, 0, 'forward', '2019-10-29 06:06:31', '2019-10-29 00:36:31'),
(96, 93, 'BOPT/DAK/FORWARD/-1572329650', 1530, 0, 'forward', '2019-10-29 06:14:10', '2019-10-29 00:44:10'),
(97, 94, 'BOPT/DAK/FORWARD/-1572329971', 1530, 0, 'forward', '2019-10-29 06:19:31', '2019-10-29 00:49:31'),
(98, 95, 'BOPT/DAK/FORWARD/-1572331372', 7657, 0, 'forward', '2019-10-29 06:42:52', '2019-10-29 01:12:52'),
(99, 96, 'BOPT/DAK/FORWARD/-1572331540', 7657, 0, 'forward', '2019-10-29 06:45:40', '2019-10-29 01:15:40'),
(100, 97, 'BOPT/DAK/FORWARD/-1572331757', 7657, 0, 'forward', '2019-10-29 06:49:17', '2019-10-29 01:19:17'),
(101, 98, 'BOPT/DAK/FORWARD/-1572331993', 7657, 0, 'forward', '2019-10-29 06:53:13', '2019-10-29 01:23:13'),
(102, 99, 'BOPT/DAK/FORWARD/-1572586114', 5408, 0, 'forward', '2019-11-01 05:28:34', '2019-10-31 23:58:34'),
(103, 100, 'BOPT/DAK/FORWARD/-1572586428', 5408, 0, 'forward', '2019-11-01 05:33:48', '2019-11-01 00:03:48'),
(104, 101, 'BOPT/DAK/FORWARD/-1572586992', 5408, 0, 'forward', '2019-11-01 05:43:12', '2019-11-01 00:13:12'),
(105, 102, 'BOPT/DAK/FORWARD/-1572587292', 5408, 0, 'forward', '2019-11-01 05:48:12', '2019-11-01 00:18:12'),
(106, 103, 'BOPT/DAK/FORWARD/-1572587779', 7657, 0, 'forward', '2019-11-01 05:56:19', '2019-11-01 00:26:19'),
(107, 104, 'BOPT/DAK/FORWARD/-1572588486', 7657, 0, 'forward', '2019-11-01 06:08:06', '2019-11-01 00:38:06'),
(108, 105, 'BOPT/DAK/FORWARD/-1572588817', 7657, 0, 'forward', '2019-11-01 06:13:37', '2019-11-01 00:43:37'),
(109, 106, 'BOPT/DAK/FORWARD/-1572589160', 7657, 0, 'forward', '2019-11-01 06:19:20', '2019-11-01 00:49:20'),
(110, 107, 'BOPT/DAK/FORWARD/-1572589517', 3020, 0, 'forward', '2019-11-01 06:25:17', '2019-11-01 00:55:17'),
(111, 108, 'BOPT/DAK/FORWARD/-1572590087', 3020, 0, 'forward', '2019-11-01 06:34:47', '2019-11-01 01:04:47'),
(112, 109, 'BOPT/DAK/FORWARD/-1572590877', 3020, 0, 'forward', '2019-11-01 06:47:57', '2019-11-01 01:17:57'),
(113, 110, 'BOPT/DAK/FORWARD/-1572591148', 3020, 0, 'forward', '2019-11-01 06:52:28', '2019-11-01 01:22:28'),
(114, 111, 'BOPT/DAK/FORWARD/-1572591453', 3020, 0, 'forward', '2019-11-01 06:57:33', '2019-11-01 01:27:33'),
(115, 112, 'BOPT/DAK/FORWARD/-1572591763', 3020, 0, 'forward', '2019-11-01 07:02:43', '2019-11-01 01:32:43'),
(116, 113, 'BOPT/DAK/FORWARD/-1572592235', 3020, 0, 'forward', '2019-11-01 07:10:35', '2019-11-01 01:40:35'),
(117, 114, 'BOPT/DAK/FORWARD/-1572592925', 3181, 0, 'forward', '2019-11-01 07:22:05', '2019-11-01 01:52:05'),
(118, 115, 'BOPT/DAK/FORWARD/-1572593141', 3181, 0, 'forward', '2019-11-01 07:25:41', '2019-11-01 01:55:41'),
(119, 116, 'BOPT/DAK/FORWARD/-1572593352', 3181, 0, 'forward', '2019-11-01 07:29:12', '2019-11-01 01:59:12'),
(120, 117, 'BOPT/DAK/FORWARD/-1572593894', 3377, 0, 'forward', '2019-11-01 07:38:14', '2019-11-01 02:08:14'),
(121, 118, 'BOPT/DAK/FORWARD/-1574932260', 5408, 0, 'forward', '2019-11-28 09:11:00', '2019-11-28 03:41:00'),
(122, 119, 'BOPT/DAK/FORWARD/-1574932591', 1530, 0, 'forward', '2019-11-28 09:16:31', '2019-11-28 03:46:31'),
(123, 120, 'BOPT/DAK/FORWARD/-1574932715', 1530, 0, 'forward', '2019-11-28 09:18:35', '2019-11-28 03:48:35'),
(124, 121, 'BOPT/DAK/FORWARD/-1574933078', 7657, 0, 'forward', '2019-11-28 09:24:38', '2019-11-28 03:54:38'),
(125, 122, 'BOPT/DAK/FORWARD/-1574933250', 7657, 0, 'forward', '2019-11-28 09:27:30', '2019-11-28 03:57:30'),
(126, 123, 'BOPT/DAK/FORWARD/-1574933404', 7657, 0, 'forward', '2019-11-28 09:30:04', '2019-11-28 04:00:04'),
(127, 124, 'BOPT/DAK/FORWARD/-1574933549', 7657, 0, 'forward', '2019-11-28 09:32:29', '2019-11-28 04:02:29'),
(128, 125, 'BOPT/DAK/FORWARD/-1575010066', 5408, 0, 'forward', '2019-11-29 06:47:46', '2019-11-29 01:17:46'),
(129, 126, 'BOPT/DAK/FORWARD/-1575010775', 5408, 0, 'forward', '2019-11-29 06:59:35', '2019-11-29 01:29:35'),
(130, 127, 'BOPT/DAK/FORWARD/-1575011012', 1530, 0, 'forward', '2019-11-29 07:03:32', '2019-11-29 01:33:32'),
(131, 128, 'BOPT/DAK/FORWARD/-1575011312', 1530, 0, 'forward', '2019-11-29 07:08:32', '2019-11-29 01:38:32'),
(132, 129, 'BOPT/DAK/FORWARD/-1575011611', 7657, 0, 'forward', '2019-11-29 07:13:31', '2019-11-29 01:43:31'),
(133, 130, 'BOPT/DAK/FORWARD/-1575013155', 7657, 0, 'forward', '2019-11-29 07:39:15', '2019-11-29 02:09:15'),
(134, 131, 'BOPT/DAK/FORWARD/-1575013284', 3020, 0, 'forward', '2019-11-29 07:41:24', '2019-11-29 02:11:24'),
(135, 132, 'BOPT/DAK/FORWARD/-1575013397', 3020, 0, 'forward', '2019-11-29 07:43:17', '2019-11-29 02:13:17'),
(136, 133, 'BOPT/DAK/FORWARD/-1575013557', 3020, 0, 'forward', '2019-11-29 07:45:57', '2019-11-29 02:15:57'),
(137, 134, 'BOPT/DAK/FORWARD/-1575013615', 3020, 0, 'forward', '2019-11-29 07:46:55', '2019-11-29 02:16:55'),
(138, 135, 'BOPT/DAK/FORWARD/-1575013923', 3020, 0, 'forward', '2019-11-29 07:52:03', '2019-11-29 02:22:03'),
(139, 136, 'BOPT/DAK/FORWARD/-1575014208', 3020, 0, 'forward', '2019-11-29 07:56:48', '2019-11-29 02:26:48'),
(140, 137, 'BOPT/DAK/FORWARD/-1575014460', 3020, 0, 'forward', '2019-11-29 08:01:00', '2019-11-29 02:31:00'),
(141, 138, 'BOPT/DAK/FORWARD/-1575014591', 3020, 0, 'forward', '2019-11-29 08:03:11', '2019-11-29 02:33:11'),
(142, 139, 'BOPT/DAK/FORWARD/-1575014685', 3181, 0, 'forward', '2019-11-29 08:04:45', '2019-11-29 02:34:45'),
(143, 140, 'BOPT/DAK/FORWARD/-1576134073', 1530, 0, 'forward', '2019-12-12 07:01:13', '2019-12-12 01:31:13'),
(144, 141, 'BOPT/DAK/FORWARD/-1576134165', 1530, 0, 'forward', '2019-12-12 07:02:45', '2019-12-12 01:32:45'),
(145, 142, 'BOPT/DAK/FORWARD/-1576134563', 7657, 0, 'forward', '2019-12-12 07:09:23', '2019-12-12 01:39:23'),
(146, 143, 'BOPT/DAK/FORWARD/-1576134678', 7657, 0, 'forward', '2019-12-12 07:11:18', '2019-12-12 01:41:18'),
(147, 144, 'BOPT/DAK/FORWARD/-1576134786', 3020, 0, 'forward', '2019-12-12 07:13:06', '2019-12-12 01:43:06'),
(148, 145, 'BOPT/DAK/FORWARD/-1576134955', 3020, 0, 'forward', '2019-12-12 07:15:55', '2019-12-12 01:45:55'),
(149, 146, 'BOPT/DAK/FORWARD/-1576135048', 3020, 0, 'forward', '2019-12-12 07:17:28', '2019-12-12 01:47:28'),
(150, 147, 'BOPT/DAK/FORWARD/-1576135145', 3020, 0, 'forward', '2019-12-12 07:19:05', '2019-12-12 01:49:05'),
(151, 148, 'BOPT/DAK/FORWARD/-1576135244', 3020, 0, 'forward', '2019-12-12 07:20:44', '2019-12-12 01:50:44'),
(152, 149, 'BOPT/DAK/FORWARD/-1576135369', 3020, 0, 'forward', '2019-12-12 07:22:49', '2019-12-12 01:52:49'),
(153, 150, 'BOPT/DAK/FORWARD/-1576135553', 3020, 0, 'forward', '2019-12-12 07:25:53', '2019-12-12 01:55:53'),
(154, 151, 'BOPT/DAK/FORWARD/-1576135796', 3377, 0, 'forward', '2019-12-12 07:29:56', '2019-12-12 01:59:56'),
(155, 152, 'BOPT/DAK/FORWARD/-1576135972', 3377, 0, 'forward', '2019-12-12 07:32:52', '2019-12-12 02:02:52'),
(156, 153, 'BOPT/DAK/FORWARD/-1576136169', 3377, 0, 'forward', '2019-12-12 07:36:09', '2019-12-12 02:06:09'),
(157, 154, 'BOPT/DAK/FORWARD/-1576136311', 3377, 0, 'forward', '2019-12-12 07:38:31', '2019-12-12 02:08:31'),
(158, 155, 'BOPT/DAK/FORWARD/-1576136397', 3377, 0, 'forward', '2019-12-12 07:39:57', '2019-12-12 02:09:57'),
(159, 156, 'BOPT/DAK/FORWARD/-1576136506', 3377, 0, 'forward', '2019-12-12 07:41:46', '2019-12-12 02:11:46'),
(160, 157, 'BOPT/DAK/FORWARD/-1576482855', 5408, 0, 'forward', '2019-12-16 07:54:15', '2019-12-16 02:24:15'),
(161, 158, 'BOPT/DAK/FORWARD/-1576482939', 1530, 0, 'forward', '2019-12-16 07:55:39', '2019-12-16 02:25:39'),
(162, 159, 'BOPT/DAK/FORWARD/-1576483005', 1530, 0, 'forward', '2019-12-16 07:56:45', '2019-12-16 02:26:45'),
(163, 160, 'BOPT/DAK/FORWARD/-1576487365', 3020, 0, 'forward', '2019-12-16 09:09:25', '2019-12-16 03:39:25'),
(164, 161, 'BOPT/DAK/FORWARD/-1576487504', 3020, 0, 'forward', '2019-12-16 09:11:44', '2019-12-16 03:41:44'),
(165, 162, 'BOPT/DAK/FORWARD/-1576487580', 3020, 0, 'forward', '2019-12-16 09:13:00', '2019-12-16 03:43:00'),
(166, 163, 'BOPT/DAK/FORWARD/-1576487727', 3020, 0, 'forward', '2019-12-16 09:15:27', '2019-12-16 03:45:27'),
(167, 164, 'BOPT/DAK/FORWARD/-1576487858', 3020, 0, 'forward', '2019-12-16 09:17:38', '2019-12-16 03:47:38'),
(168, 165, 'BOPT/DAK/FORWARD/-1576488430', 3020, 0, 'forward', '2019-12-16 09:27:10', '2019-12-16 03:57:09'),
(169, 166, 'BOPT/DAK/FORWARD/-1576488567', 3020, 0, 'forward', '2019-12-16 09:29:27', '2019-12-16 03:59:27'),
(170, 167, 'BOPT/DAK/FORWARD/-1576488776', 3020, 0, 'forward', '2019-12-16 09:32:56', '2019-12-16 04:02:56'),
(171, 168, 'BOPT/DAK/FORWARD/-1576488903', 3020, 0, 'forward', '2019-12-16 09:35:03', '2019-12-16 04:05:03'),
(172, 169, 'BOPT/DAK/FORWARD/-1576488986', 3020, 0, 'forward', '2019-12-16 09:36:26', '2019-12-16 04:06:25'),
(173, 170, 'BOPT/DAK/FORWARD/-1576489254', 3020, 0, 'forward', '2019-12-16 09:40:54', '2019-12-16 04:10:54'),
(174, 171, 'BOPT/DAK/FORWARD/-1576489410', 3181, 0, 'forward', '2019-12-16 09:43:30', '2019-12-16 04:13:30'),
(175, 172, 'BOPT/DAK/FORWARD/-1576489521', 3181, 0, 'forward', '2019-12-16 09:45:21', '2019-12-16 04:15:21'),
(176, 173, 'BOPT/DAK/FORWARD/-1576489788', 3181, 0, 'forward', '2019-12-16 09:49:48', '2019-12-16 04:19:48'),
(177, 174, 'BOPT/DAK/FORWARD/-1576489949', 3377, 0, 'forward', '2019-12-16 09:52:29', '2019-12-16 04:22:29'),
(178, 175, 'BOPT/DAK/FORWARD/-1576663884', 5408, 0, 'forward', '2019-12-18 10:11:24', '2019-12-18 04:41:24'),
(179, 176, 'BOPT/DAK/FORWARD/-1576663972', 5408, 0, 'forward', '2019-12-18 10:12:52', '2019-12-18 04:42:52'),
(180, 177, 'BOPT/DAK/FORWARD/-1576664092', 1530, 0, 'forward', '2019-12-18 10:14:52', '2019-12-18 04:44:52'),
(181, 178, 'BOPT/DAK/FORWARD/-1576664240', 1530, 0, 'forward', '2019-12-18 10:17:20', '2019-12-18 04:47:20'),
(182, 179, 'BOPT/DAK/FORWARD/-1576664344', 7657, 0, 'forward', '2019-12-18 10:19:04', '2019-12-18 04:49:04'),
(183, 180, 'BOPT/DAK/FORWARD/-1576666742', 3020, 0, 'forward', '2019-12-18 10:59:02', '2019-12-18 05:29:02'),
(184, 181, 'BOPT/DAK/FORWARD/-1576666813', 3020, 0, 'forward', '2019-12-18 11:00:13', '2019-12-18 05:30:13'),
(185, 182, 'BOPT/DAK/FORWARD/-1576733952', 3020, 0, 'forward', '2019-12-19 05:39:12', '2019-12-19 00:09:12'),
(186, 183, 'BOPT/DAK/FORWARD/-1576734199', 3020, 0, 'forward', '2019-12-19 05:43:19', '2019-12-19 00:13:19'),
(187, 184, 'BOPT/DAK/FORWARD/-1576734514', 3020, 0, 'forward', '2019-12-19 05:48:34', '2019-12-19 00:18:34'),
(188, 185, 'BOPT/DAK/FORWARD/-1576734624', 3020, 0, 'forward', '2019-12-19 05:50:24', '2019-12-19 00:20:24'),
(189, 186, 'BOPT/DAK/FORWARD/-1576734737', 3020, 0, 'forward', '2019-12-19 05:52:17', '2019-12-19 00:22:17'),
(190, 187, 'BOPT/DAK/FORWARD/-1576734835', 3020, 0, 'forward', '2019-12-19 05:53:55', '2019-12-19 00:23:55'),
(191, 188, 'BOPT/DAK/FORWARD/-1576734908', 3020, 0, 'forward', '2019-12-19 05:55:08', '2019-12-19 00:25:08'),
(192, 189, 'BOPT/DAK/FORWARD/-1576734989', 3020, 0, 'forward', '2019-12-19 05:56:29', '2019-12-19 00:26:29'),
(193, 190, 'BOPT/DAK/FORWARD/-1576735148', 3020, 0, 'forward', '2019-12-19 05:59:08', '2019-12-19 00:29:08'),
(194, 191, 'BOPT/DAK/FORWARD/-1576735245', 3020, 0, 'forward', '2019-12-19 06:00:45', '2019-12-19 00:30:45'),
(195, 192, 'BOPT/DAK/FORWARD/-1576735369', 3020, 0, 'forward', '2019-12-19 06:02:49', '2019-12-19 00:32:49'),
(196, 193, 'BOPT/DAK/FORWARD/-1576735452', 3020, 0, 'forward', '2019-12-19 06:04:12', '2019-12-19 00:34:12'),
(197, 194, 'BOPT/DAK/FORWARD/-1576735570', 3020, 0, 'forward', '2019-12-19 06:06:10', '2019-12-19 00:36:10'),
(198, 195, 'BOPT/DAK/FORWARD/-1576735677', 3181, 0, 'forward', '2019-12-19 06:07:57', '2019-12-19 00:37:57'),
(199, 196, 'BOPT/DAK/FORWARD/-1576735844', 3181, 0, 'forward', '2019-12-19 06:10:44', '2019-12-19 00:40:44'),
(200, 197, 'BOPT/DAK/FORWARD/-1577959437', 1530, 0, 'forward', '2020-01-02 10:03:57', '2020-01-02 04:33:57'),
(201, 198, 'BOPT/DAK/FORWARD/-1577959538', 1530, 0, 'forward', '2020-01-02 10:05:38', '2020-01-02 04:35:38'),
(202, 199, 'BOPT/DAK/FORWARD/-1577959633', 1530, 0, 'forward', '2020-01-02 10:07:13', '2020-01-02 04:37:13'),
(203, 200, 'BOPT/DAK/FORWARD/-1577959744', 7657, 0, 'forward', '2020-01-02 10:09:04', '2020-01-02 04:39:04'),
(204, 201, 'BOPT/DAK/FORWARD/-1577959886', 7657, 0, 'forward', '2020-01-02 10:11:26', '2020-01-02 04:41:26'),
(205, 202, 'BOPT/DAK/FORWARD/-1577959984', 3020, 0, 'forward', '2020-01-02 10:13:04', '2020-01-02 04:43:04'),
(206, 203, 'BOPT/DAK/FORWARD/-1577960091', 3020, 0, 'forward', '2020-01-02 10:14:51', '2020-01-02 04:44:51'),
(207, 204, 'BOPT/DAK/FORWARD/-1577960176', 3020, 0, 'forward', '2020-01-02 10:16:16', '2020-01-02 04:46:16'),
(208, 205, 'BOPT/DAK/FORWARD/-1577960272', 3020, 0, 'forward', '2020-01-02 10:17:52', '2020-01-02 04:47:52'),
(209, 206, 'BOPT/DAK/FORWARD/-1578389552', 5408, 0, 'forward', '2020-01-07 09:32:32', '2020-01-07 04:02:32'),
(210, 207, 'BOPT/DAK/FORWARD/-1578389645', 5408, 0, 'forward', '2020-01-07 09:34:05', '2020-01-07 04:04:05'),
(211, 208, 'BOPT/DAK/FORWARD/-1578389792', 1530, 0, 'forward', '2020-01-07 09:36:32', '2020-01-07 04:06:32'),
(212, 209, 'BOPT/DAK/FORWARD/-1578389913', 1530, 0, 'forward', '2020-01-07 09:38:33', '2020-01-07 04:08:33'),
(213, 210, 'BOPT/DAK/FORWARD/-1578390117', 7657, 0, 'forward', '2020-01-07 09:41:57', '2020-01-07 04:11:57'),
(214, 211, 'BOPT/DAK/FORWARD/-1578390347', 7657, 0, 'forward', '2020-01-07 09:45:47', '2020-01-07 04:15:47'),
(215, 212, 'BOPT/DAK/FORWARD/-1578390638', 7657, 0, 'forward', '2020-01-07 09:50:38', '2020-01-07 04:20:38'),
(216, 213, 'BOPT/DAK/FORWARD/-1578391130', 7657, 0, 'forward', '2020-01-07 09:58:50', '2020-01-07 04:28:50'),
(217, 214, 'BOPT/DAK/FORWARD/-1578391263', 7657, 0, 'forward', '2020-01-07 10:01:03', '2020-01-07 04:31:03'),
(218, 215, 'BOPT/DAK/FORWARD/-1578391339', 3020, 0, 'forward', '2020-01-07 10:02:19', '2020-01-07 04:32:19'),
(219, 216, 'BOPT/DAK/FORWARD/-1578391453', 3020, 0, 'forward', '2020-01-07 10:04:13', '2020-01-07 04:34:13'),
(220, 217, 'BOPT/DAK/FORWARD/-1578391587', 3020, 0, 'forward', '2020-01-07 10:06:27', '2020-01-07 04:36:27'),
(221, 218, 'BOPT/DAK/FORWARD/-1578391663', 3020, 0, 'forward', '2020-01-07 10:07:43', '2020-01-07 04:37:43'),
(222, 219, 'BOPT/DAK/FORWARD/-1578391836', 3020, 0, 'forward', '2020-01-07 10:10:36', '2020-01-07 04:40:36'),
(223, 220, 'BOPT/DAK/FORWARD/-1578391970', 3020, 0, 'forward', '2020-01-07 10:12:50', '2020-01-07 04:42:50'),
(224, 221, 'BOPT/DAK/FORWARD/-1578392104', 3181, 0, 'forward', '2020-01-07 10:15:04', '2020-01-07 04:45:04'),
(225, 222, 'BOPT/DAK/FORWARD/-1578392277', 3377, 0, 'forward', '2020-01-07 10:17:57', '2020-01-07 04:47:57'),
(226, 223, 'BOPT/DAK/FORWARD/-1578392513', 3377, 0, 'forward', '2020-01-07 10:21:53', '2020-01-07 04:51:53'),
(227, 224, 'BOPT/DAK/FORWARD/-1578392660', 3377, 0, 'forward', '2020-01-07 10:24:20', '2020-01-07 04:54:20'),
(228, 225, 'BOPT/DAK/FORWARD/-1578392833', 3377, 0, 'forward', '2020-01-07 10:27:13', '2020-01-07 04:57:13'),
(229, 226, 'BOPT/DAK/FORWARD/-1578392986', 4042, 0, 'forward', '2020-01-07 10:29:46', '2020-01-07 04:59:46'),
(230, 227, 'BOPT/DAK/FORWARD/-1578393145', 6654, 0, 'forward', '2020-01-07 10:32:25', '2020-01-07 05:02:25'),
(231, 228, 'BOPT/DAK/FORWARD/-1578641669', 5408, 0, 'forward', '2020-01-10 07:34:29', '2020-01-10 02:04:29'),
(232, 229, 'BOPT/DAK/FORWARD/-1578641747', 1530, 0, 'forward', '2020-01-10 07:35:47', '2020-01-10 02:05:47'),
(233, 230, 'BOPT/DAK/FORWARD/-1578641883', 1530, 0, 'forward', '2020-01-10 07:38:03', '2020-01-10 02:08:03'),
(234, 231, 'BOPT/DAK/FORWARD/-1578642064', 1530, 0, 'forward', '2020-01-10 07:41:04', '2020-01-10 02:11:04'),
(235, 232, 'BOPT/DAK/FORWARD/-1578642276', 7657, 0, 'forward', '2020-01-10 07:44:36', '2020-01-10 02:14:36'),
(236, 233, 'BOPT/DAK/FORWARD/-1578642356', 7657, 0, 'forward', '2020-01-10 07:45:56', '2020-01-10 02:15:56'),
(237, 234, 'BOPT/DAK/FORWARD/-1578642456', 3020, 0, 'forward', '2020-01-10 07:47:36', '2020-01-10 02:17:36'),
(238, 235, 'BOPT/DAK/FORWARD/-1578642606', 3020, 0, 'forward', '2020-01-10 07:50:06', '2020-01-10 02:20:06'),
(239, 236, 'BOPT/DAK/FORWARD/-1578642707', 3020, 0, 'forward', '2020-01-10 07:51:47', '2020-01-10 02:21:47'),
(240, 237, 'BOPT/DAK/FORWARD/-1578642776', 3020, 0, 'forward', '2020-01-10 07:52:56', '2020-01-10 02:22:56'),
(241, 238, 'BOPT/DAK/FORWARD/-1578642864', 3020, 0, 'forward', '2020-01-10 07:54:24', '2020-01-10 02:24:24'),
(242, 239, 'BOPT/DAK/FORWARD/-1578642951', 4042, 0, 'forward', '2020-01-10 07:55:51', '2020-01-10 02:25:51'),
(243, 240, 'BOPT/DAK/FORWARD/-1578643045', 4042, 0, 'forward', '2020-01-10 07:57:25', '2020-01-10 02:27:25'),
(244, 241, 'BOPT/DAK/FORWARD/-1578643112', 4042, 0, 'forward', '2020-01-10 07:58:32', '2020-01-10 02:28:32'),
(245, 242, 'BOPT/DAK/FORWARD/-1578643276', 3377, 0, 'forward', '2020-01-10 08:01:16', '2020-01-10 02:31:16'),
(246, 243, 'BOPT/DAK/FORWARD/-1578643338', 3377, 0, 'forward', '2020-01-10 08:02:18', '2020-01-10 02:32:18'),
(247, 244, 'BOPT/DAK/FORWARD/-1578643394', 3377, 0, 'forward', '2020-01-10 08:03:14', '2020-01-10 02:33:14'),
(248, 245, 'BOPT/DAK/FORWARD/-1579085247', 5408, 0, 'forward', '2020-01-15 10:47:27', '2020-01-15 05:17:27'),
(249, 246, 'BOPT/DAK/FORWARD/-1579085629', 5408, 0, 'forward', '2020-01-15 10:53:49', '2020-01-15 05:23:49'),
(250, 247, 'BOPT/DAK/FORWARD/-1579085736', 1530, 0, 'forward', '2020-01-15 10:55:36', '2020-01-15 05:25:36'),
(251, 248, 'BOPT/DAK/FORWARD/-1579085837', 1530, 0, 'forward', '2020-01-15 10:57:17', '2020-01-15 05:27:17'),
(252, 249, 'BOPT/DAK/FORWARD/-1579085980', 1530, 0, 'forward', '2020-01-15 10:59:40', '2020-01-15 05:29:40'),
(253, 250, 'BOPT/DAK/FORWARD/-1579086114', 1530, 0, 'forward', '2020-01-15 11:01:54', '2020-01-15 05:31:54'),
(254, 251, 'BOPT/DAK/FORWARD/-1579086320', 1530, 0, 'forward', '2020-01-15 11:05:20', '2020-01-15 05:35:20'),
(255, 252, 'BOPT/DAK/FORWARD/-1579086423', 7657, 0, 'forward', '2020-01-15 11:07:03', '2020-01-15 05:37:03'),
(256, 253, 'BOPT/DAK/FORWARD/-1579086530', 7657, 0, 'forward', '2020-01-15 11:08:50', '2020-01-15 05:38:50'),
(257, 254, 'BOPT/DAK/FORWARD/-1579089741', 7657, 0, 'forward', '2020-01-15 12:02:21', '2020-01-15 06:32:21'),
(258, 255, 'BOPT/DAK/FORWARD/-1579089889', 7657, 0, 'forward', '2020-01-15 12:04:49', '2020-01-15 06:34:49'),
(259, 256, 'BOPT/DAK/FORWARD/-1579089983', 7657, 0, 'forward', '2020-01-15 12:06:23', '2020-01-15 06:36:23'),
(260, 257, 'BOPT/DAK/FORWARD/-1579090075', 7657, 0, 'forward', '2020-01-15 12:07:55', '2020-01-15 06:37:55'),
(261, 258, 'BOPT/DAK/FORWARD/-1579090169', 7657, 0, 'forward', '2020-01-15 12:09:29', '2020-01-15 06:39:29'),
(262, 259, 'BOPT/DAK/FORWARD/-1579155452', 3020, 0, 'forward', '2020-01-16 06:17:32', '2020-01-16 00:47:32'),
(263, 260, 'BOPT/DAK/FORWARD/-1579155562', 3020, 0, 'forward', '2020-01-16 06:19:22', '2020-01-16 00:49:22'),
(264, 261, 'BOPT/DAK/FORWARD/-1579155644', 3020, 0, 'forward', '2020-01-16 06:20:44', '2020-01-16 00:50:44'),
(265, 262, 'BOPT/DAK/FORWARD/-1579155952', 3020, 0, 'forward', '2020-01-16 06:25:52', '2020-01-16 00:55:52'),
(266, 263, 'BOPT/DAK/FORWARD/-1579156446', 3020, 0, 'forward', '2020-01-16 06:34:06', '2020-01-16 01:04:06'),
(267, 264, 'BOPT/DAK/FORWARD/-1579156553', 3020, 0, 'forward', '2020-01-16 06:35:53', '2020-01-16 01:05:53'),
(268, 265, 'BOPT/DAK/FORWARD/-1579156618', 3020, 0, 'forward', '2020-01-16 06:36:58', '2020-01-16 01:06:58'),
(269, 266, 'BOPT/DAK/FORWARD/-1579156730', 3020, 0, 'forward', '2020-01-16 06:38:50', '2020-01-16 01:08:50'),
(270, 267, 'BOPT/DAK/FORWARD/-1579156820', 4042, 0, 'forward', '2020-01-16 06:40:20', '2020-01-16 01:10:20'),
(271, 268, 'BOPT/DAK/FORWARD/-1579263026', 5408, 0, 'forward', '2020-01-17 12:10:26', '2020-01-17 06:40:26'),
(272, 269, 'BOPT/DAK/FORWARD/-1579263108', 5408, 0, 'forward', '2020-01-17 12:11:48', '2020-01-17 06:41:48'),
(273, 270, 'BOPT/DAK/FORWARD/-1579263176', 1530, 0, 'forward', '2020-01-17 12:12:56', '2020-01-17 06:42:56'),
(274, 271, 'BOPT/DAK/FORWARD/-1579263248', 7657, 0, 'forward', '2020-01-17 12:14:08', '2020-01-17 06:44:08'),
(275, 272, 'BOPT/DAK/FORWARD/-1579263330', 7657, 0, 'forward', '2020-01-17 12:15:30', '2020-01-17 06:45:30'),
(276, 273, 'BOPT/DAK/FORWARD/-1579263419', 7657, 0, 'forward', '2020-01-17 12:16:59', '2020-01-17 06:46:59'),
(277, 274, 'BOPT/DAK/FORWARD/-1579498847', 7657, 0, 'forward', '2020-01-20 05:40:47', '2020-01-20 00:10:47'),
(278, 275, 'BOPT/DAK/FORWARD/-1579498968', 7657, 0, 'forward', '2020-01-20 05:42:48', '2020-01-20 00:12:48'),
(279, 276, 'BOPT/DAK/FORWARD/-1579499082', 7657, 0, 'forward', '2020-01-20 05:44:42', '2020-01-20 00:14:42'),
(280, 277, 'BOPT/DAK/FORWARD/-1579499189', 7657, 0, 'forward', '2020-01-20 05:46:29', '2020-01-20 00:16:29'),
(281, 278, 'BOPT/DAK/FORWARD/-1579499285', 7657, 0, 'forward', '2020-01-20 05:48:05', '2020-01-20 00:18:05'),
(282, 279, 'BOPT/DAK/FORWARD/-1580536236', 3020, 0, 'forward', '2020-02-01 05:50:36', '2020-02-01 00:20:36'),
(283, 280, 'BOPT/DAK/FORWARD/-1580536315', 3020, 0, 'forward', '2020-02-01 05:51:55', '2020-02-01 00:21:55'),
(284, 281, 'BOPT/DAK/FORWARD/-1580536536', 3020, 0, 'forward', '2020-02-01 05:55:36', '2020-02-01 00:25:36'),
(285, 282, 'BOPT/DAK/FORWARD/-1580536625', 3020, 0, 'forward', '2020-02-01 05:57:05', '2020-02-01 00:27:05'),
(286, 283, 'BOPT/DAK/FORWARD/-1580536953', 3020, 0, 'forward', '2020-02-01 06:02:33', '2020-02-01 00:32:33'),
(287, 284, 'BOPT/DAK/FORWARD/-1580537099', 3020, 0, 'forward', '2020-02-01 06:04:59', '2020-02-01 00:34:59'),
(288, 285, 'BOPT/DAK/FORWARD/-1580537313', 3020, 0, 'forward', '2020-02-01 06:08:33', '2020-02-01 00:38:33'),
(289, 286, 'BOPT/DAK/FORWARD/-1580537478', 3020, 0, 'forward', '2020-02-01 06:11:18', '2020-02-01 00:41:18'),
(290, 287, 'BOPT/DAK/FORWARD/-1580537629', 3181, 0, 'forward', '2020-02-01 06:13:49', '2020-02-01 00:43:49'),
(291, 288, 'BOPT/DAK/FORWARD/-1580537703', 3181, 0, 'forward', '2020-02-01 06:15:03', '2020-02-01 00:45:03'),
(292, 289, 'BOPT/DAK/FORWARD/-1580537937', 3377, 0, 'forward', '2020-02-01 06:18:57', '2020-02-01 00:48:57'),
(293, 290, 'BOPT/DAK/FORWARD/-1580538079', 3377, 0, 'forward', '2020-02-01 06:21:19', '2020-02-01 00:51:19'),
(294, 291, 'BOPT/DAK/FORWARD/-1579602906', 5408, 0, 'forward', '2020-01-21 10:35:06', '2020-01-21 05:05:06'),
(295, 292, 'BOPT/DAK/FORWARD/-1579603050', 5408, 0, 'forward', '2020-01-21 10:37:30', '2020-01-21 05:07:30'),
(296, 293, 'BOPT/DAK/FORWARD/-1579603759', 1530, 0, 'forward', '2020-01-21 10:49:19', '2020-01-21 05:19:19'),
(297, 294, 'BOPT/DAK/FORWARD/-1579603868', 1530, 0, 'forward', '2020-01-21 10:51:08', '2020-01-21 05:21:08'),
(298, 295, 'BOPT/DAK/FORWARD/-1579603948', 7657, 0, 'forward', '2020-01-21 10:52:28', '2020-01-21 05:22:28'),
(299, 296, 'BOPT/DAK/FORWARD/-1579604431', 7657, 0, 'forward', '2020-01-21 11:00:31', '2020-01-21 05:30:31'),
(300, 297, 'BOPT/DAK/FORWARD/-1579604531', 7657, 0, 'forward', '2020-01-21 11:02:11', '2020-01-21 05:32:11'),
(301, 298, 'BOPT/DAK/FORWARD/-1579604648', 3020, 0, 'forward', '2020-01-21 11:04:08', '2020-01-21 05:34:08'),
(302, 299, 'BOPT/DAK/FORWARD/-1579605018', 3020, 0, 'forward', '2020-01-21 11:10:18', '2020-01-21 05:40:18'),
(303, 300, 'BOPT/DAK/FORWARD/-1579605096', 3020, 0, 'forward', '2020-01-21 11:11:36', '2020-01-21 05:41:36'),
(304, 301, 'BOPT/DAK/FORWARD/-1579605183', 3020, 0, 'forward', '2020-01-21 11:13:03', '2020-01-21 05:43:03'),
(305, 302, 'BOPT/DAK/FORWARD/-1579605279', 3020, 0, 'forward', '2020-01-21 11:14:39', '2020-01-21 05:44:39'),
(306, 303, 'BOPT/DAK/FORWARD/-1579605384', 3020, 0, 'forward', '2020-01-21 11:16:24', '2020-01-21 05:46:24'),
(307, 304, 'BOPT/DAK/FORWARD/-1579605490', 3020, 0, 'forward', '2020-01-21 11:18:10', '2020-01-21 05:48:10'),
(308, 305, 'BOPT/DAK/FORWARD/-1579605573', 3020, 0, 'forward', '2020-01-21 11:19:33', '2020-01-21 05:49:33'),
(309, 306, 'BOPT/DAK/FORWARD/-1579605650', 3377, 0, 'forward', '2020-01-21 11:20:50', '2020-01-21 05:50:50'),
(310, 307, 'BOPT/DAK/FORWARD/-1579605732', 3377, 0, 'forward', '2020-01-21 11:22:12', '2020-01-21 05:52:12'),
(311, 308, 'BOPT/DAK/FORWARD/-1579605868', 6654, 0, 'forward', '2020-01-21 11:24:28', '2020-01-21 05:54:28'),
(312, 309, 'BOPT/DAK/FORWARD/-1579845245', 5408, 0, 'forward', '2020-01-24 05:54:05', '2020-01-24 00:24:05'),
(313, 310, 'BOPT/DAK/FORWARD/-1579845444', 5408, 0, 'forward', '2020-01-24 05:57:24', '2020-01-24 00:27:24'),
(314, 311, 'BOPT/DAK/FORWARD/-1579845635', 1530, 0, 'forward', '2020-01-24 06:00:35', '2020-01-24 00:30:35'),
(315, 312, 'BOPT/DAK/FORWARD/-1579845787', 1530, 0, 'forward', '2020-01-24 06:03:07', '2020-01-24 00:33:07'),
(316, 313, 'BOPT/DAK/FORWARD/-1579846384', 7657, 0, 'forward', '2020-01-24 06:13:04', '2020-01-24 00:43:04'),
(317, 314, 'BOPT/DAK/FORWARD/-1579846475', 7657, 0, 'forward', '2020-01-24 06:14:35', '2020-01-24 00:44:35'),
(318, 315, 'BOPT/DAK/FORWARD/-1579846587', 7657, 0, 'forward', '2020-01-24 06:16:27', '2020-01-24 00:46:27'),
(319, 316, 'BOPT/DAK/FORWARD/-1579846673', 7657, 0, 'forward', '2020-01-24 06:17:53', '2020-01-24 00:47:53'),
(320, 317, 'BOPT/DAK/FORWARD/-1579846937', 3020, 0, 'forward', '2020-01-24 06:22:17', '2020-01-24 00:52:17'),
(321, 318, 'BOPT/DAK/FORWARD/-1579847223', 3020, 0, 'forward', '2020-01-24 06:27:03', '2020-01-24 00:57:03'),
(322, 319, 'BOPT/DAK/FORWARD/-1579847304', 3020, 0, 'forward', '2020-01-24 06:28:24', '2020-01-24 00:58:24'),
(323, 320, 'BOPT/DAK/FORWARD/-1579847383', 3020, 0, 'forward', '2020-01-24 06:29:43', '2020-01-24 00:59:43'),
(324, 321, 'BOPT/DAK/FORWARD/-1579847475', 3020, 0, 'forward', '2020-01-24 06:31:15', '2020-01-24 01:01:15'),
(325, 322, 'BOPT/DAK/FORWARD/-1579847549', 3020, 0, 'forward', '2020-01-24 06:32:29', '2020-01-24 01:02:29'),
(326, 323, 'BOPT/DAK/FORWARD/-1579847629', 3020, 0, 'forward', '2020-01-24 06:33:49', '2020-01-24 01:03:49'),
(327, 324, 'BOPT/DAK/FORWARD/-1579847725', 3020, 0, 'forward', '2020-01-24 06:35:25', '2020-01-24 01:05:25'),
(328, 325, 'BOPT/DAK/FORWARD/-1579847806', 3377, 0, 'forward', '2020-01-24 06:36:46', '2020-01-24 01:06:46'),
(329, 326, 'BOPT/DAK/FORWARD/-1580203525', 5408, 0, 'forward', '2020-01-28 09:25:25', '2020-01-28 03:55:25'),
(330, 327, 'BOPT/DAK/FORWARD/-1580203654', 5408, 0, 'forward', '2020-01-28 09:27:34', '2020-01-28 03:57:34'),
(331, 328, 'BOPT/DAK/FORWARD/-1580203743', 1530, 0, 'forward', '2020-01-28 09:29:03', '2020-01-28 03:59:03'),
(332, 329, 'BOPT/DAK/FORWARD/-1580203871', 1530, 0, 'forward', '2020-01-28 09:31:11', '2020-01-28 04:01:11'),
(333, 330, 'BOPT/DAK/FORWARD/-1580204025', 7657, 0, 'forward', '2020-01-28 09:33:45', '2020-01-28 04:03:45'),
(334, 331, 'BOPT/DAK/FORWARD/-1580204101', 7657, 0, 'forward', '2020-01-28 09:35:01', '2020-01-28 04:05:01'),
(335, 332, 'BOPT/DAK/FORWARD/-1580204177', 7657, 0, 'forward', '2020-01-28 09:36:17', '2020-01-28 04:06:17'),
(336, 333, 'BOPT/DAK/FORWARD/-1580204304', 7657, 0, 'forward', '2020-01-28 09:38:24', '2020-01-28 04:08:24'),
(337, 334, 'BOPT/DAK/FORWARD/-1580204396', 7657, 0, 'forward', '2020-01-28 09:39:56', '2020-01-28 04:09:56'),
(338, 335, 'BOPT/DAK/FORWARD/-1580204705', 3020, 0, 'forward', '2020-01-28 09:45:05', '2020-01-28 04:15:05'),
(339, 336, 'BOPT/DAK/FORWARD/-1580204820', 3020, 0, 'forward', '2020-01-28 09:47:00', '2020-01-28 04:17:00'),
(340, 337, 'BOPT/DAK/FORWARD/-1580205027', 3020, 0, 'forward', '2020-01-28 09:50:27', '2020-01-28 04:20:27'),
(341, 338, 'BOPT/DAK/FORWARD/-1580205382', 3020, 0, 'forward', '2020-01-28 09:56:22', '2020-01-28 04:26:22'),
(342, 339, 'BOPT/DAK/FORWARD/-1580205507', 3020, 0, 'forward', '2020-01-28 09:58:27', '2020-01-28 04:28:27'),
(343, 340, 'BOPT/DAK/FORWARD/-1580205616', 3020, 0, 'forward', '2020-01-28 10:00:16', '2020-01-28 04:30:16'),
(344, 341, 'BOPT/DAK/FORWARD/-1580205691', 3020, 0, 'forward', '2020-01-28 10:01:31', '2020-01-28 04:31:31'),
(345, 342, 'BOPT/DAK/FORWARD/-1580205811', 3020, 0, 'forward', '2020-01-28 10:03:31', '2020-01-28 04:33:31'),
(346, 343, 'BOPT/DAK/FORWARD/-1580206118', 3020, 0, 'forward', '2020-01-28 10:08:38', '2020-01-28 04:38:38'),
(347, 344, 'BOPT/DAK/FORWARD/-1580206220', 3020, 0, 'forward', '2020-01-28 10:10:20', '2020-01-28 04:40:20'),
(348, 345, 'BOPT/DAK/FORWARD/-1580206291', 3020, 0, 'forward', '2020-01-28 10:11:31', '2020-01-28 04:41:31'),
(349, 346, 'BOPT/DAK/FORWARD/-1580206376', 3020, 0, 'forward', '2020-01-28 10:12:56', '2020-01-28 04:42:56'),
(350, 347, 'BOPT/DAK/FORWARD/-1580206488', 6654, 0, 'forward', '2020-01-28 10:14:48', '2020-01-28 04:44:48'),
(351, 348, 'BOPT/DAK/FORWARD/-1580720866', 5408, 0, 'forward', '2020-02-03 09:07:46', '2020-02-03 03:37:46'),
(352, 349, 'BOPT/DAK/FORWARD/-1580720948', 5408, 0, 'forward', '2020-02-03 09:09:08', '2020-02-03 03:39:08'),
(353, 350, 'BOPT/DAK/FORWARD/-1580721065', 5408, 0, 'forward', '2020-02-03 09:11:05', '2020-02-03 03:41:05'),
(354, 351, 'BOPT/DAK/FORWARD/-1580721138', 1530, 0, 'forward', '2020-02-03 09:12:18', '2020-02-03 03:42:18'),
(355, 352, 'BOPT/DAK/FORWARD/-1580721995', 1530, 0, 'forward', '2020-02-03 09:26:35', '2020-02-03 03:56:35'),
(356, 353, 'BOPT/DAK/FORWARD/-1580722121', 7657, 0, 'forward', '2020-02-03 09:28:41', '2020-02-03 03:58:41'),
(357, 354, 'BOPT/DAK/FORWARD/-1580722297', 7657, 0, 'forward', '2020-02-03 09:31:37', '2020-02-03 04:01:37'),
(358, 355, 'BOPT/DAK/FORWARD/-1580722408', 7657, 0, 'forward', '2020-02-03 09:33:28', '2020-02-03 04:03:28'),
(359, 356, 'BOPT/DAK/FORWARD/-1580722544', 7657, 0, 'forward', '2020-02-03 09:35:44', '2020-02-03 04:05:44'),
(360, 357, 'BOPT/DAK/FORWARD/-1580722773', 3020, 0, 'forward', '2020-02-03 09:39:33', '2020-02-03 04:09:33'),
(361, 358, 'BOPT/DAK/FORWARD/-1580722893', 3020, 0, 'forward', '2020-02-03 09:41:33', '2020-02-03 04:11:33'),
(362, 359, 'BOPT/DAK/FORWARD/-1580723049', 3020, 0, 'forward', '2020-02-03 09:44:09', '2020-02-03 04:14:09'),
(363, 360, 'BOPT/DAK/FORWARD/-1580723141', 3020, 0, 'forward', '2020-02-03 09:45:41', '2020-02-03 04:15:41'),
(364, 361, 'BOPT/DAK/FORWARD/-1580723211', 3020, 0, 'forward', '2020-02-03 09:46:51', '2020-02-03 04:16:51'),
(365, 362, 'BOPT/DAK/FORWARD/-1580723310', 3020, 0, 'forward', '2020-02-03 09:48:30', '2020-02-03 04:18:30'),
(366, 363, 'BOPT/DAK/FORWARD/-1580723398', 3020, 0, 'forward', '2020-02-03 09:49:58', '2020-02-03 04:19:58'),
(367, 364, 'BOPT/DAK/FORWARD/-1580723494', 3181, 0, 'forward', '2020-02-03 09:51:34', '2020-02-03 04:21:34'),
(368, 365, 'BOPT/DAK/FORWARD/-1580723580', 3377, 0, 'forward', '2020-02-03 09:53:00', '2020-02-03 04:23:00'),
(369, 366, 'BOPT/DAK/FORWARD/-1580723655', 6654, 0, 'forward', '2020-02-03 09:54:15', '2020-02-03 04:24:15'),
(370, 367, 'BOPT/DAK/FORWARD/-1580887484', 5408, 0, 'forward', '2020-02-05 07:24:44', '2020-02-05 01:54:44'),
(371, 368, 'BOPT/DAK/FORWARD/-1580887584', 1530, 0, 'forward', '2020-02-05 07:26:24', '2020-02-05 01:56:24'),
(372, 369, 'BOPT/DAK/FORWARD/-1580887720', 1530, 0, 'forward', '2020-02-05 07:28:40', '2020-02-05 01:58:40'),
(373, 370, 'BOPT/DAK/FORWARD/-1580887789', 7657, 0, 'forward', '2020-02-05 07:29:49', '2020-02-05 01:59:49'),
(374, 371, 'BOPT/DAK/FORWARD/-1580887886', 7657, 0, 'forward', '2020-02-05 07:31:26', '2020-02-05 02:01:26'),
(375, 372, 'BOPT/DAK/FORWARD/-1580887973', 3377, 0, 'forward', '2020-02-05 07:32:53', '2020-02-05 02:02:53'),
(376, 373, 'BOPT/DAK/FORWARD/-1580888075', 3716, 0, 'forward', '2020-02-05 07:34:35', '2020-02-05 02:04:35'),
(377, 374, 'BOPT/DAK/FORWARD/-1580888163', 6654, 0, 'forward', '2020-02-05 07:36:03', '2020-02-05 02:06:03'),
(378, 375, 'BOPT/DAK/FORWARD/-1580888258', 3181, 0, 'forward', '2020-02-05 07:37:38', '2020-02-05 02:07:38'),
(379, 376, 'BOPT/DAK/FORWARD/-1580888366', 4238, 0, 'forward', '2020-02-05 07:39:26', '2020-02-05 02:09:26'),
(380, 377, 'BOPT/DAK/FORWARD/-1580888443', 3181, 0, 'forward', '2020-02-05 07:40:43', '2020-02-05 02:10:43'),
(381, 378, 'BOPT/DAK/FORWARD/-1580888572', 4238, 0, 'forward', '2020-02-05 07:42:52', '2020-02-05 02:12:52'),
(382, 379, 'BOPT/DAK/FORWARD/-1580888692', 3020, 0, 'forward', '2020-02-05 07:44:52', '2020-02-05 02:14:52'),
(383, 380, 'BOPT/DAK/FORWARD/-1580888766', 3020, 0, 'forward', '2020-02-05 07:46:06', '2020-02-05 02:16:06'),
(384, 381, 'BOPT/DAK/FORWARD/-1580888866', 3020, 0, 'forward', '2020-02-05 07:47:46', '2020-02-05 02:17:46'),
(385, 382, 'BOPT/DAK/FORWARD/-1580888987', 3020, 0, 'forward', '2020-02-05 07:49:47', '2020-02-05 02:19:47'),
(386, 383, 'BOPT/DAK/FORWARD/-1580889065', 3020, 0, 'forward', '2020-02-05 07:51:05', '2020-02-05 02:21:05'),
(387, 384, 'BOPT/DAK/FORWARD/-1580889144', 3020, 0, 'forward', '2020-02-05 07:52:24', '2020-02-05 02:22:24'),
(388, 385, 'BOPT/DAK/FORWARD/-1580889216', 3020, 0, 'forward', '2020-02-05 07:53:36', '2020-02-05 02:23:36'),
(389, 386, 'BOPT/DAK/FORWARD/-1580889287', 3020, 0, 'forward', '2020-02-05 07:54:47', '2020-02-05 02:24:47'),
(390, 387, 'BOPT/DAK/FORWARD/-1581060653', 5408, 0, 'forward', '2020-02-07 07:30:53', '2020-02-07 02:00:53'),
(391, 388, 'BOPT/DAK/FORWARD/-1581060761', 5408, 0, 'forward', '2020-02-07 07:32:41', '2020-02-07 02:02:41'),
(392, 389, 'BOPT/DAK/FORWARD/-1581060877', 1530, 0, 'forward', '2020-02-07 07:34:37', '2020-02-07 02:04:37'),
(393, 390, 'BOPT/DAK/FORWARD/-1581060990', 7657, 0, 'forward', '2020-02-07 07:36:30', '2020-02-07 02:06:30'),
(394, 391, 'BOPT/DAK/FORWARD/-1581061148', 3020, 0, 'forward', '2020-02-07 07:39:08', '2020-02-07 02:09:08'),
(395, 392, 'BOPT/DAK/FORWARD/-1581061235', 3020, 0, 'forward', '2020-02-07 07:40:35', '2020-02-07 02:10:35'),
(396, 393, 'BOPT/DAK/FORWARD/-1581061337', 3020, 0, 'forward', '2020-02-07 07:42:17', '2020-02-07 02:12:17'),
(397, 394, 'BOPT/DAK/FORWARD/-1581061465', 3020, 0, 'forward', '2020-02-07 07:44:25', '2020-02-07 02:14:25'),
(398, 395, 'BOPT/DAK/FORWARD/-1581061621', 4042, 0, 'forward', '2020-02-07 07:47:01', '2020-02-07 02:17:01'),
(399, 396, 'BOPT/DAK/FORWARD/-1581416193', 5408, 0, 'forward', '2020-02-11 10:16:33', '2020-02-11 04:46:33'),
(400, 397, 'BOPT/DAK/FORWARD/-1581416279', 5408, 0, 'forward', '2020-02-11 10:17:59', '2020-02-11 04:47:59'),
(401, 398, 'BOPT/DAK/FORWARD/-1581416460', 5408, 0, 'forward', '2020-02-11 10:21:00', '2020-02-11 04:51:00'),
(402, 399, 'BOPT/DAK/FORWARD/-1581416654', 1530, 0, 'forward', '2020-02-11 10:24:14', '2020-02-11 04:54:14'),
(403, 400, 'BOPT/DAK/FORWARD/-1581416758', 1530, 0, 'forward', '2020-02-11 10:25:58', '2020-02-11 04:55:58'),
(404, 401, 'BOPT/DAK/FORWARD/-1581416843', 1530, 0, 'forward', '2020-02-11 10:27:23', '2020-02-11 04:57:23'),
(405, 402, 'BOPT/DAK/FORWARD/-1581416963', 1530, 0, 'forward', '2020-02-11 10:29:23', '2020-02-11 04:59:23'),
(406, 403, 'BOPT/DAK/FORWARD/-1581417083', 7657, 0, 'forward', '2020-02-11 10:31:23', '2020-02-11 05:01:23'),
(407, 404, 'BOPT/DAK/FORWARD/-1581417312', 7657, 0, 'forward', '2020-02-11 10:35:12', '2020-02-11 05:05:12'),
(408, 405, 'BOPT/DAK/FORWARD/-1581417478', 7657, 0, 'forward', '2020-02-11 10:37:58', '2020-02-11 05:07:58'),
(409, 406, 'BOPT/DAK/FORWARD/-1581417556', 7657, 0, 'forward', '2020-02-11 10:39:16', '2020-02-11 05:09:16'),
(410, 407, 'BOPT/DAK/FORWARD/-1581417762', 3181, 0, 'forward', '2020-02-11 10:42:42', '2020-02-11 05:12:42'),
(411, 408, 'BOPT/DAK/FORWARD/-1581417876', 3377, 0, 'forward', '2020-02-11 10:44:36', '2020-02-11 05:14:36'),
(412, 409, 'BOPT/DAK/FORWARD/-1581418012', 3377, 0, 'forward', '2020-02-11 10:46:52', '2020-02-11 05:16:52'),
(413, 410, 'BOPT/DAK/FORWARD/-1581418083', 3377, 0, 'forward', '2020-02-11 10:48:03', '2020-02-11 05:18:03'),
(414, 411, 'BOPT/DAK/FORWARD/-1581418236', 3377, 0, 'forward', '2020-02-11 10:50:36', '2020-02-11 05:20:36'),
(415, 412, 'BOPT/DAK/FORWARD/-1581418374', 3020, 0, 'forward', '2020-02-11 10:52:54', '2020-02-11 05:22:54'),
(416, 413, 'BOPT/DAK/FORWARD/-1581418474', 3020, 0, 'forward', '2020-02-11 10:54:34', '2020-02-11 05:24:34'),
(417, 414, 'BOPT/DAK/FORWARD/-1581418636', 3020, 0, 'forward', '2020-02-11 10:57:16', '2020-02-11 05:27:16'),
(418, 415, 'BOPT/DAK/FORWARD/-1581418779', 3020, 0, 'forward', '2020-02-11 10:59:39', '2020-02-11 05:29:39'),
(419, 416, 'BOPT/DAK/FORWARD/-1581419085', 3020, 0, 'forward', '2020-02-11 11:04:45', '2020-02-11 05:34:45'),
(420, 417, 'BOPT/DAK/FORWARD/-1581420340', 3020, 0, 'forward', '2020-02-11 11:25:40', '2020-02-11 05:55:40'),
(421, 418, 'BOPT/DAK/FORWARD/-1581420456', 3020, 0, 'forward', '2020-02-11 11:27:36', '2020-02-11 05:57:36'),
(422, 419, 'BOPT/DAK/FORWARD/-1581420559', 3020, 0, 'forward', '2020-02-11 11:29:19', '2020-02-11 05:59:19'),
(423, 420, 'BOPT/DAK/FORWARD/-1581420630', 3020, 0, 'forward', '2020-02-11 11:30:30', '2020-02-11 06:00:30'),
(424, 421, 'BOPT/DAK/FORWARD/-1581420775', 3020, 0, 'forward', '2020-02-11 11:32:55', '2020-02-11 06:02:55'),
(425, 422, 'BOPT/DAK/FORWARD/-1581420988', 3020, 0, 'forward', '2020-02-11 11:36:28', '2020-02-11 06:06:28'),
(426, 423, 'BOPT/DAK/FORWARD/-1581421067', 3020, 0, 'forward', '2020-02-11 11:37:47', '2020-02-11 06:07:47'),
(427, 424, 'BOPT/DAK/FORWARD/-1581421147', 3020, 0, 'forward', '2020-02-11 11:39:07', '2020-02-11 06:09:07'),
(428, 425, 'BOPT/DAK/FORWARD/-1581421224', 3020, 0, 'forward', '2020-02-11 11:40:24', '2020-02-11 06:10:24'),
(429, 426, 'BOPT/DAK/FORWARD/-1581421339', 3020, 0, 'forward', '2020-02-11 11:42:19', '2020-02-11 06:12:19'),
(430, 427, 'BOPT/DAK/FORWARD/-1581577928', 5408, 0, 'forward', '2020-02-13 07:12:08', '2020-02-13 01:42:08'),
(431, 428, 'BOPT/DAK/FORWARD/-1581578074', 1530, 0, 'forward', '2020-02-13 07:14:34', '2020-02-13 01:44:34'),
(432, 429, 'BOPT/DAK/FORWARD/-1581578512', 7657, 0, 'forward', '2020-02-13 07:21:52', '2020-02-13 01:51:52'),
(433, 430, 'BOPT/DAK/FORWARD/-1581578701', 7657, 0, 'forward', '2020-02-13 07:25:01', '2020-02-13 01:55:01'),
(434, 431, 'BOPT/DAK/FORWARD/-1581578817', 3020, 0, 'forward', '2020-02-13 07:26:57', '2020-02-13 01:56:57'),
(435, 432, 'BOPT/DAK/FORWARD/-1581579058', 3020, 0, 'forward', '2020-02-13 07:30:58', '2020-02-13 02:00:58'),
(436, 433, 'BOPT/DAK/FORWARD/-1581579181', 3020, 0, 'forward', '2020-02-13 07:33:01', '2020-02-13 02:03:01'),
(437, 434, 'BOPT/DAK/FORWARD/-1581579608', 3020, 0, 'forward', '2020-02-13 07:40:08', '2020-02-13 02:10:08'),
(438, 435, 'BOPT/DAK/FORWARD/-1581580200', 3020, 0, 'forward', '2020-02-13 07:50:00', '2020-02-13 02:20:00'),
(439, 436, 'BOPT/DAK/FORWARD/-1581580269', 3020, 0, 'forward', '2020-02-13 07:51:09', '2020-02-13 02:21:09'),
(440, 0, 'BOPT/DAK/FORWARD/-1581580509', 3181, 0, 'forward', '2020-02-13 07:55:09', '2020-02-13 02:25:09'),
(441, 438, 'BOPT/DAK/FORWARD/-1581580600', 3181, 0, 'forward', '2020-02-13 07:56:40', '2020-02-13 02:26:40');

-- --------------------------------------------------------

--
-- Table structure for table `dak_receipt_details`
--

CREATE TABLE `dak_receipt_details` (
  `id` int(11) NOT NULL,
  `diary_year` year(4) DEFAULT NULL,
  `diary_date` date NOT NULL,
  `receipt_type` varchar(100) DEFAULT NULL,
  `receipt_category` varchar(100) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `reference_date` date NOT NULL,
  `sender_name` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `remarks` varchar(100) DEFAULT NULL,
  `dealing_head` varchar(100) DEFAULT NULL,
  `enclosure_details` varchar(100) DEFAULT NULL,
  `rec_lan` varchar(11) DEFAULT NULL,
  `other_lan` varchar(50) NOT NULL,
  `dairy_no` varchar(100) DEFAULT NULL,
  `doc_status` enum('receipt','forward','reject','accept','closed','open') NOT NULL,
  `updated_at` timestamp(6) NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT '0000-00-00 00:00:00.000000'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dak_receipt_details`
--

INSERT INTO `dak_receipt_details` (`id`, `diary_year`, `diary_date`, `receipt_type`, `receipt_category`, `reference_no`, `reference_date`, `sender_name`, `address`, `state`, `subject`, `remarks`, `dealing_head`, `enclosure_details`, `rec_lan`, `other_lan`, `dairy_no`, `doc_status`, `updated_at`, `created_at`) VALUES
(1, 2019, '2019-08-16', 'Letter', 'General', 'SMPL/TIOM/HR&ES/2019-20/3468', '2019-07-05', 'SARDA MINES PRIVATE LIMITED', 'KEONJHAR', NULL, 'SHOW CAUSE NOTICE', 'NILL', NULL, '2 - PREVIOUS LETTER', 'English', '', 'BOPT/DAK-72-2019-08-16', 'closed', '2019-08-16 02:04:58.000000', '2019-08-16 07:29:13.620804'),
(4, 2019, '2019-08-16', 'Letter', 'General', '1002/RIT/BOPT/3387/19', '2019-08-09', 'ROLAND INSTITUTE OF TECHNOLOGY', 'BRAHMAPUR', 'Orissa', 'ENGAGEMENT OF TRAINEE', 'NILL', NULL, '1- BOPT LETTER', 'English', '', 'BOPT/DAK-88-2019-08-16', 'forward', NULL, '2019-08-16 07:49:52.058977'),
(5, 2019, '2019-08-16', 'Letter', 'General', '1002/RIT/BOPT/3385/19', '2019-08-07', 'ROLAND INSTITUTE OF TECHNOLOGY', 'BRAHMAPUR', 'Orissa', 'INTERNSHIP PROGRAMME', 'NILL', NULL, 'INTERNSHIP FORM', 'English', '', 'BOPT/DAK-60-2019-08-16', 'forward', NULL, '2019-08-16 07:57:49.981051'),
(6, 2019, '2019-08-16', 'Letter', 'General', 'OPGC/ITPS/HR/4501', '2019-07-17', 'ODISHA POWER TRANSMISSION CORPORATION LIMITED', 'JHARSUGUDA', 'Orissa', 'SHOW CAUSE NOTICE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-17-2019-08-16', 'forward', NULL, '2019-08-16 09:00:10.989260'),
(7, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'LUM/T/NATS/068/08/19', '2019-08-08', 'LUMINOUS INFOWAYS PRIVATE LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-40-2019-08-16', 'forward', NULL, '2019-08-16 09:12:03.631712'),
(8, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'HRD/TA/RC/1166', '2019-08-08', 'STEEL AUTHORITY OF INDIA LIMITED', 'ROURKELA', 'Orissa', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-30-2019-08-16', 'forward', NULL, '2019-08-16 09:19:02.173859'),
(9, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'HRD/TA/RC/1167', '2019-08-08', 'STEEL AUTHORITY OF INDIA LIMITED', 'ROURKELA', 'Orissa', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-49-2019-08-16', 'forward', NULL, '2019-08-16 09:44:45.999861'),
(10, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'RSB-1/JSR/HR-001/2019-20', '2019-08-12', 'RSB TRANSMISSIONS (I) LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-97-2019-08-16', 'closed', NULL, '2019-08-16 09:52:06.150647'),
(11, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'RSB-3/JSR/HR-002/2019-20', '2019-07-15', 'RSB TRANSMISSIONS (I) LTD. (UNIT-III)', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-21-2019-08-16', 'closed', NULL, '2019-08-16 09:59:15.685560'),
(12, 2019, '2019-08-16', 'Letter', 'General', 'HRD/2019/968', '2019-08-02', 'STEEL AUTHORITY OF INDIA LTD. BOKARO STEEL PLANT', 'BOKARO', 'Jharkhand', 'SHOW CAUSE NOTICE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-36-2019-08-16', 'forward', NULL, '2019-08-16 10:08:56.102223'),
(13, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'STI1804708', '2018-09-04', 'EWEBTONIC SERVICES PVT. LTD.', NULL, 'Jharkhand', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-77-2019-08-16', 'forward', NULL, '2019-08-16 10:17:01.506376'),
(14, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'NILL', '2019-07-31', 'NIKS TECHNOLOGY PVT. LTD.', 'PATNA', 'Bihar', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-62-2019-08-16', 'forward', NULL, '2019-08-16 10:25:00.498631'),
(15, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'CS/SW/20022', '2019-08-02', 'PRIYA IT SOLUTION LLP', 'PATNA', 'Bihar', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-14-2019-08-16', 'forward', NULL, '2019-08-16 10:28:32.518200'),
(16, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'TKECLP/HO/HR/OC/2019-20/08/03', '2019-08-01', 'T. K. ENGINEERING CONSORTIUM PVT. LTD.', 'PAPUMPARE', 'Arunachal Pradesh', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-46-2019-08-16', 'forward', NULL, '2019-08-16 10:35:01.515762'),
(17, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'CMPDI/2019-20/416/1935', '2019-08-01', 'CENTRAL MINE PLANNING & DESIGN INSTITUTE LTD.', 'NAGPUR', 'Maharashtra', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-97-2019-08-16', 'forward', NULL, '2019-08-16 10:38:49.443981'),
(18, 2019, '2019-08-16', 'Proficiancy certificate', 'General', 'DCE/MCH/E-4DCE/MCH/E-46/VIL-III/14416/VIL-III/1441', '2019-07-29', 'ANDAMAN LAKSHADWEEP HARBOUR WORKS', 'PORT BLAIR', 'Andaman and Nicobar Islands', 'PROFICIENCY CERTIFICATE', 'NILL', NULL, 'CERTIFICATE  FORMAT', 'English', '', 'BOPT/DAK-77-2019-08-16', 'forward', NULL, '2019-08-16 10:52:57.633175'),
(19, 2019, '2019-08-16', 'Letter', 'General', 'NILL', '2019-08-08', 'THE OBEROI GRAND', 'SALT LAKE - KOLKATA', 'West Bengal', 'ENGAGEMENT OF TRAINEE', 'NILL', NULL, '3 COPY', 'English', '', 'BOPT/DAK-80-2019-08-16', 'forward', NULL, '2019-08-16 10:57:44.844833'),
(20, 2019, '2019-08-16', 'Letter', 'General', 'NILL', '2019-08-07', 'FEEDBACK ENERGY DISTRIBUTION COMPANY LTD.B', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-78-2019-08-16', 'forward', NULL, '2019-08-16 11:01:59.944628'),
(21, 2019, '2019-08-16', 'Letter', 'General', 'TSIL/HR/19-20/01', '2019-08-05', 'THE SUPREME INDUSTRIES LIMITED', 'DURGAPUR', 'West Bengal', 'SHOW CAUSE NOTICE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-35-2019-08-16', 'forward', NULL, '2019-08-16 11:10:56.182890'),
(22, 2019, '2019-08-16', 'Letter', 'General', 'DC/DD/E-32/VOL-IX/2474', '2019-08-05', 'ANDAMAN LAKSHADWEEP HARBOUR WORKS', 'PORT BLAIR', 'Andaman and Nicobar Islands', 'PROFICIENCY CERTIFICATE', 'NILL', NULL, '7- COPIES', 'English', '', 'BOPT/DAK-47-2019-08-16', 'forward', NULL, '2019-08-16 11:16:15.548000'),
(23, 2019, '2019-08-16', 'Letter', 'General', 'TS/5/1/BATCH 2016-17', '2019-08-06', 'CHITTARANJAN LOCOMOTIVE WORKS', 'CHITTARANJAN', 'West Bengal', 'CONTRACT REGISTRATION', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-52-2019-08-16', 'forward', NULL, '2019-08-16 11:20:19.724161'),
(24, 2019, '2019-08-16', 'Letter', 'General', 'HR/ER/APPR', '2019-08-06', 'INDIAN OIL CORPORATION LIMITED - INDIAN OIL CORPORATION LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'ENGAGEMENT OF TRAINEE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-30-2019-08-16', 'forward', NULL, '2019-08-16 11:24:19.791087'),
(25, 2019, '2019-08-16', 'Bill(Stipend)', 'General', 'LB/AC/SG/AD/440', '2019-08-14', 'L. B. ENGINEERING PVT. LTD.', 'HOOGHLY', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-20-2019-08-16', 'forward', NULL, '2019-08-16 11:27:06.657763'),
(26, 2019, '2019-08-16', 'Letter', 'General', 'NILL', '2019-08-07', 'AMEC FOSTER WHEELER INDIA PRIVATE LIMITED', 'CHENNAI', 'Tamil Nadu', 'SHOW CAUSE NOTICE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-62-2019-08-16', 'forward', NULL, '2019-08-16 11:31:13.642088'),
(27, 2019, '2019-08-16', 'Letter', 'General', '21136', '2019-08-08', 'NORTHEAST CONSULTANCY SERVICES', 'AIZAWL', 'Mizoram', 'MONEY RECEIPT', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-16-2019-08-16', 'forward', NULL, '2019-08-16 11:34:40.685095'),
(28, 2019, '2019-08-16', 'Letter', 'General', 'NILL', '2019-07-12', 'KUMAR CERAMICS PVT. LTD.', 'BALASORE', 'Orissa', 'SHOW CAUSE NOTICE', 'NILL', NULL, '2 - COPIES', 'English', '', 'BOPT/DAK-91-2019-08-16', 'forward', NULL, '2019-08-16 11:42:21.908846'),
(29, 2019, '2019-08-16', 'Letter', 'General', 'NILL', '2019-08-13', 'BATA INDIA LIMITED', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', 'NILL', NULL, '1- BOPT LETTER', 'English', '', 'BOPT/DAK-33-2019-08-16', 'forward', NULL, '2019-08-16 11:45:34.727030'),
(30, 2019, '2019-08-16', 'Bill', 'General', 'BL-TV/CCU/BPT', '2019-08-07', 'BALMER LAWRIE & CO. LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, '10 - COPIES', 'English', '', 'BOPT/DAK-39-2019-08-16', 'forward', NULL, '2019-08-16 11:56:42.321749'),
(31, 2019, '2019-08-16', 'Bill', 'General', 'GD-1920005521', '2019-08-02', 'GUJRAL DISRIBUTORS', 'KOLKATA', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, '5 COPIES', 'English', '', 'BOPT/DAK-43-2019-08-16', 'forward', NULL, '2019-08-16 12:05:08.925131'),
(32, 2019, '2019-08-16', 'Bill', 'General', '984', '2019-07-31', 'SALT LAKE SERVICE STATION', 'KOLKATA', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, '1 COPIES', 'English', '', 'BOPT/DAK-57-2019-08-16', 'forward', NULL, '2019-08-16 12:07:22.714892'),
(33, 2019, '2019-08-16', 'Bill', 'General', 'OE/19-20/WB/1303', '2019-08-05', 'ORION EDUTECH PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-26-2019-08-16', 'receipt', NULL, '2019-08-16 12:10:37.335179'),
(34, 2019, '2019-08-27', 'Bill', 'General', 'EXIDE/HAL/PLANT HR/BOPT/2019/3601', '2019-08-21', 'EXIDE INDUSTRIES LIMITED', 'PURBA MEDINIPUR', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:20:59-2019-08-27', 'forward', NULL, '2019-08-27 07:20:59.092458'),
(35, 2019, '2019-08-27', 'Bill', 'General', 'EXIDE/HAL/PLANT HR/BOPT/2019/3601', '2019-08-21', 'EXIDE INDUSTRIES LIMITED', 'PURBA MEDINIPUR', 'West Bengal', 'CLAIM BILL', 'NILL', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:24:35-2019-08-27', 'forward', NULL, '2019-08-27 07:24:35.527011'),
(36, 2019, '2019-08-27', 'Letter', 'General', 'NSPC/225/19', '2019-08-24', 'N. S. POLYTECHNIC COLLEGE', 'PURBA BARDHAMAN', 'West Bengal', 'SHOW CAUSE NOTICE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-07:29:09-2019-08-27', 'forward', NULL, '2019-08-27 07:29:09.613907'),
(37, 2019, '2019-08-27', 'Letter', 'General', 'NILL', '2019-08-22', 'SWASTIK CLINIC & SEVA SADAN PVT. LTD.', 'BIRBHUM', 'West Bengal', 'APPRENTICESHIP TRAINING', 'NILL', NULL, '10 - COPIES', 'English', '', 'BOPT/DAK-07:38:23-2019-08-27', 'forward', NULL, '2019-08-27 07:38:23.633040'),
(38, 2019, '2019-08-27', 'Letter', 'General', '1452/M', '2019-07-25', 'JALPAIGURI MUNICIPALITY', 'JALPAIGURI', 'West Bengal', 'ENGAGEMENT OF TRAINEE', 'NILL', NULL, '2 - PREVIOUS LETTER', 'English', '', 'BOPT/DAK-07:43:11-2019-08-27', 'reject', NULL, '2019-08-27 07:43:11.609742'),
(39, 2019, '2019-08-27', 'Letter', 'General', '12031/1/2018-DTE(AGR-ESTT)', '2019-08-01', 'DIRECTORATE OF AGRICULTURE, GOVT. OF MIZORAM', 'AIZAWL', 'Mizoram', 'ENGAGEMENT OF TRAINEE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-07:48:35-2019-08-27', 'reject', NULL, '2019-08-27 07:48:35.494526'),
(40, 2019, '2019-08-27', 'Letter', 'General', '1075/DLB/P-215/3-2011', '2019-08-20', 'DIRECTORATE OF LOCAL BODIES, GOVT. OF WEST BENGAL', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', 'NILL', NULL, 'NILL', 'English', '', 'BOPT/DAK-07:55:42-2019-08-27', 'forward', NULL, '2019-08-27 07:55:42.271280'),
(41, 2019, '2019-10-18', 'Letter', 'General', 'NIL', '2019-08-16', 'TRISHAN METALS PVT. LTD.', 'HOOGHLY', 'West Bengal', 'SHOW CAUSE NOTICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:47:52-2019-10-18', 'forward', NULL, '2019-10-18 07:47:52.255424'),
(42, 2019, '2019-10-18', 'Letter', 'General', '9043', '2019-10-11', 'BUILDING CONSTRUCTION DEPARTMENT, GGOVT. OF BIHAR', 'PATNA', 'Bihar', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:51:41-2019-10-18', 'forward', NULL, '2019-10-18 07:51:41.064695'),
(43, 2019, '2019-10-18', 'Letter', 'General', '9042', '2019-10-11', 'BUILDING CONSTRUCTION DEPARTMENT, GGOVT. OF BIHAR', 'PATNA', 'Bihar', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:53:41-2019-10-18', 'receipt', NULL, '2019-10-18 07:53:41.492681'),
(44, 2019, '2019-10-18', 'Letter', 'General', '9042', '2019-10-11', 'BUILDING CONSTRUCTION DEPARTMENT, GGOVT. OF BIHAR', 'PATNA', 'Bihar', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:53:41-2019-10-18', 'forward', NULL, '2019-10-18 07:53:41.507681'),
(45, 2019, '2019-10-18', 'Letter', 'General', 'NIL', '2019-09-13', 'EXPERIS IT PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1439', NULL, 'STIPEND CLAIM FORM', 'English', '', 'BOPT/DAK-07:57:20-2019-10-18', 'forward', NULL, '2019-10-18 07:57:20.925407'),
(46, 2019, '2019-10-18', 'Bill', 'General', 'STI1912977', '2019-10-12', 'SARASWATY PRESS LIMITED', 'JHARKHAND', 'Jharkhand', 'CLAIM BILL', '1440', NULL, 'STIPEND CLAIM FORM', 'English', '', 'BOPT/DAK-08:00:48-2019-10-18', 'forward', NULL, '2019-10-18 08:00:48.382439'),
(47, 2019, '2019-10-18', 'Bill', 'General', 'FS-547/167-UM', '2019-10-15', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1441', NULL, NULL, 'English', '', 'BOPT/DAK-08:03:44-2019-10-18', 'receipt', NULL, '2019-10-18 08:03:44.682666'),
(48, 2019, '2019-10-21', 'Letter', 'General', 'NIL', '2019-10-17', 'GODAVARI COMMODITIES LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', '1444', NULL, NULL, 'English', '', 'BOPT/DAK-07:26:30-2019-10-21', 'forward', NULL, '2019-10-21 07:26:30.949136'),
(49, 2019, '2019-10-21', 'Letter', 'General', 'NIL', '2019-10-15', 'MINISTRY OF SKILL DEVELOPMENT & ENTERPRENEURSHIP', 'NEW DELHI', 'Delhi', 'PUBLIC GRIEVANCES', '1445', NULL, NULL, 'English', '', 'BOPT/DAK-07:34:13-2019-10-21', 'forward', NULL, '2019-10-21 07:34:13.235496'),
(50, 2019, '2019-10-21', 'Letter', 'General', 'TE-E/TRG-3/2018/4511', '2019-09-26', 'OFFICE OF THE DIRECTOR OF TECHNICAL EDUCATION - ASSAM', 'KAHILIPARA', 'Assam', 'APPRENTICESHIP TRAINING', '1447', NULL, NULL, 'English', '', 'BOPT/DAK-07:46:32-2019-10-21', 'forward', NULL, '2019-10-21 07:46:32.472968'),
(51, 2019, '2019-10-21', 'Letter', 'General', '5024', '2019-09-30', 'OFFICE OF THE EXECUTIVE ENGINEER, ANGUL IRRIGATION DIVISION', 'ANGUL', 'Orissa', 'OFFICE ORDER', '1447', NULL, NULL, 'English', '', 'BOPT/DAK-07:57:33-2019-10-21', 'forward', NULL, '2019-10-21 07:57:33.445317'),
(52, 2019, '2019-10-21', 'Letter', 'General', '4742/WE', '2019-10-14', 'OFFICE OF THE EXECUTIVE ENGINEER, MECHANICAL DIVISION', 'BHUBANESHWAR', 'Orissa', 'PROFICIENCY CERTIFICATE', '1448', NULL, NULL, 'English', '', 'BOPT/DAK-08:02:07-2019-10-21', 'forward', NULL, '2019-10-21 08:02:07.264964'),
(53, 2019, '2019-10-21', 'Bill(Stipend)', 'General', 'NIL', '2019-10-17', 'KAIZEN IT SERVICES PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1449', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-09:04:59-2019-10-21', 'forward', NULL, '2019-10-21 09:04:59.800635'),
(54, 2019, '2019-10-21', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/10/1/01', '2019-10-16', 'SKYPRO TECHNOLOGIES PVT. LTD.', 'BANGALORE', 'Karnataka', 'CLAIM BILL', '1450', NULL, NULL, 'English', '', 'BOPT/DAK-09:13:09-2019-10-21', 'closed', NULL, '2019-10-21 09:13:09.264845'),
(55, 2019, '2019-10-21', 'Bill(Stipend)', 'General', 'NIL', '2019-10-15', 'GRAPHITE INDIA LIMITED', 'DURGAPUR', 'West Bengal', 'CLAIM BILL', '1451', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-09:18:03-2019-10-21', 'forward', NULL, '2019-10-21 09:18:03.851823'),
(56, 2019, '2019-10-21', 'Bill(Stipend)', 'General', '092/EDC/DA04/CLAIM/03', '2019-10-16', 'NTPC LIMITED - KAHALGAON', 'BHAGALPUR', 'Bihar', 'CLAIM BILL', '1452', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-09:26:53-2019-10-21', 'forward', NULL, '2019-10-21 09:26:53.516348'),
(57, 2019, '2019-10-21', 'Bill(Stipend)', 'General', 'AISCO/HR/BOPT/SR/03/2019-20', '2019-09-18', 'ARYA IRON & STEEL COMPANY PVT. LTD.', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', '1453', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-09:33:43-2019-10-21', 'forward', NULL, '2019-10-21 09:33:43.088952'),
(58, 2019, '2019-10-21', 'Letter', 'General', 'NIL', '2019-10-17', 'CAPARO ENGINEERING INDIA LTD.', 'JAMSHEDPUR', 'Jharkhand', 'ECS MANDATE FORM', '1454', NULL, NULL, 'English', '', 'BOPT/DAK-09:51:04-2019-10-21', 'forward', NULL, '2019-10-21 09:51:04.333962'),
(59, 2019, '2019-10-22', 'Bill(Stipend)', 'General', 'BAHDL/TM/BOPT/006', '2019-06-18', 'BENGAL AMBUJA HOUSING DEVELOPMENT LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1455', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:43:14-2019-07-01', 'forward', NULL, '2019-07-01 07:43:14.009725'),
(60, 2019, '2019-10-22', 'Bill(Stipend)', 'General', 'BAHDL/TM/BOPT/008', '2019-10-17', 'BENGAL AMBUJA HOUSING DEVELOPMENT LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1456', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:49:02-2019-07-01', 'forward', NULL, '2019-07-01 07:49:02.517703'),
(61, 2019, '2019-10-22', 'Bill(Establishment)', 'General', 'BAHDL/TM/BOPT/005', '2019-10-18', 'BENGAL AMBUJA HOUSING DEVELOPMENT LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1457', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:53:21-2019-07-01', 'forward', NULL, '2019-07-01 07:53:21.750739'),
(62, 2019, '2019-10-22', 'Bill(Stipend)', 'General', 'WEBFIL/P&A/2019-20/58', '2019-10-16', 'WEBFIL LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1458', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:57:28-2019-07-01', 'forward', NULL, '2019-07-01 07:57:28.188032'),
(63, 2019, '2019-10-22', 'Bill(Stipend)', 'General', 'TRG/BOPT/02/2017-18/CLAIM-3', '2019-10-16', 'GARDEN REACH SHIPBUILDERS & ENGINEERING LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1459', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-08:02:16-2019-07-01', 'forward', NULL, '2019-07-01 08:02:16.196737'),
(64, 2019, '2019-10-22', 'Bill(Stipend)', 'General', '1399', '2019-10-03', 'S.K.D.A.V GOVERNMENT POLYTECHNIC', 'ROURKELA', 'West Bengal', 'CLAIM BILL', '1460', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-09:16:14-2019-07-01', 'forward', NULL, '2019-07-01 09:16:15.005150'),
(65, 2019, '2019-10-22', 'Letter', 'General', '9-12/2012-TRG-928', '2019-10-15', 'FARM MECHINERRY TRAINING & TESTING INSTITUTE - ASSAM', 'BISWANATH', 'Assam', 'OFFICE ORDER', '1461', NULL, NULL, 'Hindi', '', 'BOPT/DAK-09:32:45-2019-07-01', 'forward', NULL, '2019-07-01 09:32:45.350590'),
(66, 2019, '2019-10-22', 'Letter', 'General', 'IESL/BOPT/SS/14', '2019-10-18', 'INDIAN EX - SERVICES LEAGUE', 'KOLKATA', 'West Bengal', 'LETTER', '1462', NULL, NULL, 'English', '', 'BOPT/DAK-09:47:39-2019-07-01', 'forward', NULL, '2019-07-01 09:47:39.962476'),
(67, 2019, '2019-10-24', 'Letter', 'General', 'HCL/TRG/BOPT/17', '2019-10-22', 'HINDUSTAN COPPER LIMITED', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', '1463', NULL, NULL, 'English', '', 'BOPT/DAK-07:01:53-2019-10-24', 'forward', NULL, '2019-10-24 07:01:53.585331'),
(68, 2019, '2019-10-24', 'Letter', 'General', '12019/1/2014-NECS', '2019-10-18', 'NORTHEAST CONSULTANCY SERVICES', 'AIZAWL', 'Mizoram', 'APPRENTICESHIP TRAINING', '1464', NULL, NULL, 'English', '', 'BOPT/DAK-07:08:53-2019-10-24', 'forward', NULL, '2019-10-24 07:08:53.264672'),
(69, 2019, '2019-10-24', 'Letter', 'General', '3331', '2019-10-01', 'CENTRAL ELECTRICITY SUPPLY UTILITY OF ODISHA', 'CUTTACK', 'Orissa', 'OFFICE ORDER', '1465', NULL, NULL, 'English', '', 'BOPT/DAK-07:13:45-2019-10-24', 'forward', NULL, '2019-10-24 07:13:45.039595'),
(70, 2019, '2019-10-24', 'Bill(Stipend)', 'General', '18(19)/2018/E-I/4791', '2019-10-18', 'CSIR - INSTT. OF MINERALS & MATERIALS TECHNOLOGY', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', '1466', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:19:34-2019-10-24', 'forward', NULL, '2019-10-24 07:19:34.210846'),
(71, 2019, '2019-10-24', 'Bill(Stipend)', 'General', 'AISCO/HR/BOPT/SR/04/2019-20', '2019-10-19', 'ARYA IRON & STEEL COMPANY PVT. LTD.', 'KEONJHAR', 'Orissa', 'CLAIM BILL', '1467', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:25:05-2019-10-24', 'forward', NULL, '2019-10-24 07:25:05.968088'),
(72, 2019, '2019-10-24', 'Bill(Stipend)', 'General', 'SACPL/16/19-20', '2019-10-18', 'SATI AUTO COMPONENTS PVT. LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', '1468', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:31:37-2019-10-24', 'forward', NULL, '2019-10-24 07:31:37.207779'),
(73, 2019, '2019-10-24', 'Bill(Stipend)', 'General', 'APT/19-20/03', '2019-10-22', 'CHLORIDE POWER SYSTEMS & SOLUTIONS LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1469', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:37:51-2019-10-24', 'forward', NULL, '2019-10-24 07:37:51.634495'),
(74, 2019, '2019-10-24', 'Bill', 'General', 'GST/027', '2019-10-22', 'DHIRAJ & ASSOCIATES', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1470', NULL, NULL, 'English', '', 'BOPT/DAK-07:45:51-2019-10-24', 'forward', NULL, '2019-10-24 07:45:51.782344'),
(75, 2019, '2019-10-24', 'Bill', 'General', '108/2019-20', '2019-10-22', 'VERMA MISHRA & ASSOCIATES', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1471', NULL, NULL, 'English', '', 'BOPT/DAK-07:51:09-2019-10-24', 'forward', NULL, '2019-10-24 07:51:09.884794'),
(76, 2019, '2019-10-24', 'Bill', 'General', '109/2019-20', '2019-10-22', 'VERMA MISHRA & ASSOCIATES', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1472', NULL, NULL, 'English', '', 'BOPT/DAK-07:53:18-2019-10-24', 'forward', NULL, '2019-10-24 07:53:18.589258'),
(77, 2019, '2019-10-24', 'Bill', 'General', '1577', '2019-09-30', 'SALT LAKE SERVICE STATION', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1473', NULL, NULL, 'English', '', 'BOPT/DAK-07:58:33-2019-10-24', 'forward', NULL, '2019-10-24 07:58:33.024496'),
(78, 2019, '2019-10-24', 'Bill', 'General', 'CB/ORG/2019-20/06', '2019-10-22', 'ORIGIN', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1474', NULL, NULL, 'English', '', 'BOPT/DAK-08:05:26-2019-10-24', 'forward', NULL, '2019-10-24 08:05:26.159456'),
(79, 2019, '2019-10-29', 'RTI', 'General', 'NIL', '2019-10-24', 'MR. AVIJIT MITRA, PURBA BARDHAMAN - WB', 'PURBA BARDHAMAN', 'West Bengal', 'RIGHT TO INFORMATION', '1475', NULL, NULL, 'English', '', 'BOPT/DAK-04:59:58-2019-10-29', 'forward', NULL, '2019-10-29 04:59:58.362194'),
(80, 2019, '2019-10-29', 'Bill', 'General', 'EDCWB0015393699', '2019-10-06', 'BHARAT SANCHAR NIGAM LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1476', NULL, NULL, 'English', '', 'BOPT/DAK-05:04:21-2019-10-29', 'forward', NULL, '2019-10-29 05:04:21.310396'),
(81, 2019, '2019-10-29', 'Bill', 'General', 'EDCWB0015194586', '2019-10-06', 'BHARAT SANCHAR NIGAM LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1477', NULL, NULL, 'English', '', 'BOPT/DAK-05:07:36-2019-10-29', 'forward', NULL, '2019-10-29 05:07:36.236212'),
(82, 2019, '2019-10-29', 'Letter', 'General', 'NIL', '2019-10-24', 'MR. TRIDEB KAYAL, BOPT EMPLOYEE', 'KOLKATA', 'West Bengal', NULL, '1478', NULL, NULL, 'English', '', 'BOPT/DAK-05:12:57-2019-10-29', 'forward', NULL, '2019-10-29 05:12:57.995305'),
(83, 2019, '2019-10-29', 'Letter', 'General', 'NIL', '2019-10-19', 'MR. ASHOK SAHA, MURSHIDABAD', 'MURSHIDABAD', 'West Bengal', NULL, '1479', NULL, NULL, 'English', '', 'BOPT/DAK-05:17:55-2019-10-29', 'forward', NULL, '2019-10-29 05:17:55.942878'),
(84, 2019, '2019-10-28', 'Bill(Stipend)', 'General', 'INCP/2019/027', '2019-10-24', 'INCEPTIAL INFRASTRUCTURES & TECHNOLOGY LLP', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1480', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-05:20:49-2019-10-29', 'receipt', NULL, '2019-10-29 05:20:49.915929'),
(85, 2019, '2019-10-28', 'Bill(Stipend)', 'General', 'INCP/2019/027', '2019-10-24', 'INCEPTIAL INFRASTRUCTURES & TECHNOLOGY LLP', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1480', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-05:20:49-2019-10-29', 'forward', NULL, '2019-10-29 05:20:49.994054'),
(86, 2019, '2019-10-29', 'Bill(Stipend)', 'General', 'NIL', '2019-10-23', 'ULTRATECH CEMENT LIMITED', 'JHARSUGUDA', 'Orissa', 'CLAIM BILL', '1481', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-05:24:09-2019-10-29', 'forward', NULL, '2019-10-29 05:24:09.260213'),
(87, 2019, '2019-10-29', 'Letter', 'General', 'NIL', '2019-10-23', 'MRS. ABHA MITRA, EX EMPLOYEE', 'KOLKATA', 'West Bengal', 'SUBMISSION OF PAN & ADHAR', '1482', NULL, NULL, 'English', '', 'BOPT/DAK-05:27:50-2019-10-29', 'forward', NULL, '2019-10-29 05:27:50.870183'),
(88, 2019, '2019-10-29', 'Letter', 'General', 'NIL', '2019-10-23', 'MR. SAMAR RAY, EX EMPLOYEE', 'KOLKATA', 'West Bengal', 'SUBMISSION OF PAN & ADHAR', '1483', NULL, NULL, 'English', '', 'BOPT/DAK-05:33:21-2019-10-29', 'forward', NULL, '2019-10-29 05:33:21.335733'),
(89, 2019, '2019-10-29', 'Bill', 'General', 'BL-TV/CCU/BPT', '2019-10-23', 'BALMER LAWRIE & CO. LIMITED', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1484', NULL, NULL, 'English', '', 'BOPT/DAK-05:36:43-2019-10-29', 'forward', NULL, '2019-10-29 05:36:43.427177'),
(90, 2019, '2019-10-29', 'Letter', 'General', 'EDPL/HR/72/2019-20', '2019-10-24', 'EMDEE DIGITRONICS PVT. LTD.', 'KOLKATA', 'West Bengal', 'APPRENTICESHIP TRAINING', '1485', NULL, NULL, 'English', '', 'BOPT/DAK-05:43:16-2019-10-29', 'forward', NULL, '2019-10-29 05:43:16.568217'),
(91, 2019, '2019-10-29', 'Letter', 'General', 'NIL', '2019-07-11', 'BIRLA CORPORATION LIMITED', 'KOLKATA', 'West Bengal', 'APPRENTICESHIP TRAINING', '1486', NULL, NULL, 'English', '', 'BOPT/DAK-05:56:21-2019-10-29', 'forward', NULL, '2019-10-29 05:56:21.299142'),
(92, 2019, '2019-10-29', 'Letter', 'General', 'BIL/HR/APPRENTICE/2019/001', '2019-10-19', 'BRITANNIA INDUSTRIES LIMITED', 'KOLKATA', 'West Bengal', 'ENGAGEMENT OF TRAINEE', '1487', NULL, NULL, 'English', '', 'BOPT/DAK-06:06:07-2019-10-29', 'forward', NULL, '2019-10-29 06:06:07.320011'),
(93, 2019, '2019-10-29', 'Letter', 'General', 'CCL/TRG/PDPT/KIT/18-19/1485', '2019-02-07', 'CENTRAL COALFIELDS LIMITED - RANCHI', 'RANCHI', 'Jharkhand', 'APPRENTICESHIP TRAINING', '1488', NULL, NULL, 'English', '', 'BOPT/DAK-06:13:50-2019-10-29', 'forward', NULL, '2019-10-29 06:13:50.030848'),
(94, 2019, '2019-10-29', 'Letter', 'General', 'GM(D)/SO(HRD/GVTC/PDPT/2019/2448', '2019-03-13', 'CENTRAL COALFIELDS LIMITED -BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', '1489', NULL, NULL, 'English', '', 'BOPT/DAK-06:19:10-2019-10-29', 'forward', NULL, '2019-10-29 06:19:10.868455'),
(95, 2019, '2019-10-29', 'Letter', 'Select', 'WESCO/HR.ESTT/7222', '2019-10-21', 'WESCO UTILITY', 'SAMBALPUR', 'Orissa', 'APPRENTICESHIP TRAINING', '1490', NULL, NULL, 'English', '', 'BOPT/DAK-06:42:32-2019-10-29', 'forward', NULL, '2019-10-29 06:42:32.601755'),
(96, 2019, '2019-10-29', 'Letter', 'General', 'NIL', '2019-10-22', 'UTKAL MOTORS PVT. LTD.', 'CUTTACK', 'Orissa', 'SHOW CAUSE NOTICE', '1491', NULL, NULL, 'English', '', 'BOPT/DAK-06:45:23-2019-10-29', 'forward', NULL, '2019-10-29 06:45:23.927693'),
(97, 2019, '2019-10-29', 'Letter', 'General', 'MCL/HRD/PDPT/2019-20/642', '2019-10-15', 'MAHANADI COALFIELDS LIMITED', 'SAMBALPUR', 'Orissa', 'OFFICE ORDER', '1492', NULL, NULL, 'English', '', 'BOPT/DAK-06:49:00-2019-10-29', 'forward', NULL, '2019-10-29 06:49:00.475252'),
(98, 2019, '2019-10-29', 'Letter', 'General', 'SBML/HR/2019-20/592', '2019-10-21', 'SHREE BHARAT MOTORS LTD.', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', '1493', NULL, NULL, 'English', '', 'BOPT/DAK-06:52:49-2019-10-29', 'forward', NULL, '2019-10-29 06:52:49.830554'),
(99, 2019, '2019-11-01', 'Letter', 'General', 'GM/HRD/TRG/BOPT/460', '2019-10-23', 'WEST BENGAL STATE ELECTRICITY DISTRIBUTION COMPANY LIMITED', 'KOLKATA', 'West Bengal', 'REG-NATS PORTAL', '1495', NULL, NULL, 'English', '', 'BOPT/DAK-05:22:27-2019-11-01', 'forward', NULL, '2019-11-01 05:22:27.518287'),
(100, 2019, '2019-11-01', 'Letter', 'General', 'NIL', '2019-10-21', 'PRICE WATER HOUSE COOPERS PVT. LTD.', 'GURUGRAM', 'Haryana', 'SHOW CAUSE NOTICE', '1496', NULL, NULL, 'English', '', 'BOPT/DAK-05:33:24-2019-11-01', 'forward', NULL, '2019-11-01 05:33:24.673400'),
(101, 2019, '2019-11-01', 'Letter', 'General', 'CC/2019-20/100', '2019-10-28', 'CANS & CLOSURES PVT. LTD.', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', '1497', NULL, NULL, 'English', '', 'BOPT/DAK-05:42:17-2019-11-01', 'forward', NULL, '2019-11-01 05:42:17.943329'),
(102, 2019, '2019-11-01', 'Letter', 'General', 'NIL', '2019-10-29', 'CHEVIOT AGRO INDUSTRIES PVT. LTD.', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', '1496', NULL, NULL, 'English', '', 'BOPT/DAK-05:47:08-2019-11-01', 'forward', NULL, '2019-11-01 05:47:08.906204'),
(103, 2019, '2019-11-01', 'Letter', 'General', 'NCP/132/19-20', '2019-10-26', 'NEELACHAL CONCRETE PRODUCTS PRIVATE LIMITED', 'BALASORE', 'Orissa', 'SHOW CAUSE NOTICE', '1498', NULL, NULL, 'English', '', 'BOPT/DAK-05:55:50-2019-11-01', 'forward', NULL, '2019-11-01 05:55:50.335447'),
(104, 2019, '2019-11-01', 'Letter', 'General', 'SPL/GCOG/BOPT/0134/2019', '2019-10-25', 'SWOSTI PREMIUM LTD.', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', '1499', NULL, NULL, 'English', '', 'BOPT/DAK-06:06:49-2019-11-01', 'forward', NULL, '2019-11-01 06:06:49.828697'),
(105, 2019, '2019-11-01', 'Letter', 'General', 'BTPL/BOPT/NATS/JB/244', '2019-10-21', 'BENZFAB TECHNOLOGIES PVT. LTD.', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', '1500', NULL, NULL, 'English', '', 'BOPT/DAK-06:13:18-2019-11-01', 'forward', NULL, '2019-11-01 06:13:18.322230'),
(106, 2019, '2019-11-01', 'Letter', 'General', 'NIL', '2019-10-21', 'ADITYA BIRLA FASHION AND RETAIL LIMITED', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', '1501', NULL, 'NIL', 'English', '', 'BOPT/DAK-06:18:41-2019-11-01', 'forward', NULL, '2019-11-01 06:18:41.278960'),
(107, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'BCPL/HR/STIPEND CLAIM/APPRENTICE/7-9/2018-19', '2019-10-29', 'BRAHMAPUTRA CRACKER AND POLYMER LIMITED', 'DIBRUGARH', 'Assam', 'CLAIM BILL', '1502', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-06:24:54-2019-11-01', 'forward', NULL, '2019-11-01 06:24:54.245592'),
(108, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'NIL', '2019-10-28', 'DPS EASTERN PRIVATE LIMITED - JAMSHEDPUR', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', '1503', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-06:34:25-2019-11-01', 'forward', NULL, '2019-11-01 06:34:25.325714'),
(109, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'UMTI/BOPT/19-20/05', '2019-10-16', 'USHA MARTIN TRAINING INSTITUTE', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', '1504', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-06:42:59-2019-11-01', 'forward', NULL, '2019-11-01 06:42:59.767552'),
(110, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'NIL', '2019-10-25', 'JAGDAMBA POLYMERS PRIVATE LIMITED', 'BALASORE', 'Orissa', 'CLAIM BILL', '1505', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-06:52:09-2019-11-01', 'forward', NULL, '2019-11-01 06:52:09.244420'),
(111, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'NIL', '2019-10-28', 'BENNETT, COLEMAN & CO., LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1506', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-06:57:01-2019-11-01', 'forward', NULL, '2019-11-01 06:57:01.153350'),
(112, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'STI1910196', '2019-10-23', 'PRAVAT FABRICATORS PVT. LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', '1507', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:02:24-2019-11-01', 'forward', NULL, '2019-11-01 07:02:25.003133'),
(113, 2019, '2019-11-01', 'Bill(Stipend)', 'General', 'TRG/BOPT/02/2017-18/CLAIM-4', '2019-10-23', 'GARDEN REACH SHIPBUILDERS & ENGINEERS LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'CLAIM BILL', '1508', NULL, 'CLAIM BILL FORM', 'English', '', 'BOPT/DAK-07:09:35-2019-11-01', 'forward', NULL, '2019-11-01 07:09:35.686113'),
(114, 2019, '2019-11-01', 'Bill', 'General', 'TDS/1920/24Q/D/100035565029', '2019-10-21', 'TDS - CENTRALIZED PROCESSING CELL', 'GHAZIABAD', 'Uttar Pradesh', 'TAX INVOICE', '1509', NULL, NULL, 'English', '', 'BOPT/DAK-07:21:46-2019-11-01', 'forward', NULL, '2019-11-01 07:21:46.700512'),
(115, 2019, '2019-11-01', 'Letter', 'General', 'NIL', '2019-10-26', 'MR. SURAJIT BOSE, EX EMPLOYEE', 'KOLKATA', 'West Bengal', 'SUBMISSION OF PAN & ADHAR', '1510', NULL, NULL, 'English', '', 'BOPT/DAK-07:25:21-2019-11-01', 'forward', NULL, '2019-11-01 07:25:21.125948'),
(116, 2019, '2019-11-01', 'Letter', 'General', 'NIL', '2019-10-30', 'MR. ARUN KR. MUKHERJEE, EX EMPLOYEE', 'KOLKATA', 'West Bengal', 'SUBMISSION OF PAN & ADHAR', '1511', NULL, NULL, 'English', '', 'BOPT/DAK-07:28:56-2019-11-01', 'forward', NULL, '2019-11-01 07:28:56.852459'),
(117, 2019, '2019-11-01', 'Bill', 'General', 'OE/19-20/WB/1934', '2019-10-01', 'ORION EDUTECH PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', '1512', NULL, NULL, 'English', '', 'BOPT/DAK-07:37:38-2019-11-01', 'forward', NULL, '2019-11-01 07:37:38.994743'),
(118, 2019, '2019-11-28', 'Letter', 'General', 'NIL', '2019-11-26', 'MR. MD MUBARAK ALI, BARDHAMAN', 'BARDHAMAN', 'West Bengal', 'CORRECTION OF CERTIFICATE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:10:28-2019-11-28', 'forward', NULL, '2019-11-28 09:10:28.410607'),
(119, 2019, '2019-11-28', 'Letter', 'General', 'CCL/TRG/PDPT/19-20/839', '2019-10-16', 'CENTRAL COALFIELDS LIMITED - RANCHI', 'RANCHI', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:16:03-2019-11-28', 'forward', NULL, '2019-11-28 09:16:03.146021'),
(120, 2019, '2019-11-28', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1519', '2019-11-21', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:18:11-2019-11-28', 'forward', NULL, '2019-11-28 09:18:11.483465'),
(121, 2019, '2019-11-28', 'Letter', 'General', 'NIL', '2019-11-27', 'JAGADAMBA POLYMERS PRIVATE LIMITED', 'ODISHA', 'Orissa', 'ECS MANDATE FORM', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:24:10-2019-11-28', 'forward', NULL, '2019-11-28 09:24:10.628294'),
(122, 2019, '2019-11-28', 'Letter', 'General', 'DDK/IMP-23(11)2019-20/APP/1084', '2019-11-13', 'PRASAR BHARATI - IMPHAL', 'IMPHAL', 'Manipur', 'SANCTION ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:27:07-2019-11-28', 'forward', NULL, '2019-11-28 09:27:07.104530'),
(123, 2019, '2019-11-28', 'Letter', 'General', 'MCL/PO(T&H)/PDPT/2019/8749', '2019-11-22', 'MAHANADI COALFIELDS LIMITED', 'JHARSUGUDA', 'Punjab', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:29:41-2019-11-28', 'forward', NULL, '2019-11-28 09:29:41.729500'),
(124, 2019, '2019-11-28', 'Select', 'Select', 'MISL/PERS/BOPT/2019/2411', '2019-11-21', 'MIDEAST INTEGRATED STEELS LIMITED', 'BHUBANESHWAR', 'Orissa', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:32:03-2019-11-28', 'forward', NULL, '2019-11-28 09:32:03.447717'),
(125, 2019, '2019-11-29', 'Letter', 'General', 'ERPL/HR/APP/2019', '2019-11-15', 'INDIAN OIL CORPORATIO LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:47:17-2019-11-29', 'forward', NULL, '2019-11-29 06:47:17.224975'),
(126, 2019, '2019-11-29', 'Letter', 'General', 'NIL', '2019-11-28', 'MR. SUDIP KR. GIRI, MEDINIPUR EAST', 'MEDINIPUR EAST', 'West Bengal', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:59:04-2019-11-29', 'forward', NULL, '2019-11-29 06:59:04.943021'),
(127, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'AAI/JS/ADMIN-17/232', '2019-11-20', 'AIRPORTS AUTHORITY OF INDIA - JAMSHEDPUR', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:02:45-2019-11-29', 'forward', NULL, '2019-11-29 07:02:45.627821'),
(128, 2019, '2019-11-29', 'Letter', 'General', '2146', '2019-11-25', 'BIHAR STATE MILK CO-OPERATIVE FEDERATION LTD.', 'PATNA', 'Bihar', 'OFFICE ORDER', NULL, NULL, NULL, 'Hindi', '', 'BOPT/DAK-07:08:05-2019-11-29', 'forward', NULL, '2019-11-29 07:08:05.289360'),
(129, 2019, '2019-11-29', 'Letter', 'General', 'NIL', '2019-11-28', 'OSD - ODISHA', 'BHUBANESHWAR', 'Orissa', 'WEEKLY REPORT', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:13:07-2019-11-29', 'forward', NULL, '2019-11-29 07:13:07.799906'),
(130, 2019, '2019-11-29', 'Letter', 'General', '5706', '2019-11-20', 'SKILL DEVELOPMENT AND TECHNICAL EDUCATION DEPT. - GOVT. OF ODISHA', 'BHUBANESHWAR', 'Orissa', 'LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:38:56-2019-11-29', 'forward', NULL, '2019-11-29 07:38:56.440725'),
(131, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'NIL', '2019-11-27', 'EXPERIS IT PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:41:06-2019-11-29', 'forward', NULL, '2019-11-29 07:41:06.097245'),
(132, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'NIL', '2019-11-27', 'EXPERIS IT PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:42:59-2019-11-29', 'forward', NULL, '2019-11-29 07:42:59.295811'),
(133, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'NIL', '2019-11-27', 'EXPERIS IT PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:45:38-2019-11-29', 'forward', NULL, '2019-11-29 07:45:38.921069'),
(134, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'NIL', '2019-11-20', 'EXPERIS IT PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:46:37-2019-11-29', 'forward', NULL, '2019-11-29 07:46:37.256453'),
(135, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'NIL', '2019-11-23', 'GLENMARK PHARMACEUTICALS LIMITED - SIKKIM', 'SIKKIM', 'Sikkim', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:51:46-2019-11-29', 'forward', NULL, '2019-11-29 07:51:46.215372'),
(136, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'EXIDE/HAL/PLANT/HR/BOPT/19/3765', '2019-11-22', 'EXIDE INDUSTRIES LIMITED', 'HALDIA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:56:27-2019-11-29', 'forward', NULL, '2019-11-29 07:56:27.895709'),
(137, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'AAI/RNC/HR/C-5/407', '2019-11-22', 'AIRPORTS AUTHORITY OF INDIA - RANCHI', 'RANCHI', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-08:00:37-2019-11-29', 'forward', NULL, '2019-11-29 08:00:37.610192'),
(138, 2019, '2019-11-29', 'Bill(Stipend)', 'General', 'NIL', '2019-11-28', 'BENNETT, COLEMAN & CO., LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-08:02:54-2019-11-29', 'forward', NULL, '2019-11-29 08:02:54.785148'),
(139, 2019, '2019-11-29', 'Bill', 'General', 'NIL', '2019-11-28', 'OSD - ODISHA', 'BHUBANESHWAR', 'Orissa', 'T. A. BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-08:04:21-2019-11-29', 'forward', NULL, '2019-11-29 08:04:21.825197'),
(140, 2019, '2019-12-12', 'Letter', 'General', 'G.M(D)/SO(HRD)GVTC/TRG/PDPT/2019/1537', '2019-11-25', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:00:53-2019-12-12', 'forward', NULL, '2019-12-12 07:00:53.247689'),
(141, 2019, '2019-12-12', 'Letter', 'General', 'G.M(D)/SO(HRD)GVTC/TRG/PDPT/2019/1374', '2019-11-04', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:02:28-2019-12-12', 'forward', NULL, '2019-12-12 07:02:28.875236'),
(142, 2019, '2019-12-12', 'Letter', 'General', '50364', '2019-11-29', 'OFFICE OF THE ENGINEER-IN-CHIEF (CIVIL), BHUBANESWAR', 'BHUBANESHWAR', 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:08:56-2019-12-12', 'forward', NULL, '2019-12-12 07:08:56.686728'),
(143, 2019, '2019-12-12', 'Letter', 'General', 'CPA/205/19', '2019-12-06', 'FERRO ALLOYS CORPORATION LIMITED', 'BHADRAK', 'Orissa', 'CONTRACT REGISTRATION', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:10:59-2019-12-12', 'forward', NULL, '2019-12-12 07:10:59.343842'),
(144, 2019, '2019-12-12', 'Bill(Stipend)', 'General', 'HNG/CLAIM/19-20/4241', '2019-12-10', 'HINDUSTAN NATIONAL GLASS & INDUSTRIES LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:12:45-2019-12-12', 'forward', NULL, '2019-12-12 07:12:45.085975'),
(145, 2019, '2019-12-12', 'Bill(Stipend)', 'General', 'SSIL/2019-20/AS/592', '2019-12-07', 'SHYAM STEEL INDUSTRIES LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:15:05-2019-12-12', 'forward', NULL, '2019-12-12 07:15:05.660129'),
(146, 2019, '2019-12-12', 'Bill(Stipend)', 'General', 'NIL', '2019-12-06', 'ONPROCESS TECHNOLOGIES INDIA PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:17:06-2019-12-12', 'forward', NULL, '2019-12-12 07:17:06.099114'),
(147, 2019, '2019-12-12', 'Bill(Stipend)', 'General', 'TD-HO-07/2017/28913', '2019-12-06', 'ODISHA POWER TRANSMISSION CORPORATION LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:18:45-2019-12-12', 'forward', NULL, '2019-12-12 07:18:45.734892'),
(148, 2019, '2019-12-12', 'Bill(Stipend)', 'General', 'TD-HO-07/2017/28916', '2019-12-06', 'ODISHA POWER TRANSMISSION CORPORATION LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:20:23-2019-12-12', 'forward', NULL, '2019-12-12 07:20:23.186545'),
(149, 2019, '2019-12-12', 'Bill(Stipend)', 'General', 'NIL', '2019-12-07', 'NEW GOVT. POLYTECHNIC - PATNA', 'PATNA', 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:21:58-2019-12-12', 'forward', NULL, '2019-12-12 07:21:58.335063'),
(150, 2019, '2019-12-12', 'Bill(Stipend)', 'General', '12019/1/2014-NECS', '2019-12-02', 'NORTHEAST CONSULTANCY SERVICES', 'GUWAHATI', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:25:34-2019-12-12', 'forward', NULL, '2019-12-12 07:25:34.173582'),
(151, 2019, '2019-12-12', 'Bill', 'General', 'OE/19-20/WB/2781', '2019-12-09', 'ORION EDUTECH PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:29:25-2019-12-12', 'forward', NULL, '2019-12-12 07:29:25.752013'),
(152, 2019, '2019-12-12', 'Bill', 'General', 'OE/19-20/WB/2782', '2019-12-09', 'ORION EDUTECH PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:32:32-2019-12-12', 'forward', NULL, '2019-12-12 07:32:32.472843'),
(153, 2019, '2019-12-12', 'Bill', 'General', 'FS-1861/509-UM', '2019-12-10', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:35:49-2019-12-12', 'forward', NULL, '2019-12-12 07:35:49.415265'),
(154, 2019, '2019-12-12', 'Bill', 'General', 'FS-1862/510-UM', '2019-12-10', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:37:11-2019-12-12', 'forward', NULL, '2019-12-12 07:37:11.790043'),
(155, 2019, '2019-12-12', 'Bill', 'General', 'FS-547/169-UM', '2019-12-10', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:39:30-2019-12-12', 'forward', NULL, '2019-12-12 07:39:30.847107'),
(156, 2019, '2019-12-12', 'Letter', 'Urgent', 'NIL', '2019-12-12', 'MR. SAKET KRISHNAN, BOPT EMPLOYEE', 'KOLKATA', 'West Bengal', 'RESIGNATION LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:41:22-2019-12-12', 'forward', NULL, '2019-12-12 07:41:22.692595'),
(157, 2019, '2019-12-16', 'Letter', 'General', '33023/7/2018-DTE(RD)ESTT', '2019-12-02', 'RURAL DEVELOPMENT DEPT. GOVT. OF MIZORAM', 'AIZAWL', 'Mizoram', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:53:54-2019-12-16', 'forward', NULL, '2019-12-16 07:53:54.144734'),
(158, 2019, '2019-12-16', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1538', '2019-11-25', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:55:19-2019-12-16', 'forward', NULL, '2019-12-16 07:55:19.454652'),
(159, 2019, '2019-12-16', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1536', '2019-11-25', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:56:24-2019-12-16', 'forward', NULL, '2019-12-16 07:56:24.333390'),
(160, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'CPA/206/19', '2019-12-09', 'FERRO ALLOYS CORPORATION LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:07:16-2019-12-16', 'forward', NULL, '2019-12-16 09:07:16.249438'),
(161, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'NIL', '2019-12-11', 'INDIA POWER CORPORATION LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:11:26-2019-12-16', 'forward', NULL, '2019-12-16 09:11:26.894882'),
(162, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'NIL', '2019-12-11', 'INDIA POWER CORPORATION LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:12:41-2019-12-16', 'forward', NULL, '2019-12-16 09:12:41.292171'),
(163, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'TRG/VIII-(10)/280', '2019-12-03', 'BRAHMAPUTRA VALLY FERTILIZER CORPORATION LIMITED - ASSAM', 'KAMRUP', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:14:40-2019-12-16', 'forward', NULL, '2019-12-16 09:14:40.566046'),
(164, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'STI1914931', '2019-11-19', 'ELECTRONICS REGIONAL TEST LABORATORY', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:17:21-2019-12-16', 'forward', NULL, '2019-12-16 09:17:21.734333'),
(165, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'BGR/HR/L&D/58', '2019-12-03', 'INDIAN OIL CORPORATION LIMITED - BONGAIGAON REFINERY', 'GUWAHATI', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:26:53-2019-12-16', 'forward', NULL, '2019-12-16 09:26:53.974313'),
(166, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'BGR/HR/L&D/58', '2019-12-03', 'INDIAN OIL CORPORATION LIMITED - BONGAIGAON REFINERY', 'GUWAHATI', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:28:46-2019-12-16', 'forward', NULL, '2019-12-16 09:28:46.672808'),
(167, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'BGR/HR/L&D/58', '2019-12-03', 'INDIAN OIL CORPORATION LIMITED - BONGAIGAON REFINERY', 'GUWAHATI', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:32:30-2019-12-16', 'forward', NULL, '2019-12-16 09:32:30.595713'),
(168, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'NIL', '2019-12-10', 'INTAS PHARMACEUTICALS LIMITED - SIKKIM', 'SIKKIM', 'Sikkim', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:34:39-2019-12-16', 'forward', NULL, '2019-12-16 09:34:39.825160'),
(169, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'NIL', '2019-12-10', 'INTAS PHARMACEUTICALS LIMITED - SIKKIM', 'SIKKIM', 'Sikkim', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:36:00-2019-12-16', 'forward', NULL, '2019-12-16 09:36:00.165791'),
(170, 2019, '2019-12-16', 'Bill(Stipend)', 'General', 'PL/HR/ESTB/APPR-2018(1)', '2019-12-09', 'INDIAN OIL CORPORATION LIMITED - BHUBANESHWAR', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:40:41-2019-12-16', 'forward', NULL, '2019-12-16 09:40:41.062980'),
(171, 2019, '2019-12-16', 'Bill(Establishment)', 'General', 'NIL', '2019-12-10', 'UNITED ENGINEERS PVT. LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CANCELLED CHEQUE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:42:46-2019-12-16', 'forward', NULL, '2019-12-16 09:42:46.801227'),
(172, 2019, '2019-12-16', 'Bill', 'General', 'GD1920-011470', '2019-12-06', 'GUJRAL DISRIBUTORS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:44:58-2019-12-16', 'forward', NULL, '2019-12-16 09:44:58.085793'),
(173, 2019, '2019-12-16', 'Bill', 'General', '2116', '2019-11-30', 'SALT LAKE SERVICE STATION', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:48:46-2019-12-16', 'forward', NULL, '2019-12-16 09:48:46.455954'),
(174, 2019, '2019-12-16', 'Letter', 'General', 'NIL', '2019-12-03', 'NATIONAL ARCHIVES OF INDIA, MINISTRY OF CULTURE', 'NEW DELHI', 'Delhi', 'LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:52:06-2019-12-16', 'forward', NULL, '2019-12-16 09:52:06.647492'),
(175, 2019, '2019-12-18', 'Bill', 'General', 'AAI/PB/APD/NATS/2019/1781', '2019-12-12', 'AIRPORTS AUTHORITY OF INDIA - PORT BLAIR', 'PORT BLAIR', 'Andaman and Nicobar Islands', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:11:06-2019-12-18', 'forward', NULL, '2019-12-18 10:11:06.336648'),
(176, 2019, '2019-12-18', 'Letter', 'General', 'NIL', '2019-12-09', 'HALDIA STEELS PVT. LTD.', 'HALDIA', 'West Bengal', 'SHOW CAUSE NOTICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:12:33-2019-12-18', 'forward', NULL, '2019-12-18 10:12:33.774687'),
(177, 2019, '2019-12-18', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1674', '2019-12-11', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:14:09-2019-12-18', 'forward', NULL, '2019-12-18 10:14:09.843223'),
(178, 2019, '2019-12-18', 'Letter', 'General', 'HRD/HQ/2019-250', '2019-12-05', 'HEAVY ENGINEERING CORPORATION LIMITED - RANCHI', 'RANCHI', 'Jharkhand', 'INTERNSHIP PROGRAMME', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:16:46-2019-12-18', 'forward', NULL, '2019-12-18 10:16:46.157232'),
(179, 2019, '2019-12-18', 'Letter', 'General', 'NISER/LIB/APPR/19/3723', '2019-12-06', 'NATIONAL INSTT. OF SCIENCE EDUCATION AND RESEARCH - ODISHA', 'BHUBANESWAR', 'Orissa', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:18:38-2019-12-18', 'forward', NULL, '2019-12-18 10:18:38.476705'),
(180, 2019, '2019-12-18', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/17/12/19-20', '2019-12-13', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:58:36-2019-12-18', 'forward', NULL, '2019-12-18 10:58:36.148149'),
(181, 2019, '2019-12-18', 'Select', 'General', 'BOPT/CLAIM/18/12/19-20', '2019-12-13', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:59:54-2019-12-18', 'forward', NULL, '2019-12-18 10:59:54.334684'),
(182, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'SSS/2019/101', '2019-11-26', 'SOFTWARE SERVICES AND SOLUTIONS - PATNA', 'PATNA', 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:38:57-2019-12-19', 'forward', NULL, '2019-12-19 05:38:57.495315');
INSERT INTO `dak_receipt_details` (`id`, `diary_year`, `diary_date`, `receipt_type`, `receipt_category`, `reference_no`, `reference_date`, `sender_name`, `address`, `state`, `subject`, `remarks`, `dealing_head`, `enclosure_details`, `rec_lan`, `other_lan`, `dairy_no`, `doc_status`, `updated_at`, `created_at`) VALUES
(183, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'BALB/HR/1574', '2019-12-11', 'BALASORE ALLOYS LIMITED', 'BALASORE', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:42:58-2019-12-19', 'forward', NULL, '2019-12-19 05:42:58.124182'),
(184, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'HRLC/BOPT/19-20/01S', '2019-12-11', 'INDIAN OIL CORPORATION LIMITED - HALDIA', 'HALDIA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:44:24-2019-12-19', 'forward', NULL, '2019-12-19 05:44:24.066135'),
(185, 2019, '2019-12-19', 'Bill(Establishment)', 'General', 'HR/BOPT/DEC/06', '2019-12-06', 'SAM SOFTECH CONSULTANCY PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:50:02-2019-12-19', 'forward', NULL, '2019-12-19 05:50:02.751654'),
(186, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/12/11/01', '2019-12-11', 'SKYPRO TECHNOLOGIES PVT. LTD.', 'BANGALORE', 'Karnataka', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:51:56-2019-12-19', 'forward', NULL, '2019-12-19 05:51:56.628217'),
(187, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/12/11/02', '2019-12-11', 'SKYPRO TECHNOLOGIES PVT. LTD.', 'BANGALORE', 'Karnataka', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:53:30-2019-12-19', 'forward', NULL, '2019-12-19 05:53:30.895650'),
(188, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/12/11/03', '2019-12-11', 'SKYPRO TECHNOLOGIES PVT. LTD.', 'BANGALORE', 'Karnataka', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:54:46-2019-12-19', 'forward', NULL, '2019-12-19 05:54:46.233992'),
(189, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/12/11/04', '2019-12-11', 'SKYPRO TECHNOLOGIES PVT. LTD.', 'BANGALORE', 'Karnataka', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:56:03-2019-12-19', 'forward', NULL, '2019-12-19 05:56:03.796462'),
(190, 2019, '2019-12-19', 'Select', 'Select', 'PPL/NLDC/19-20/30', '2019-12-09', 'PARADEEP PHOSPHATES LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:58:42-2019-12-19', 'forward', NULL, '2019-12-19 05:58:42.519610'),
(191, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'STI1915701', '2019-11-28', 'DHANASHREE ELECTRONICS LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:00:26-2019-12-19', 'forward', NULL, '2019-12-19 06:00:26.245589'),
(192, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'NIL', '2019-12-18', 'EWEBTONIC SERVICES PVT. LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:02:18-2019-12-19', 'forward', NULL, '2019-12-19 06:02:18.887080'),
(193, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'NIL', '2019-12-13', 'EXPERIS IT PVT. LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:03:54-2019-12-19', 'forward', NULL, '2019-12-19 06:03:54.607597'),
(194, 2019, '2019-12-19', 'Bill(Stipend)', 'General', 'SNTI/P&I/BOPT/569/18', '2019-12-13', 'TATA STEEL LIMITED', 'RANCHI', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:05:24-2019-12-19', 'forward', NULL, '2019-12-19 06:05:24.519778'),
(195, 2019, '2019-12-19', 'Bill', 'General', '668', '2019-11-29', 'LAKE PLACE', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:07:34-2019-12-19', 'forward', NULL, '2019-12-19 06:07:34.313258'),
(196, 2019, '2019-12-19', 'Bill', 'General', 'BL-TV/CCU/BPT', '2019-12-13', 'BALMER LAWRIE & CO. LIMITED', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:10:26-2019-12-19', 'forward', NULL, '2019-12-19 06:10:26.731195'),
(197, 2019, '2020-01-02', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1377', '2019-11-04', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:03:27-2020-01-02', 'forward', NULL, '2020-01-02 10:03:27.066580'),
(198, 2019, '2020-01-02', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1384', '2019-11-04', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:05:20-2020-01-02', 'forward', NULL, '2020-01-02 10:05:20.900182'),
(199, 2019, '2020-01-02', 'Letter', 'General', 'NIL', '2020-01-01', 'MR. SHUBHAM KR. PRAJAPATI,BOKARO', 'BOKARO', 'Jharkhand', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:06:52-2020-01-02', 'forward', NULL, '2020-01-02 10:06:52.719507'),
(200, 2019, '2020-01-02', 'Letter', 'General', 'JMLB/15/G.APP/2019-20/1102-04', '2019-12-14', 'THE ASSAM CO-OPERATIVE JUTE MILLS', 'ASSAM', 'Assam', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:08:37-2020-01-02', 'forward', NULL, '2020-01-02 10:08:37.581589'),
(201, 2019, '2020-01-02', 'Letter', 'General', '13255', '2019-12-17', 'OFFICE OF THE ENGINEER-IN-CHIEF, PUBLIC HEALTH - ODISHA', 'BHUBANESHWAR', 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:10:54-2020-01-02', 'forward', NULL, '2020-01-02 10:10:54.488530'),
(202, 2019, '2020-01-02', 'Bill(Stipend)', 'General', 'NEEPCO/AGTCCPP/TRG-3/2019-20/3342', '2019-12-23', 'NORTH EASTERN ELECTRICAL POWER CORP. LIMITED', 'ASSAM', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:12:38-2020-01-02', 'forward', NULL, '2020-01-02 10:12:38.940588'),
(203, 2019, '2020-01-02', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/24/19-20', '2019-12-30', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:14:32-2020-01-02', 'forward', NULL, '2020-01-02 10:14:32.689186'),
(204, 2019, '2020-01-02', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/23/19-20', '2019-12-30', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:15:55-2020-01-02', 'forward', NULL, '2020-01-02 10:15:55.517989'),
(205, 2019, '2020-01-02', 'Bill(Stipend)', 'General', 'BALB/HR/1633', '2019-12-26', 'BALASORE ALLOYS LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:17:32-2020-01-02', 'forward', NULL, '2020-01-02 10:17:32.304603'),
(206, 2019, '2020-01-07', 'Letter', 'General', 'CAL/FCTY/19-20', '2020-01-03', 'STADMED PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:32:11-2020-01-07', 'forward', NULL, '2020-01-07 09:32:11.010879'),
(207, 2019, '2020-01-07', 'Letter', 'General', 'NIL', '2019-12-20', 'PRICEWATERHOUSE COOPERS PVT. LTD.', 'KOLKATA', 'West Bengal', 'SHOW CAUSE NOTICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:33:47-2020-01-07', 'forward', NULL, '2020-01-07 09:33:48.001469'),
(208, 2019, '2020-01-07', 'Letter', 'General', 'NIL', '2019-12-26', 'BUILDING CONSTRUCTION DEPARTMENT, GOVT. OF BIHAR', 'PATNA', 'Bihar', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Hindi', '', 'BOPT/DAK-09:36:11-2020-01-07', 'forward', NULL, '2020-01-07 09:36:12.001769'),
(209, 2019, '2020-01-07', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1687', '2019-12-14', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:38:16-2020-01-07', 'forward', NULL, '2020-01-07 09:38:16.064919'),
(210, 2019, '2020-01-07', 'Letter', 'General', 'AIR/SIL-26(2)/APP/2019/1538', '2019-12-19', 'PRASAR BHARARTI - SILCHAR', 'SILCHAR', 'Assam', 'REG - NATS PORTAL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:41:32-2020-01-07', 'forward', NULL, '2020-01-07 09:41:32.267226'),
(211, 2019, '2020-01-07', 'Letter', 'General', '11362', '2019-12-07', 'OFFICE OF THE EXECUTIVE ENGINEER, CUTTACK (R&B) DIVISION NO-I', 'BHUBANESHWAR', 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:45:28-2020-01-07', 'forward', NULL, '2020-01-07 09:45:28.708853'),
(212, 2019, '2020-01-07', 'Letter', 'General', 'CESU/ESTT/10-27/26580', '2019-12-31', 'CENTRAL ELECTRICITY SUPPLY UTILITY OF ODISHA', 'BHUBANESHWAR', 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:50:14-2020-01-07', 'forward', NULL, '2020-01-07 09:50:14.732338'),
(213, 2019, '2020-01-07', 'Letter', 'General', '10953', '2019-12-30', 'OFFICE OF THE ENGINEER-IN-CHIEF, RURAL WATER SUPPLY & SANITATION', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-09:58:28-2020-01-07', 'forward', NULL, '2020-01-07 09:58:28.748810'),
(214, 2019, '2020-01-07', 'Letter', 'General', 'E-II-T-4/19/14', '2020-01-01', 'OFFICE OF THE ENGINEER-IN-CHIEF, PUBLIC HEALTH - ODISHA', 'BHUBANESHWAR', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:00:32-2020-01-07', 'forward', NULL, '2020-01-07 10:00:32.053916'),
(215, 2019, '2020-01-07', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/25/19-20', '2020-01-02', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:02:02-2020-01-07', 'forward', NULL, '2020-01-07 10:02:02.173108'),
(216, 2019, '2020-01-07', 'Bill(Stipend)', 'General', 'NH/LOK/T&HRD/APP/2019/3346', '2019-12-31', 'NHPC LIMITED - LOKTAK', 'MANIPUR', 'Manipur', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:03:56-2020-01-07', 'forward', NULL, '2020-01-07 10:03:56.624705'),
(217, 2019, '2020-01-07', 'Bill(Stipend)', 'General', 'TD-HO-07/2017-97', '2020-01-02', 'ODISHA POWER TRANSMISSION CORPORATION LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:06:08-2020-01-07', 'forward', NULL, '2020-01-07 10:06:08.285293'),
(218, 2019, '2020-01-07', 'Bill(Stipend)', 'General', 'NIL', '2020-01-02', 'UNITED ENGINEERS PVT. LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:07:27-2020-01-07', 'forward', NULL, '2020-01-07 10:07:27.352849'),
(219, 2019, '2020-01-07', 'Bill(Stipend)', 'General', 'CMPDI/RI-VII/FINANCE/1186', '2020-01-02', 'CENTRAL MINE PLANNING & DESIGN INSTITUTE LIMITED - BHUBANESWAR', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:10:13-2020-01-07', 'forward', NULL, '2020-01-07 10:10:13.119403'),
(220, 2019, '2020-01-07', 'Bill(Stipend)', 'General', '092/EDC/DA04/CLAIM/05', '2020-01-01', 'NTPC LIMITED - KAHALGAON', 'PATNA', 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:12:34-2020-01-07', 'forward', NULL, '2020-01-07 10:12:34.010523'),
(221, 2019, '2020-01-07', 'Bill(Stipend)', 'General', 'BL-TV/CCU/BPT', '2020-01-03', 'BALMER LAWRIE & CO. LIMITED', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:14:46-2020-01-07', 'forward', NULL, '2020-01-07 10:14:46.394153'),
(222, 2019, '2020-01-07', 'Letter', 'General', 'NIL', '2019-12-31', 'MR. JAGDISH PRASAD MEENA, NEW DELHI', 'NEW DELHI', 'Delhi', 'ATTENDENCE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:17:29-2020-01-07', 'forward', NULL, '2020-01-07 10:17:29.651562'),
(223, 2019, '2020-01-07', 'Letter', 'General', 'GST/2019-20/134', '2019-12-31', 'ALPHA TELEKOM', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:21:29-2020-01-07', 'forward', NULL, '2020-01-07 10:21:29.489383'),
(224, 2019, '2020-01-07', 'Bill', 'General', '514', '2020-01-01', 'INDIAN EX - SERVICES LEAGUE', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:23:56-2020-01-07', 'forward', NULL, '2020-01-07 10:23:56.287844'),
(225, 2019, '2020-01-07', 'Letter', 'General', 'NIL', '2019-12-25', 'MR. ASHOK SAHA, MURSHIDABAD', 'KOLKATA', 'West Bengal', 'LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:26:57-2020-01-07', 'forward', NULL, '2020-01-07 10:26:57.391282'),
(226, 2019, '2020-01-07', 'Bill', 'General', 'PCS/BOPT/HOSTING/2019/26', '2020-01-02', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:28:59-2020-01-07', 'forward', NULL, '2020-01-07 10:28:59.727333'),
(227, 2019, '2020-01-07', 'Letter', 'General', 'BOAT/WR/MIN/2019/4103', '2019-12-31', 'BOARD OF APPRENTICESHIP TRAINING (WESTERN REGION)', 'MUMBAI', 'Maharashtra', 'LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:31:55-2020-01-07', 'forward', NULL, '2020-01-07 10:31:55.356454'),
(228, 2019, '2020-01-10', 'Letter', 'General', 'ALHW/ACCT/13(57)/2018-19/07', '2020-01-02', 'ANDAMAN LAKSHADWEEP HARBOUR WORKS', 'PORT BLAIR', 'Andaman and Nicobar Islands', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:34:13-2020-01-10', 'forward', NULL, '2020-01-10 07:34:13.922229'),
(229, 2019, '2020-01-10', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1385', '2019-11-05', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:35:25-2020-01-10', 'forward', NULL, '2020-01-10 07:35:25.385347'),
(230, 2019, '2020-01-10', 'Select', 'General', 'CEVT/E-V/9/2019-20/320-22', '2019-12-09', 'OFFICE OF THE CHIEF ENGINEER, VIGILANCE & TRAINING, PWD - ITANAGAR', 'ITANAGAR', 'Jharkhand', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:37:45-2020-01-10', 'forward', NULL, '2020-01-10 07:37:45.589427'),
(231, 2019, '2020-01-10', 'Letter', 'General', 'CEVT/E-V/9/2019-20/329-337', '2019-12-18', 'OFFICE OF THE CHIEF ENGINEER, VIGILANCE & TRAINING, PWD - ITANAGAR', 'ITANAGAR', 'Arunachal Pradesh', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:40:43-2020-01-10', 'forward', NULL, '2020-01-10 07:40:43.658689'),
(232, 2019, '2020-01-10', 'Letter', 'General', '3010', '2019-12-31', 'OFFICE OF THE EXECUTIVE ENGINEER, PADAMPUR INVESTIGATION DIVISION', 'BHUBANESHWAR', 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:42:59-2020-01-10', 'forward', NULL, '2020-01-10 07:42:59.076493'),
(233, 2019, '2020-01-10', 'Letter', 'General', '53260', '2019-12-18', 'OFFICE OF THE ENGINEER-IN-CHIEF (CIVIL), BHUBANESWAR', 'BHUBANESHWAR', 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:45:40-2020-01-10', 'forward', NULL, '2020-01-10 07:45:40.006073'),
(234, 2019, '2020-01-10', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/28/19-20', '2020-01-06', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:47:20-2020-01-10', 'forward', NULL, '2020-01-10 07:47:20.756202'),
(235, 2019, '2020-01-10', 'Bill(Stipend)', 'General', 'CMPDI/2019-20/1319', '2019-12-27', 'CENTRAL MINE PLANNING & DESIGN INSTITUTE LIMITED - ASANSOL', 'ASANSOL', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:49:51-2020-01-10', 'forward', NULL, '2020-01-10 07:49:51.337537'),
(236, 2019, '2020-01-10', 'Bill(Stipend)', 'General', 'PIS/BOPT/03/19-20', '2019-12-31', 'PINNACLE INFOTECH SOLUTIONS - DURGAPUR', 'DURGAPUR', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:51:01-2020-01-10', 'forward', NULL, '2020-01-10 07:51:01.808763'),
(237, 2019, '2020-01-10', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/01/07/03', '2020-01-07', 'SKYPRO TECHNOLOGIES PVT. LTD.', 'BANGALORE', 'Karnataka', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:52:43-2020-01-10', 'forward', NULL, '2020-01-10 07:52:43.277588'),
(238, 2019, '2020-01-10', 'Bill(Stipend)', 'General', 'HRD/708/N10/20', '2020-01-03', 'TRL KROSAKI REFRACTORIES LIMITED', 'BHUBANESHWAR', 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:54:03-2020-01-10', 'forward', NULL, '2020-01-10 07:54:03.522004'),
(239, 2019, '2020-01-10', 'Bill', 'General', 'FT/19-20/513', '2020-01-03', 'FAST TECH TECHNOLOGIES SERVICES PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:55:31-2020-01-10', 'forward', NULL, '2020-01-10 07:55:31.724393'),
(240, 2019, '2020-01-10', 'Bill', 'General', 'FT/19-20/514', '2020-01-10', 'FAST TECH TECHNOLOGIES SERVICES PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:56:52-2020-01-10', 'forward', NULL, '2020-01-10 07:56:52.568643'),
(241, 2019, '2020-01-10', 'Bill', 'General', 'FT/19-20/515', '2020-01-03', 'FAST TECH TECHNOLOGIES SERVICES PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-07:58:16-2020-01-10', 'forward', NULL, '2020-01-10 07:58:16.631336'),
(242, 2019, '2020-01-10', 'Bill', 'General', 'FS-1862/511-UM', '2020-01-09', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-08:00:40-2020-01-10', 'forward', NULL, '2020-01-10 08:00:40.429011'),
(243, 2019, '2020-01-10', 'Bill', 'General', 'FS-547/170-UM', '2020-01-09', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-08:02:01-2020-01-10', 'forward', NULL, '2020-01-10 08:02:01.944827'),
(244, 2019, '2020-01-10', 'Bill', 'General', 'FS-1861/510-UM', '2020-01-09', 'MSK SOLUTIONS', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-08:02:58-2020-01-10', 'forward', NULL, '2020-01-10 08:02:58.413709'),
(245, 2019, '2020-01-15', 'Letter', 'General', 'NIL', '2020-01-14', 'EMAMI LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:46:30-2020-01-15', 'forward', NULL, '2020-01-15 10:46:30.947964'),
(246, 2019, '2020-01-15', 'Bill(Stipend)', 'General', 'SER/P-HQ/CORD/BOPT/RECON', '2019-12-31', 'SOUTH EASTERN RAILWAY', 'KOLKATA', 'West Bengal', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:53:17-2020-01-15', 'forward', NULL, '2020-01-15 10:53:17.967421'),
(247, 2019, '2020-01-15', 'Letter', 'General', 'MIL/HR/34/19-20', '2020-01-07', 'METALDYNE INDUSTRIES LIMITED', 'JAMSHEDPUR', 'Jharkhand', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:55:08-2020-01-15', 'forward', NULL, '2020-01-15 10:55:08.479791'),
(248, 2019, '2020-01-15', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1561', '2019-11-28', 'CENTRAL COALFIELDS LIMITED - BOKARO', 'BOKARO', 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:56:54-2020-01-15', 'forward', NULL, '2020-01-15 10:56:54.636908'),
(249, 2019, '2020-01-15', 'Letter', 'General', 'NIL', '2020-01-14', 'MJUNCTION SERVICES LIMITED', NULL, 'Jharkhand', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-10:59:20-2020-01-15', 'forward', NULL, '2020-01-15 10:59:20.048289'),
(250, 2019, '2020-01-15', 'Letter', 'General', 'CDA/E-6/2019-20/6077-84', '2020-01-12', 'OFFICE OF THE EXECUTIVE ENGINEER, CAPITAL DIVISION-A, ITANAGAR', 'ITANAGAR', 'Arunachal Pradesh', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-11:01:01-2020-01-15', 'forward', NULL, '2020-01-15 11:01:01.736150'),
(251, 2019, '2020-01-15', 'Letter', 'General', 'HRD/HQ/2020-06', '2020-01-07', 'HEAVY ENGINEERING CORPORATION LIMITED - RANCHI', NULL, 'Jharkhand', 'INTERNSHIP PROGRAMME', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-11:04:48-2020-01-15', 'forward', NULL, '2020-01-15 11:04:48.823237'),
(252, 2019, '2020-01-15', 'Letter', 'General', 'GRASIM/CD/GM/2019-20/694', '2020-01-06', 'GRASIM INDUSTRIES LIMITED', NULL, 'Orissa', 'LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-11:06:38-2020-01-15', 'forward', NULL, '2020-01-15 11:06:38.791575'),
(253, 2019, '2020-01-15', 'Letter', 'General', 'NIL', '2020-01-09', 'DEFENCE RESEARCH & DEVELOPMENT ORGANISATION (DRDO)', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-11:08:14-2020-01-15', 'forward', NULL, '2020-01-15 11:08:14.055067'),
(254, 2019, '2020-01-15', 'Letter', 'General', '6724', '2020-01-07', 'AJAY BINAY INSTITUTE OF TECHNOLOGY', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:01:55-2020-01-15', 'forward', NULL, '2020-01-15 12:01:55.461722'),
(255, 2019, '2020-01-15', 'Letter', 'General', 'NIL', '2020-01-09', 'FORTUNE BISCUITS PVT. LTD.', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:03:17-2020-01-15', 'forward', NULL, '2020-01-15 12:03:17.758466'),
(256, 2019, '2020-01-15', 'Letter', 'General', 'IFFCO/PDP/HR/2020', '2020-01-07', 'INDIAN FARMERS FERTILISER COOPERATIVE LTD.', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:06:02-2020-01-15', 'forward', NULL, '2020-01-15 12:06:02.519961'),
(257, 2019, '2020-01-15', 'Letter', 'General', 'NIL', '2020-01-14', 'MR. M. SANJAY REDDY, SAMBALPUR - ODISHA', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-12:07:36-2020-01-15', 'forward', NULL, '2020-01-15 12:07:36.350368'),
(258, 2019, '2020-01-15', 'Letter', 'General', 'AISCO/BOPT/2020-2', '2020-01-08', 'ARYA IRON & STEEL COMPANY PVT. LTD.', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-12:09:05-2020-01-15', 'forward', NULL, '2020-01-15 12:09:05.727519'),
(259, 2019, '2020-01-09', 'Bill(Stipend)', 'General', 'TD-HO-07/2017-699', '2020-01-09', 'ODISHA POWER TRANSMISSION CORPORATION LIMITED', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:17:14-2020-01-16', 'forward', NULL, '2020-01-16 06:17:14.813237'),
(260, 2019, '2020-01-16', 'Bill(Stipend)', 'General', 'STI1915963', '2019-12-05', 'CIPLA LIMITED - SIKKIM', NULL, 'Sikkim', 'CLAIM BILL', NULL, NULL, 'No forwarding letter', 'English', '', 'BOPT/DAK-06:19:05-2020-01-16', 'forward', NULL, '2020-01-16 06:19:05.297868'),
(261, 2019, '2020-01-16', 'Bill(Stipend)', 'General', '18(19)/2018-E-I/5401', '2020-01-05', 'CSIR - INSTT. OF MINERALS & MATERIALS TECHNOLOGY', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:20:25-2020-01-16', 'forward', NULL, '2020-01-16 06:20:25.548055'),
(262, 2019, '2020-01-16', 'Bill(Stipend)', 'General', 'PPL/NLDC/19-20/31', '2019-12-31', 'PARADEEP PHOSPHATES LIMITED', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:24:10-2020-01-16', 'forward', NULL, '2020-01-16 06:24:10.892330'),
(263, 2019, '2020-01-16', 'Bill(Stipend)', 'General', 'NIL', '2020-01-07', 'ITC INFOTECH INDIA LIMITED', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:33:39-2020-01-16', 'forward', NULL, '2020-01-16 06:33:39.346774'),
(264, 2019, '2020-01-16', 'Bill(Stipend)', 'General', 'BR/L&D/NATS/CLAIM/19', '2020-01-04', 'INDIAN OIL CORPORATION LIMITED - BARAUNI', NULL, 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:35:29-2020-01-16', 'forward', NULL, '2020-01-16 06:35:29.800155'),
(265, 2019, '2020-01-16', 'Bill(Stipend)', 'General', 'NIL', '2020-01-13', 'BENNETT, COLEMAN & CO., LTD.', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:36:39-2020-01-16', 'forward', NULL, '2020-01-16 06:36:39.456567'),
(266, 2019, '2020-01-16', 'Bill(Stipend)', 'General', 'NIL', '2020-01-14', 'INLAND POWER LIMITED', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:37:59-2020-01-16', 'forward', NULL, '2020-01-16 06:37:59.581754'),
(267, 2019, '2020-01-16', 'Bill', 'General', 'PCS/BOPT/HOSTING/2019/26', '2020-01-02', 'PCS GLOBAL PRIVATE LIMITED', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:39:56-2020-01-16', 'forward', NULL, '2020-01-16 06:39:56.175773'),
(268, 2019, '2020-01-17', 'Letter', 'General', 'DCE/LD/ESTT/GENL/12/3547', '2019-12-20', 'ANDAMAN LAKSHADWEEP HARBOUR WORKS', NULL, 'Andaman and Nicobar Islands', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:10:00-2020-01-17', 'forward', NULL, '2020-01-17 12:10:00.299206'),
(269, 2019, '2020-01-17', 'Letter', 'General', 'NIL', '2020-01-14', 'EMAMI AGROTECH LIMITED - HALDIA', NULL, 'West Bengal', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:11:17-2020-01-17', 'forward', NULL, '2020-01-17 12:11:17.897678'),
(270, 2019, '2020-01-17', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2019/1850', '2020-01-09', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:12:31-2020-01-17', 'forward', NULL, '2020-01-17 12:12:31.915944'),
(271, 2019, '2020-01-17', 'Letter', 'General', '10', '2020-01-03', 'OFFICE OF THE EXECUTIVE ENGINEER, RURAL WORKS MECHANICAL DIV. - BHUBANESWAR', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:13:47-2020-01-17', 'forward', NULL, '2020-01-17 12:13:47.367292'),
(272, 2019, '2020-01-17', 'Letter', 'General', '23', '2020-01-06', 'THE ENGINEER-IN-CHIEF, P.H - ODISHA', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-12:15:11-2020-01-17', 'forward', NULL, '2020-01-17 12:15:11.101118'),
(273, 2019, '2020-01-17', 'Letter', 'General', '90', '2020-01-07', 'OFFICE OF THE EXECUTIVE ENGINEER, RURAL WORKS DIVISION - RAYAGADA', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-12:16:43-2020-01-17', 'forward', NULL, '2020-01-17 12:16:43.970470'),
(274, 2019, '2020-01-20', 'Letter', 'General', 'NIL', '2020-01-10', 'B & A PACKAGING INDIA LIMITED', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:40:30-2020-01-20', 'forward', NULL, '2020-01-20 05:40:30.040377'),
(275, 2019, '2020-01-20', 'Letter', 'General', 'OCC.S.47/1988/458(WE)', '2020-01-10', 'ODISHA CONSTRUCTION CORPORATION LIMITED', 'BHUBANESHWAR', 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:42:03-2020-01-20', 'forward', NULL, '2020-01-20 05:42:03.080739'),
(276, 2019, '2020-01-20', 'Letter', 'General', '20', '2020-01-02', 'OFFICE OF THE EXECUTIVE ENGINEER, PUBLIC HEALTH DIVISION - ANGUL', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-05:44:23-2020-01-20', 'forward', NULL, '2020-01-20 05:44:23.998861'),
(277, 2019, '2020-01-20', 'Letter', 'General', 'HCE/42/2020', '2020-01-14', 'NALCO LIMITED', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:46:08-2020-01-20', 'forward', NULL, '2020-01-20 05:46:08.303872'),
(278, 2019, '2020-01-20', 'Letter', 'General', 'SPARC/BOPT/2020/480', '2020-01-14', 'SPATIAL PLANNING & ANALYSIS RESEARCH CENTRE PVT. LTD.', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:47:46-2020-01-20', 'forward', NULL, '2020-01-20 05:47:46.874553'),
(279, 2019, '2020-01-20', 'Bill(Stipend)', 'General', 'NIL', '2020-01-14', 'K P AUTOMOBILES PRIVATE LIMITED', NULL, 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:50:19-2020-02-01', 'forward', NULL, '2020-02-01 05:50:19.712572'),
(280, 2019, '2020-01-20', 'Bill(Stipend)', 'General', 'NIL', '2020-01-14', 'BIHAR FOUNDRY & CASTINGS LIMITED', NULL, 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:51:32-2020-02-01', 'forward', NULL, '2020-02-01 05:51:32.560770'),
(281, 2019, '2020-01-20', 'Bill(Stipend)', 'General', '12019/1/2014-NECS', '2020-01-10', 'NORTHEAST CONSULTANCY SERVICES', NULL, 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:55:20-2020-02-01', 'forward', NULL, '2020-02-01 05:55:20.356898'),
(282, 2019, '2020-01-20', 'Bill(Stipend)', 'General', 'NIL', '2020-01-14', 'RIZITEK INDIA PRIVATE LIMITED - RANCHI', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:56:50-2020-02-01', 'forward', NULL, '2020-02-01 05:56:50.194082'),
(283, 2019, '2020-01-20', 'Bill(Stipend)', 'General', 'WEBFIL/P&A/2019-20/57', '2019-12-13', 'WEBFIL LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:01:43-2020-02-01', 'forward', NULL, '2020-02-01 06:01:43.803997'),
(284, 2019, '2020-01-20', 'Bill(Stipend)', 'General', '829/19-20', '2020-01-16', 'HARRY GUEST HOUSE', NULL, 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:04:25-2020-02-01', 'forward', NULL, '2020-02-01 06:04:25.311306'),
(285, 2019, '2020-01-20', 'Bill(Stipend)', 'General', 'BCPL/HR/BOPT/2020/01', '2020-01-14', 'BENGAL CHEMICALS & PHARMACEUTICALS LTD.', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:08:09-2020-02-01', 'forward', NULL, '2020-02-01 06:08:09.710239'),
(286, 2019, '2020-01-20', 'Bill(Stipend)', 'General', 'GR/L&D/TA/2019', '2020-01-06', 'INDIAN OIL CORPORATION LIMITED - GUWAHATI REFINERY', NULL, 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:10:55-2020-02-01', 'forward', NULL, '2020-02-01 06:10:55.356787'),
(287, 2019, '2020-01-20', 'Bill', 'General', 'NIL', '2020-01-14', 'LIFE INSURANCE CORPORATION OF INDIA - KOLKATA', NULL, 'West Bengal', 'MONEY RECEIPT', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:13:26-2020-02-01', 'forward', NULL, '2020-02-01 06:13:26.204478'),
(288, 2019, '2020-01-20', 'Bill', 'General', '2404', '2019-12-31', 'SALT LAKE SERVICE STATION', NULL, 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:14:44-2020-02-01', 'forward', NULL, '2020-02-01 06:14:44.537993'),
(289, 2019, '2020-01-20', 'Bill', 'General', '16', '2020-01-15', 'SHUVAM ENTERPRISE', NULL, 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:18:38-2020-02-01', 'forward', NULL, '2020-02-01 06:18:38.814496'),
(290, 2019, '2020-01-20', 'Bill', 'General', 'NIL', '2020-01-15', 'MR. DEEPAK PAWAR, BOPT EMPLOYEE', NULL, NULL, 'MEDICAL LEAVE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:20:57-2020-02-01', 'forward', NULL, '2020-02-01 06:20:57.616495'),
(291, 2019, '2020-01-21', 'Letter', 'General', 'CA/ER/APP', '2020-01-17', 'BHARAT PETROLIUM CORPORATION LIMITED', NULL, 'West Bengal', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:34:19-2020-01-21', 'forward', NULL, '2020-01-21 10:34:19.585693'),
(292, 2019, '2020-01-21', 'Letter', 'General', 'AAI/BAG/2439-41', '2020-01-13', 'AIRPORTS AUTHORITY OF INDIA - BAGDOGRA', NULL, 'West Bengal', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:36:42-2020-01-21', 'forward', NULL, '2020-01-21 10:36:42.645991'),
(293, 2019, '2020-01-21', 'Letter', 'General', 'G.M.(D)/SO(HRD)GVTC/TRG/PDPT/2020/1879', '2020-01-13', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:48:59-2020-01-21', 'forward', NULL, '2020-01-21 10:48:59.636001'),
(294, 2019, '2020-01-21', 'Letter', 'General', 'NIL', '2014-01-13', 'MRS. MARIA AHMED, PATNA', NULL, NULL, 'PROFICIENCY CERTIFICATE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:50:50-2020-01-21', 'forward', NULL, '2020-01-21 10:50:50.052593'),
(295, 2019, '2020-01-21', 'Letter', 'General', 'HHEP/HRD/ESTT-501 (VOL-I)/180', '2020-01-14', 'ODISHA HYDRO POWER CORPORATION LTD.', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:52:11-2020-01-21', 'forward', NULL, '2020-01-21 10:52:11.334062'),
(296, 2019, '2020-01-21', 'Letter', 'General', 'NIL', '2020-01-15', 'SKY AUTOMOBILES - ODISHA', NULL, NULL, NULL, NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:00:15-2020-01-21', 'forward', NULL, '2020-01-21 11:00:15.111479'),
(297, 2019, '2020-01-21', 'Letter', 'General', '68', '2020-01-04', 'CENTRAL ELECTRICITY SUPPLY UTILITY OF ODISHA', NULL, NULL, NULL, NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:01:53-2020-01-21', 'forward', NULL, '2020-01-21 11:01:53.492185'),
(298, 2019, '2020-01-21', 'Bill(Stipend)', 'General', 'NIL', '2020-01-13', 'NATHCORP PRIVATE LIMITED - RANCHI', NULL, 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:03:36-2020-01-21', 'forward', NULL, '2020-01-21 11:03:36.133138'),
(299, 2019, '2020-01-21', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/01/09/01', '2020-01-09', 'SKYPRO TECHNOLOGIES PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:09:40-2020-01-21', 'forward', NULL, '2020-01-21 11:09:40.136250'),
(300, 2019, '2020-01-21', 'Bill(Stipend)', 'General', '25', '2020-01-13', 'GOVT. WOMEN\'S POLYTECHNIC, - PATNA', NULL, 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:11:17-2020-01-21', 'forward', NULL, '2020-01-21 11:11:17.757912'),
(301, 2019, '2020-01-21', 'Bill(Stipend)', 'General', 'NIL', '2020-01-14', 'J.M.A. STORES PVT. LTD.', NULL, 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:12:44-2020-01-21', 'forward', NULL, '2020-01-21 11:12:44.352934'),
(302, 2019, '2020-01-21', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/29/19-20', '2020-01-15', 'PCS GLOBAL PRIVATE LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:14:22-2020-01-21', 'forward', NULL, '2020-01-21 11:14:22.708640'),
(303, 2019, '2020-01-21', 'Bill(Stipend)', 'General', 'HRDC/MeECL/TRG-43/2019-20/138', '2020-01-09', 'MEGHALAYA ENERGY CORPORATION LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:16:09-2020-01-21', 'forward', NULL, '2020-01-21 11:16:09.799850'),
(304, 2019, '2020-01-21', 'Bill(Stipend)', 'General', 'PPL/NLDC/19-20/34', '2020-01-14', 'PARADEEP PHOSPHATES LIMITED', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:17:31-2020-01-21', 'forward', NULL, '2020-01-21 11:17:31.909612'),
(305, 2019, '2020-01-21', 'Ministry Communication', 'General', 'TRG.9/DHE/CLAIM/2020/920', '2020-01-16', 'INDIAN OIL CORPORATION LIMITED - DIGBOI REFINERY', NULL, 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:19:16-2020-01-21', 'forward', NULL, '2020-01-21 11:19:16.887701'),
(306, 2019, '2020-01-21', 'Letter', 'General', 'A/220/2019/VR/CON', '2020-01-15', 'OFFICE OF THE DISTRICT MAGISTRATE, NORTH 24 PARGANAS - W.B', NULL, NULL, 'VERIFICATION', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:20:35-2020-01-21', 'forward', NULL, '2020-01-21 11:20:35.349251'),
(307, 2019, '2020-01-21', 'Letter', 'General', 'MSK/W/03', '2020-01-20', 'MSK SOLUTIONS', NULL, NULL, 'SERVICE CONTRACT', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:21:53-2020-01-21', 'forward', NULL, '2020-01-21 11:21:53.929809'),
(308, 2019, '2020-01-21', 'Letter', 'General', 'P&AP/AIB-VE/2020/121', '2020-01-09', 'ALL INDIA COUNCIL FOR TECHNICAL EDUCATION', NULL, NULL, 'LETTER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-11:23:25-2020-01-21', 'forward', NULL, '2020-01-21 11:23:25.899144'),
(309, 2019, '2020-01-24', 'Letter', 'General', '17017/1/2015-DSE(MIS)', '2020-01-16', 'DIRECTORATE OF SCHOOL EDUCATION, GOVT. OF MIZORAM', NULL, 'Mizoram', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:53:46-2020-01-24', 'forward', NULL, '2020-01-24 05:53:46.760389'),
(310, 2019, '2020-01-24', 'Letter', 'General', 'AAC/HRM/101/APPT/165', '2020-01-16', 'AIRPORTS AUTHORITY OF INDIA - KOLKATA', 'KOLKATA', 'West Bengal', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:56:09-2020-01-24', 'forward', NULL, '2020-01-24 05:56:09.800581'),
(311, 2019, '2020-01-24', 'Letter', 'General', 'CCL/TRG/PDPT/19-20/1058', '2019-11-18', 'CENTRAL COALFIELDS LIMITED - RANCHI', NULL, 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-05:59:46-2020-01-24', 'forward', NULL, '2020-01-24 05:59:46.873011'),
(312, 2019, '2020-01-24', 'Letter', 'General', 'DD/TRG/2019-20/2893', '2019-12-27', 'PUBLIC WORKS DEPARTMENT - GOVT. OF ARUNACHAL PRADESH', NULL, 'Arunachal Pradesh', 'OFFICE ORDER', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:02:48-2020-01-24', 'forward', NULL, '2020-01-24 06:02:48.398407'),
(313, 2019, '2020-01-24', 'Letter', 'General', 'ST/58-136/2020/5', '2020-01-10', 'BHARAT SANCHAR NIGAM LIMITED - BHUBANESWAR', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:12:45-2020-01-24', 'forward', NULL, '2020-01-24 06:12:45.212584'),
(314, 2019, '2020-01-24', 'Letter', 'General', 'WESCO/HR/ESTT/286', '2020-01-09', 'WESCO UTILITY', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:14:15-2020-01-24', 'forward', NULL, '2020-01-24 06:14:15.780772'),
(315, 2019, '2020-01-24', 'Letter', 'General', '687/OSHB', '2020-01-20', 'ODISHA STATE HOUSING BOARD', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:16:03-2020-01-24', 'forward', NULL, '2020-01-24 06:16:03.392933'),
(316, 2019, '2020-01-24', 'Letter', 'General', 'JES-TRG-MISC-01/2020/1087 WE', '2020-01-10', 'OFFICE OF TE ENGINEER-IN-CHIEF,WATER RESOURCES - ODISHA', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:17:30-2020-01-24', 'forward', NULL, '2020-01-24 06:17:30.983949'),
(317, 2019, '2020-01-24', 'Bill(Stipend)', 'General', 'HRD/TRG/04/1940', '2020-01-20', 'IDCOL FERRO CHROME & ALLOYS LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:22:01-2020-01-24', 'forward', NULL, '2020-01-24 06:22:01.560444'),
(318, 2019, '2020-01-24', 'Ministry Communication', 'General', 'HNG/CLAIM/19-20/4261', '2020-01-20', 'HNG/CLAIM/19-20/4261', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:26:45-2020-01-24', 'forward', NULL, '2020-01-24 06:26:45.466701'),
(319, 2019, '2020-01-24', 'Bill(Stipend)', 'General', 'P&IR/76/2020/3098', '2020-01-17', 'KOLKATA PORT TRUST, HALDIA DOCK COMPLEX', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:28:07-2020-01-24', 'forward', NULL, '2020-01-24 06:28:07.805417'),
(320, 2019, '2020-01-24', 'Bill(Stipend)', 'General', 'TRTC/GHY/BP/T/19-20/10', '2020-01-14', 'TOOL ROOM & TRAINING CENTRE - GUWAHATI', 'GUWAHATI', 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:29:24-2020-01-24', 'forward', NULL, '2020-01-24 06:29:24.113787'),
(321, 2019, '2020-01-24', 'Letter', 'General', 'SPARC/BOPT/2020/481', '2020-01-14', 'SPATIAL PLANNING & ANALYSIS RESEARCH CENTRE PVT. LTD.', NULL, 'Orissa', 'MONEY RECEIPT', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:30:54-2020-01-24', 'forward', NULL, '2020-01-24 06:30:54.923988'),
(322, 2019, '2020-01-24', 'Bill(Stipend)', 'General', 'NIL', '2020-01-17', 'ONPROCESS TECHNOLOGIES INDIA PRIVATE LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:32:13-2020-01-24', 'forward', NULL, '2020-01-24 06:32:13.472485'),
(323, 2019, '2020-01-24', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/31/19-20', '2020-01-20', 'PCS GLOBAL PRIVATE LIMITED', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-06:33:31-2020-01-24', 'forward', NULL, '2020-01-24 06:33:31.447951'),
(324, 2019, '2020-01-24', 'Bill(Stipend)', 'General', 'NIL', '2020-01-20', 'WIPRO LIMITED - BANGALURU', 'BANGALORE', 'Karnataka', 'CLAIM BILL', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:34:53-2020-01-24', 'forward', NULL, '2020-01-24 06:34:53.768665'),
(325, 2019, '2020-01-24', 'Bill', 'General', 'OE/19-20/WB/3072', '2020-01-07', 'ORION EDUTECH PVT. LTD.', 'KOLKATA', 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'English', '', 'BOPT/DAK-06:36:29-2020-01-24', 'forward', NULL, '2020-01-24 06:36:29.283134'),
(326, 2019, '2020-01-28', 'Letter', 'General', 'AAC/HRM/101/APPT/203', '2020-01-23', 'AIRPORTS AUTHORITY OF INDIA - KOLKATA', 'KOLKATA', 'West Bengal', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:25:00-2020-01-28', 'forward', NULL, '2020-01-28 09:25:00.399941'),
(327, 2019, '2020-01-28', 'Letter', 'General', 'NIL', '2020-01-21', 'MR. SANTU PAL, RIFLE FACTORY ISHAPORE', NULL, 'West Bengal', 'PROFICIENCY CERTIFICATE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:26:40-2020-01-28', 'forward', NULL, '2020-01-28 09:26:40.056458'),
(328, 2019, '2020-01-28', 'Letter', 'General', 'CDA/E-6/2019-20/7190-97', '2020-01-21', 'OFFICE OF THE EXECUTIVE ENGINEER, CAPITAL DIVISION-A, ITANAGAR', 'ITANAGAR', 'Arunachal Pradesh', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:28:47-2020-01-28', 'forward', NULL, '2020-01-28 09:28:47.791176'),
(329, 2019, '2020-01-28', 'Letter', 'General', 'G.M(D)/SO(HRD)GVTC/TRG/PDPT/2019/1877', '2020-01-13', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:30:48-2020-01-28', 'forward', NULL, '2020-01-28 09:30:48.072752'),
(330, 2019, '2020-01-28', 'Letter', 'General', 'CESU/ESTT/10-27/1852', '2020-01-22', 'CENTRAL ELECTRICITY SUPPLY UTILITY OF ODISHA', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:33:12-2020-01-28', 'forward', NULL, '2020-01-28 09:33:12.370013'),
(331, 2019, '2020-01-28', 'Letter', 'General', '9-2/2020-TRG/1452', '2020-01-22', 'FARM MECHINERRY TRAINING & TESTING INSTITUTE - ASSAM', NULL, 'Assam', 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:34:43-2020-01-28', 'forward', NULL, '2020-01-28 09:34:43.807757'),
(332, 2019, '2020-01-28', 'Letter', 'General', 'NIL', '2020-01-22', 'EVEREADY INDUSTRIES INDIA LIMITED - ASSAM', NULL, 'Assam', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:35:57-2020-01-28', 'forward', NULL, '2020-01-28 09:35:57.370457'),
(333, 2019, '2020-01-28', 'Letter', 'General', 'E-8(13)/93', '2020-01-18', 'BHARAT SANCHAR NIGAM LIMITED - CUTTACK', NULL, 'Orissa', 'RELIVE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:38:04-2020-01-28', 'forward', NULL, '2020-01-28 09:38:04.073921'),
(334, 2019, '2020-01-28', 'Letter', 'General', 'JMLB/BOPT/2019-20/1411', '2020-01-17', 'THE ASSAM CO-OPERATIVE JUTE MILLS', NULL, 'Assam', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:39:34-2020-01-28', 'forward', NULL, '2020-01-28 09:39:34.777290'),
(335, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'NIL', '2020-01-23', 'IBM INDIA PRIVATE LIMITED - KOLKATA', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:44:48-2020-01-28', 'forward', NULL, '2020-01-28 09:44:48.981261'),
(336, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'HEC/HTI/2020/1155', '2020-01-20', 'HEAVY ENGINEERING CORPORATION LIMITED - RANCHI', NULL, 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:46:14-2020-01-28', 'forward', NULL, '2020-01-28 09:46:14.606491'),
(337, 2019, '2020-01-28', 'Select', 'Select', 'IDTR/JSR/ADMIN/NATS/20/654', '2020-01-21', 'INDO DANISH TOOL ROOM - JAMSHEDPUR', 'RANCHI', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:50:03-2020-01-28', 'forward', NULL, '2020-01-28 09:50:03.825857'),
(338, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'BCP/G-36/20/34145', '2020-01-21', 'BENGAL COLLEGE OF POLYTECHNIC', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:55:25-2020-01-28', 'forward', NULL, '2020-01-28 09:55:25.623595'),
(339, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'AAI/PAT/HR/APPRNTICES/7050-51', '2020-01-22', 'AIRPORTS AUTHORITY OF INDIA - PATNA', 'PATNA', 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:58:04-2020-01-28', 'forward', NULL, '2020-01-28 09:58:04.983402'),
(340, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'NIL', '2020-01-17', 'SHREE JAGANNATH INSTITUTE OF ITC', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:59:56-2020-01-28', 'forward', NULL, '2020-01-28 09:59:56.311825'),
(341, 2019, '2020-01-28', 'Bill(Stipend)', 'Select', 'HRD/TA/RC/105', '2020-01-21', 'STEEL AUTHORITY OF INDIA LIMITED - ROURKELA', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:01:11-2020-01-28', 'forward', NULL, '2020-01-28 10:01:11.593276'),
(342, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'BSBCCL/97/2018/APP/157', '2020-01-21', 'BIHAR STATE BUILDING CONSTRUCTION CORPORATION LIMITED', NULL, 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:03:13-2020-01-28', 'forward', NULL, '2020-01-28 10:03:13.656104'),
(343, 2019, '2020-01-28', 'Bill(Stipend)', 'General', 'TRG/BOPT/02/2019-20/CLAIM-1', '2020-01-24', 'GARDEN REACH SHIPBUILDERS & ENGINEERS LIMITED - KOLKATA', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:08:19-2020-01-28', 'forward', NULL, '2020-01-28 10:08:19.516301'),
(344, 2019, '2020-01-28', 'Bill(Stipend)', 'Select', 'TRG/01/22/2155', '2020-01-18', 'NALCO LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:10:00-2020-01-28', 'forward', NULL, '2020-01-28 10:10:00.500948'),
(345, 2019, '2020-01-28', 'Bill(Stipend)', 'Select', 'LB/AC/SG/AD/449', '2020-01-27', 'L. B. ENGINEERING PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:11:10-2020-01-28', 'forward', NULL, '2020-01-28 10:11:10.126136'),
(346, 2019, '2020-01-28', 'Bill(Stipend)', 'Select', 'NIL', '2020-01-24', 'NCC LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:12:39-2020-01-28', 'forward', NULL, '2020-01-28 10:12:39.282626'),
(347, 2019, '2020-01-28', 'Letter', 'General', 'BT/BM-1/0929-32', '2020-01-21', 'BOARD OF APPRENTICESHIP TRAINING (NORTHERN REGION)', NULL, 'Uttar Pradesh', 'LIST OF HOLIDAYS', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:14:24-2020-01-28', 'forward', NULL, '2020-01-28 10:14:24.907909'),
(348, 2019, '2020-02-03', 'Letter', 'General', 'AAC/HRM/101/APPT/216', '2020-01-24', 'AIRPORTS AUTHORITY OF INDIA - KOLKATA', 'KOLKATA', 'West Bengal', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:07:07-2020-02-03', 'forward', NULL, '2020-02-03 09:07:07.621471'),
(349, 2019, '2020-02-03', 'Letter', 'General', 'NIL', '2020-01-27', 'JAS EQUIPMENT & ENGINEERS PVT. LTD.', NULL, NULL, 'SHOW CAUSE NOTICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:08:48-2020-02-03', 'forward', NULL, '2020-02-03 09:08:48.637370'),
(350, 2019, '2020-02-03', 'Letter', 'General', '33023/5/2016-DTE(RD)/ESTT', '2020-01-07', 'DIRECTORATE OF RURAL DEVELOPMENT, CHANMARI - AIZAWL', NULL, 'Mizoram', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:10:33-2020-02-03', 'forward', NULL, '2020-02-03 09:10:33.528275'),
(351, 2019, '2020-02-03', 'Letter', 'General', 'G.M(D)SO(HRD)GVTC/TRG/PDPT/2020/1918', '2020-01-17', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:11:58-2020-02-03', 'forward', NULL, '2020-02-03 09:11:58.341005'),
(352, 2019, '2020-02-03', 'Letter', 'General', 'G.M(D)SO(HRD)GVTC/TRG/PDPT/2020/1948', '2020-01-21', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, 'Jharkhand', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:26:08-2020-02-03', 'forward', NULL, '2020-02-03 09:26:08.015162'),
(353, 2019, '2020-02-03', 'Letter', 'General', 'BSAL/BOPT/19-20', '2020-01-24', 'BAJRANG STEEL AND ALLOYS LTD.', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:28:20-2020-02-03', 'forward', NULL, '2020-02-03 09:28:20.093643'),
(354, 2019, '2020-02-03', 'Letter', 'General', '201', '2020-01-13', 'OFFICE OF THE EXECUTIVE ENGINEER, JHARSUGUDA (R&B) DIVISION', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:31:17-2020-02-03', 'forward', NULL, '2020-02-03 09:31:17.031618'),
(355, 2019, '2020-02-03', 'Letter', 'General', 'ATE/237/2019/3', '2020-01-08', 'HIGHER EDUCATION (TECHNICAL ) DEPARTMENT - GUWAHATI', NULL, 'Assam', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:33:07-2020-02-03', 'forward', NULL, '2020-02-03 09:33:07.297539'),
(356, 2019, '2020-02-03', 'Letter', 'General', 'GIL/PSD/HRD/2020/9941', '2020-01-22', 'GRAPHITE INDIA LIMITED', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:35:12-2020-02-03', 'forward', NULL, '2020-02-03 09:35:12.172875'),
(357, 2019, '2020-02-03', 'Bill(Stipend)', 'General', 'WESCO/HR/ESTT/609', '2020-01-24', 'WESCO UTILITY', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:39:07-2020-02-03', 'forward', NULL, '2020-02-03 09:39:07.642257'),
(358, 2019, '2020-02-03', 'Bill(Stipend)', 'General', 'SSS/2020/102', '2020-01-11', 'SOFTWARE SERVICES AND SOLUTIONS - PATNA', 'PATNA', 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:41:11-2020-02-03', 'forward', NULL, '2020-02-03 09:41:11.673842'),
(359, 2019, '2020-02-03', 'Bill(Stipend)', 'General', '123', '2020-01-24', 'UTKALMANI GOPABANDHU INSTITUTE OF ENGINEERING - ROURKELA', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:43:53-2020-02-03', 'forward', NULL, '2020-02-03 09:43:53.158652'),
(360, 2019, '2020-02-03', 'Bill(Stipend)', 'General', 'S&P/TRG/043/2019', '2020-01-21', 'NALCO LIMITED', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:45:23-2020-02-03', 'forward', NULL, '2020-02-03 09:45:23.658894'),
(361, 2019, '2020-02-03', 'Bill(Stipend)', 'General', 'BALB/HR/122', '2020-01-21', 'BALASORE ALLOYS LIMITED', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:46:30-2020-02-03', 'forward', NULL, '2020-02-03 09:46:30.330947'),
(362, 2019, '2020-02-03', 'Letter', 'General', 'ERTL-E/ADMN-352-19/990', '2020-01-24', 'ELECTRONICS REGIONAL TEST LABORATORY', 'KOLKATA', 'West Bengal', 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:48:08-2020-02-03', 'forward', NULL, '2020-02-03 09:48:08.581211'),
(363, 2019, '2020-02-03', 'Bill(Stipend)', 'General', 'WEBFIL/P&A/2019-20/57', '2020-01-21', 'WEBFIL LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:49:37-2020-02-03', 'forward', NULL, '2020-02-03 09:49:37.222076'),
(364, 2019, '2020-02-03', 'Letter', 'General', 'NIL', '2020-01-25', 'MR. KASI NATH MONDAL, BOPT EX EMPLOYEE', 'KOLKATA', 'West Bengal', 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:51:18-2020-02-03', 'forward', NULL, '2020-02-03 09:51:18.878598'),
(365, 2019, '2020-02-03', 'Bill', 'General', 'OE/19-20/WB/3072', '2020-01-07', 'ORION EDUTECH PVT. LTD.', NULL, 'West Bengal', 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:52:43-2020-02-03', 'forward', NULL, '2020-02-03 09:52:43.019451');
INSERT INTO `dak_receipt_details` (`id`, `diary_year`, `diary_date`, `receipt_type`, `receipt_category`, `reference_no`, `reference_date`, `sender_name`, `address`, `state`, `subject`, `remarks`, `dealing_head`, `enclosure_details`, `rec_lan`, `other_lan`, `dairy_no`, `doc_status`, `updated_at`, `created_at`) VALUES
(366, 2019, '2020-02-03', 'Letter', 'General', '65-SP', '2020-01-27', 'GOVERNOR\'S SECRETARIAT - WEST BENGAL', NULL, 'West Bengal', 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-09:53:52-2020-02-03', 'forward', NULL, '2020-02-03 09:53:52.113385'),
(367, 2019, '2020-02-05', 'Letter', 'General', 'ACC/HRM/101/APPT/245', '2020-01-28', 'AIRPORTS AUTHORITY OF INDIA - KOLKATA', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:24:12-2020-02-05', 'forward', NULL, '2020-02-05 07:24:12.636919'),
(368, 2019, '2020-02-05', 'Letter', 'General', 'DD/TRG/2019-20/4032-39', '2020-01-20', 'PUBLIC WORKS DEPARTMENT - GOVT. OF ARUNACHAL PRADESH', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:25:51-2020-02-05', 'forward', NULL, '2020-02-05 07:25:51.979680'),
(369, 2019, '2020-02-05', 'Letter', 'General', 'G.M.(D)/SO(HRD)/GVTC/TRG/PDPT/2020/1881', '2020-01-14', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:28:16-2020-02-05', 'forward', NULL, '2020-02-05 07:28:16.529063'),
(370, 2019, '2020-02-05', 'Letter', 'General', 'MCL/GM(BA)/S&T/V.T/19-20/620', '2020-01-24', 'MAHANADI COALFIELDS LIMITED', NULL, 'Orissa', 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:29:30-2020-02-05', 'forward', NULL, '2020-02-05 07:29:30.374347'),
(371, 2019, '2020-02-05', 'Letter', 'General', '770', '2020-01-22', 'OFFICE OF THE CHIEF ENGINEER, NATIONAL HIGHWAYS - BHUBANESHWAR', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:31:04-2020-02-05', 'forward', NULL, '2020-02-05 07:31:04.084783'),
(372, 2019, '2020-02-05', 'Letter', 'General', 'MSK/W/03/1', '2020-01-31', 'MSK SOLUTIONS', NULL, NULL, 'SERVICE CONTRACT', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:32:32-2020-02-05', 'forward', NULL, '2020-02-05 07:32:32.069885'),
(373, 2019, '2020-02-05', 'Letter', 'General', '12/1/2020/ER/28-427', '2020-01-07', 'MINISTRY OF HOME AFFAIRS - DEPT. OF OFFICIAL LANGUAGE', NULL, NULL, 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:34:13-2020-02-05', 'forward', NULL, '2020-02-05 07:34:13.849788'),
(374, 2019, '2020-02-05', 'Letter', 'General', 'NIL', '2020-02-04', 'MR. ANINDYA BHATTACHARYA, BOPT EMPLOYEE', NULL, NULL, 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:35:22-2020-02-05', 'forward', NULL, '2020-02-05 07:35:22.619777'),
(375, 2019, '2020-02-05', 'Letter', 'General', 'NIL', '2020-01-07', 'LIFE INSURANCE CORPORATION OF INDIA - KOLKATA', NULL, NULL, 'MONEY RECEIPT', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:37:08-2020-02-05', 'forward', NULL, '2020-02-05 07:37:08.840938'),
(376, 2019, '2020-02-05', 'Bill', 'General', 'AS/KV/SN/PD/2020/898', '2020-01-13', 'NSDL e-GOVERNANCE INFRASTUCTURE LIMITED', NULL, NULL, 'SERVICE CHARGE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:39:07-2020-02-05', 'forward', NULL, '2020-02-05 07:39:07.170801'),
(377, 2019, '2020-02-05', 'Bill', 'General', '140/2019-20', '2020-02-03', 'VERMA MISHRA & ASSOCIATES', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:40:24-2020-02-05', 'forward', NULL, '2020-02-05 07:40:24.165266'),
(378, 2019, '2020-02-05', 'Letter', 'General', 'NIL', '2020-01-10', 'HDFC ERGO HEALTH INSURANCE LIMITED', NULL, NULL, 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:42:26-2020-02-05', 'forward', NULL, '2020-02-05 07:42:26.597368'),
(379, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'HAL/KPT/KT/4-3/2020/212', '2020-01-31', 'HINDUSTAN AERONAUTICS LIMITED - KORAPUT', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:44:17-2020-02-05', 'forward', NULL, '2020-02-05 07:44:17.009771'),
(380, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/32/19-20', '2020-01-24', 'PCS GLOBAL PRIVATE LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:45:43-2020-02-05', 'forward', NULL, '2020-02-05 07:45:43.733800'),
(381, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'TZP-AIR/3(21)/2018-19/APP/548', '2019-11-27', 'ALL INDIA RADIO - TEZPUR', NULL, 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:47:26-2020-02-05', 'forward', NULL, '2020-02-05 07:47:26.566765'),
(382, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'N-XV/T.R/APP/1807/19/31', '2020-01-28', 'NORTH BIHAR POWER DISTRIBUTION COMPANY LIMITED', NULL, 'Bihar', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:49:28-2020-02-05', 'forward', NULL, '2020-02-05 07:49:28.186818'),
(383, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'AAI/VEPY/APD/APPRN/1923', '2020-01-27', 'AIRPORTS AUTHORITY OF INDIA - PAKYONG', NULL, 'Sikkim', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:50:45-2020-02-05', 'forward', NULL, '2020-02-05 07:50:45.123281'),
(384, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'HCE/APP/18-19/91/2020', '2020-01-28', 'NALCO LIMITED', NULL, 'Orissa', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:52:03-2020-02-05', 'forward', NULL, '2020-02-05 07:52:03.370820'),
(385, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'NIL', '2020-01-31', 'ULTRATECH CEMENT LIMITED - DURGAPUR', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:53:14-2020-02-05', 'forward', NULL, '2020-02-05 07:53:14.234930'),
(386, 2019, '2020-02-05', 'Bill(Stipend)', 'General', 'NIL', '2020-01-28', 'IBM INDIA PRIVATE LIMITED - KOLKATA', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:54:25-2020-02-05', 'forward', NULL, '2020-02-05 07:54:25.265049'),
(387, 2019, '2020-02-07', 'Letter', 'General', 'NIL', '2020-02-05', 'MR. AMIR HUSSAIN, KOLKATA', 'KOLKATA', 'West Bengal', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:30:28-2020-02-07', 'forward', NULL, '2020-02-07 07:30:28.257649'),
(388, 2019, '2020-02-07', 'Letter', 'General', 'NEEPCO/PERS26/T-7/19-20/2107', '2020-01-31', 'NORTH EASTERN ELECTRICAL POWER CORP. LIMITED', NULL, 'Mizoram', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:32:22-2020-02-07', 'forward', NULL, '2020-02-07 07:32:22.052082'),
(389, 2019, '2020-02-07', 'Letter', 'General', 'G.M(D)/SO(HRD)GVTC/TRG/PDPT/2020/1950', '2020-01-21', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:34:12-2020-02-07', 'forward', NULL, '2020-02-07 07:34:12.794343'),
(390, 2019, '2020-02-07', 'Letter', 'General', 'UAL/DKL/5842', '2020-02-03', 'UAL INDUSTRIS LIMITED', NULL, 'Orissa', 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:36:03-2020-02-07', 'forward', NULL, '2020-02-07 07:36:03.348593'),
(391, 2019, '2020-02-07', 'Bill', 'General', 'HCE/APPR/111/2020', '2020-02-03', 'NALCO LIMITED', NULL, NULL, 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:37:36-2020-02-07', 'forward', NULL, '2020-02-07 07:37:36.526861'),
(392, 2019, '2020-02-07', 'Letter', 'General', 'CMPDI/2019-20/1466', '2020-02-01', 'CENTRAL MINE PLANNING & DESIGN INSTITUTE LIMITED - ASANSOL', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:40:13-2020-02-07', 'forward', NULL, '2020-02-07 07:40:13.080711'),
(393, 2019, '2020-02-07', 'Bill(Stipend)', 'General', 'STI2001597', '2020-02-01', 'NALCO LIMITED - ANGUL', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:41:55-2020-02-07', 'forward', NULL, '2020-02-07 07:41:55.462499'),
(394, 2019, '2020-02-07', 'Letter', 'General', 'NIL', '2020-01-28', 'CIPLA LIMITED - SIKKIM', NULL, 'Sikkim', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:43:26-2020-02-07', 'forward', NULL, '2020-02-07 07:43:26.767660'),
(395, 2019, '2020-02-07', 'Bill', 'General', '2019/BOPT/06', '2020-02-03', 'ALPHALINX TECHNOLOGIES LLP. - BANGALORE', NULL, 'Karnataka', 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:46:08-2020-02-07', 'forward', NULL, '2020-02-07 07:46:08.892827'),
(396, 2019, '2020-02-11', 'Letter', 'General', 'GAIGGP/34/T&P/18/2020', '2020-02-03', 'GAIGHATA GOVERNMENT POLYTECHNIC - W.B', NULL, 'West Bengal', 'LETTER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:16:12-2020-02-11', 'forward', NULL, '2020-02-11 10:16:12.045443'),
(397, 2019, '2020-02-11', 'Letter', 'General', 'AAC/HRM/101/APPT/264', '2020-01-31', 'AIRPORTS AUTHORITY OF INDIA - KOLKATA', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:17:41-2020-02-11', 'forward', NULL, '2020-02-11 10:17:41.685510'),
(398, 2019, '2020-02-11', 'Letter', 'General', 'GPT/BANK/19-20/BS', '2020-02-04', 'PULSE POWER TECHNOLOGIES PVT. LTD.', NULL, NULL, 'APPRENTICESHIP TRAINING', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:20:43-2020-02-11', 'forward', NULL, '2020-02-11 10:20:43.938814'),
(399, 2019, '2020-02-11', 'Letter', 'General', 'CEVT/E-V/2019-20/384-91', '2020-01-14', 'OFFICE OF THE CHIEF ENGINEER, VIGILANCE & TRAINING, PWD - ITANAGAR', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:23:53-2020-02-11', 'forward', NULL, '2020-02-11 10:23:53.568533'),
(400, 2019, '2020-02-11', 'Letter', 'General', 'G.M.(D)SO(HRD)/GVTC/TRG/PDPT/2020/1930', '2020-01-18', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:25:11-2020-02-11', 'forward', NULL, '2020-02-11 10:25:11.683949'),
(401, 2019, '2020-02-11', 'Letter', 'General', 'NIL', '2020-02-06', 'MJUNCTION SERVICES LIMITED', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:27:05-2020-02-11', 'forward', NULL, '2020-02-11 10:27:05.497383'),
(402, 2019, '2020-02-11', 'Letter', 'General', 'BCCL/HRD/2019/13644', '2019-12-30', 'BHARAT COKING COAL LIMITED - DHANBAD', NULL, NULL, 'ENGAGEMENT OF TRAINEE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:28:36-2020-02-11', 'forward', NULL, '2020-02-11 10:28:36.127507'),
(403, 2019, '2020-02-11', 'Letter', 'General', '4014', '2020-01-29', 'OFFICE OF THE ENGINEER-IN-CHIEF (CIVIL), BHUBANESWAR', NULL, 'Orissa', NULL, NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:31:00-2020-02-11', 'forward', NULL, '2020-02-11 10:31:00.788686'),
(404, 2019, '2020-02-11', 'Letter', 'General', '25(2)', '2020-01-04', 'S.K.D.A.V GOVERNMENT POLYTECHNIC', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:34:07-2020-02-11', 'forward', NULL, '2020-02-11 10:34:07.971268'),
(405, 2019, '2020-02-11', 'Letter', 'General', '270', '2020-01-27', 'OFFICE OF THE EXECUTIVE ENGINEER,RURAL WORKS DIVISION - SAMBALPUR', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:37:29-2020-02-11', 'forward', NULL, '2020-02-11 10:37:29.389654'),
(406, 2019, '2020-02-11', 'Letter', 'General', 'HAL/KPT/KT/MDP-04/2020/94', '2020-02-04', 'HINDUSTAN AERONAUTICS LIMITED - KORAPUT', NULL, NULL, 'INTERNSHIP PROGRAMME', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:38:56-2020-02-11', 'forward', NULL, '2020-02-11 10:38:56.616585'),
(407, 2019, '2020-02-11', 'Bill', 'General', '2694', '2020-01-31', 'SALT LAKE SERVICE STATION', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:42:10-2020-02-11', 'forward', NULL, '2020-02-11 10:42:10.346537'),
(408, 2019, '2020-02-11', 'Bill', 'General', '528', '2020-02-03', 'INDIAN EX - SERVICES LEAGUE', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:44:09-2020-02-11', 'forward', NULL, '2020-02-11 10:44:09.831292'),
(409, 2019, '2020-02-11', 'Bill', 'General', 'FS-1861/511-UM', '2020-02-07', 'MSK SOLUTIONS', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:45:47-2020-02-11', 'forward', NULL, '2020-02-11 10:45:47.706825'),
(410, 2019, '2020-02-11', 'Bill', 'General', 'FS-1861/512-UM', '2020-02-07', 'MSK SOLUTIONS', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:47:27-2020-02-11', 'forward', NULL, '2020-02-11 10:47:27.955493'),
(411, 2019, '2020-02-11', 'Letter', 'General', 'FS-547/171-UM', '2020-02-07', 'MSK SOLUTIONS', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:48:54-2020-02-11', 'forward', NULL, '2020-02-11 10:48:54.972411'),
(412, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'TRG/01/22/2177', '2020-01-29', 'NALCO LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:52:25-2020-02-11', 'forward', NULL, '2020-02-11 10:52:25.344305'),
(413, 2019, '2020-02-11', 'Bill(Stipend)', 'General', '12019/1/2014-NECS', '2020-02-04', 'NORTHEAST CONSULTANCY SERVICES', NULL, 'Assam', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:54:12-2020-02-11', 'forward', NULL, '2020-02-11 10:54:12.844381'),
(414, 2019, '2020-02-11', 'Letter', 'General', 'TIPL/MAG/T124', '2020-02-05', 'TDK INDIA PRIVATE LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:56:55-2020-02-11', 'forward', NULL, '2020-02-11 10:56:55.912601'),
(415, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'BOPT/CLAIM/36/19-20', '2020-02-07', 'PCS GLOBAL PRIVATE LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-10:58:42-2020-02-11', 'forward', NULL, '2020-02-11 10:58:42.150606'),
(416, 2019, '2020-02-11', 'Bill(Stipend)', 'General', '9-1/2016-TRG-1503', '2020-02-03', 'FARM MECHINERRY TRAINING & TESTING INSTITUTE - ASSAM', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:04:30-2020-02-11', 'forward', NULL, '2020-02-11 11:04:30.018272'),
(417, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'IMFA/HR/20/955', '2020-02-08', 'INDIAN METALS & FERRO ALLOYS LIMITED', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:25:21-2020-02-11', 'forward', NULL, '2020-02-11 11:25:21.694033'),
(418, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'PDR/L&D/BOPT/01', '2020-01-29', 'INDIAN OIL CORPORATION LIMITED - PARADIP REFINERY', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:27:15-2020-02-11', 'forward', NULL, '2020-02-11 11:27:15.616474'),
(419, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'NIL', '2020-02-09', 'SURAT AUTOTECH PVT. LTD.', 'JAMSHEDPUR', 'Jharkhand', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:28:59-2020-02-11', 'forward', NULL, '2020-02-11 11:28:59.062321'),
(420, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'SKYPRO/BOPTER/CLAIM REPORT/02/04/02', '2020-02-04', 'SKYPRO TECHNOLOGIES PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:30:02-2020-02-11', 'forward', NULL, '2020-02-11 11:30:02.416903'),
(421, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'AAI/BDP-17/2729', '2020-01-29', 'AIRPORTS AUTHORITY OF INDIA - BAGDOGRA', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:31:23-2020-02-11', 'forward', NULL, '2020-02-11 11:31:23.042461'),
(422, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'SPARC/2020/HRD/526', '2020-02-06', 'SPATIAL PLANNING & ANALYSIS RESEARCH CENTRE PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:36:09-2020-02-11', 'forward', NULL, '2020-02-11 11:36:09.225639'),
(423, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'PFPL/465/19-20', '2020-02-06', 'PRAVAT FABRICATORS PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:37:23-2020-02-11', 'forward', NULL, '2020-02-11 11:37:23.928862'),
(424, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'S&P/TRG/084/2020', '2020-02-05', 'NALCO LIMITED - ANGUL', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:38:48-2020-02-11', 'forward', NULL, '2020-02-11 11:38:48.969671'),
(425, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'CCL/TRG/CLAIM BILL/19-20/1540', '2020-01-28', 'CENTRAL COALFIELDS LIMITED - RANCHI', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:40:03-2020-02-11', 'forward', NULL, '2020-02-11 11:40:03.938908'),
(426, 2019, '2020-02-11', 'Bill(Stipend)', 'General', 'AIESL/ER-CCU/187', '2020-02-06', 'AIR INDIA ENGINEERING SERVICES - KOLKATA', NULL, 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-11:42:02-2020-02-11', 'forward', NULL, '2020-02-11 11:42:02.871632'),
(427, 2019, '2020-02-13', 'Letter', 'General', 'PER/19-20', '2020-02-12', 'STADMED PRIVATE LIMITED', NULL, NULL, NULL, NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:11:33-2020-02-13', 'forward', NULL, '2020-02-13 07:11:33.863810'),
(428, 2019, '2020-02-13', 'Bill(Stipend)', 'General', 'G.M(D)/SO(HRD)/GVTC/TRG/PDPT/2020/1951', '2020-01-21', 'CENTRAL COALFIELDS LIMITED - BOKARO', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:14:06-2020-02-13', 'forward', NULL, '2020-02-13 07:14:06.670448'),
(429, 2019, '2020-02-13', 'Letter', 'General', '779', '2020-02-05', 'OFFICE OF THE EXECUTIVE ENGINEER, PURI (R&B) DIVISION', NULL, NULL, 'OFFICE ORDER', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:21:16-2020-02-13', 'forward', NULL, '2020-02-13 07:21:16.513749'),
(430, 2019, '2020-02-13', 'Letter', 'General', 'ARSS/HR/2019-20', '2020-02-08', 'ARSS INFRASTUCTURE PROJECTS LIMITED', NULL, NULL, 'SHOW CAUSE NOTICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:23:45-2020-02-13', 'forward', NULL, '2020-02-13 07:23:45.221155'),
(431, 2019, '2020-02-13', 'Bill(Stipend)', 'General', '092/EDC/DA04/CLAIM/06', '2020-02-08', 'NTPC LIMITED - KAHALGAON', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:26:23-2020-02-13', 'forward', NULL, '2020-02-13 07:26:23.159084'),
(432, 2019, '2020-02-13', 'Bill(Stipend)', 'General', 'CCL/TRG/CLAIM BILL/19-20/1539', '2020-01-28', 'CENTRAL COALFIELDS LIMITED - RANCHI', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:30:36-2020-02-13', 'forward', NULL, '2020-02-13 07:30:36.900428'),
(433, 2019, '2020-02-13', 'Bill(Stipend)', 'General', 'TTC/2(2)/2015', '2020-02-08', 'GARDEN REACH SHIPBUILDERS & ENGINEERS LIMITED - KOLKATA', 'KOLKATA', 'West Bengal', 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:32:37-2020-02-13', 'forward', NULL, '2020-02-13 07:32:37.744261'),
(434, 2019, '2020-02-13', 'Letter', 'General', '17017/2/2020-DTE(TECH)', '2020-01-28', 'DIRECTORATE OF RURAL DEVELOPMENT, CHANMARI - AIZAWL', NULL, NULL, 'MONEY RECEIPT', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:39:17-2020-02-13', 'forward', NULL, '2020-02-13 07:39:17.373853'),
(435, 2019, '2020-02-13', 'Bill(Stipend)', 'General', 'NIL', '2020-02-07', 'EREVMAX TECHNOLOGIES PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:49:12-2020-02-13', 'forward', NULL, '2020-02-13 07:49:12.750510'),
(436, 2019, '2020-02-13', 'Bill(Stipend)', 'General', 'LB/AC/SG/AD/451', '2020-02-12', 'L. B. ENGINEERING PVT. LTD.', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:50:47-2020-02-13', 'forward', NULL, '2020-02-13 07:50:47.160848'),
(437, 2019, '2020-02-13', 'Bill', 'General', 'BL-TV/CCU/BPT', '2020-02-10', 'BALMER LAWRIE & CO. LIMITED', NULL, NULL, 'TAX INVOICE', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:52:51-2020-02-13', 'receipt', NULL, '2020-02-13 07:52:51.017850'),
(438, 2019, '2020-02-13', 'Bill', 'General', 'NIL', '2020-02-10', 'MR. RAKESH KR. SHAW, OS - BOPT', NULL, NULL, 'CLAIM BILL', NULL, NULL, NULL, 'Select', '', 'BOPT/DAK-07:56:09-2020-02-13', 'forward', NULL, '2020-02-13 07:56:09.533072');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_code` varchar(50) DEFAULT NULL,
  `department_name` varchar(50) DEFAULT NULL,
  `department_status` varchar(255) DEFAULT 'active',
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_code`, `department_name`, `department_status`, `updated_at`, `created_at`) VALUES
(2, NULL, 'ACCOUNTS (ESTABLISHMENT)', 'active', '2019-06-27 00:46:16.000000', '2019-06-27 00:46:16.000000'),
(3, NULL, 'ACCOUNTS (STIPEND)', 'active', '2019-06-27 00:46:24.000000', '2019-06-27 00:46:24.000000'),
(6, NULL, 'ADMINISTRATION', 'active', '2019-06-27 00:46:44.000000', '2019-06-27 00:46:44.000000'),
(7, NULL, 'TRAINING', 'active', '2019-06-27 00:46:51.000000', '2019-06-27 00:46:51.000000'),
(19, NULL, 'DIRECTOR SECRETARIAT', 'active', '2019-08-13 00:58:35.000000', '2019-08-13 00:58:35.000000'),
(20, NULL, 'COMPUTER SECTION', 'active', '2019-08-13 06:42:16.000000', '2019-08-13 06:42:16.000000');

-- --------------------------------------------------------

--
-- Table structure for table `depreciation_master`
--

CREATE TABLE `depreciation_master` (
  `id` int(11) NOT NULL,
  `assets_code` varchar(20) DEFAULT NULL,
  `gross_addition` varchar(20) DEFAULT NULL,
  `gross_deduction` varchar(20) DEFAULT NULL,
  `gross_closingbalance` varchar(20) DEFAULT NULL,
  `depreciation` varchar(20) DEFAULT NULL,
  `depreciation_deduction` varchar(20) DEFAULT NULL,
  `netclosing_balance` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `depreciation_master`
--

INSERT INTO `depreciation_master` (`id`, `assets_code`, `gross_addition`, `gross_deduction`, `gross_closingbalance`, `depreciation`, `depreciation_deduction`, `netclosing_balance`, `created_at`) VALUES
(1, '04/001', '0', '490', '-490', '230', '20', '-740', '2019-12-30 04:58:25'),
(2, '0', '2500', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:25'),
(3, '04/003', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:25'),
(4, '04/004', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:25'),
(5, '04/005', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:25'),
(6, '04/006', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:26'),
(7, '04/007', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:26'),
(8, '04/008', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:26'),
(9, '0', '2500', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:26'),
(10, '04/010', '0', NULL, NULL, '0', '0', NULL, '2019-12-30 04:58:26'),
(11, '04/001', '0', '20', '-20', '0', '0', '-20', '2020-01-03 08:30:56'),
(12, '0', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(13, '04/003', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(14, '04/004', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(15, '04/005', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(16, '04/006', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(17, '04/007', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(18, '04/008', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(19, '0', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(20, '04/010', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(21, '04/011', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(22, '04/012', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(23, '04/013', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(24, '04/014', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(25, '04/015', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(26, '04/016', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(27, '04/017', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(28, '04/018', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(29, '0', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56'),
(30, '0', '0', NULL, NULL, '0', '0', NULL, '2020-01-03 08:30:56');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `id` int(11) NOT NULL,
  `department_code` varchar(255) NOT NULL,
  `designation_code` varchar(255) DEFAULT NULL,
  `designation_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `designation_status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `department_code`, `designation_code`, `designation_name`, `created_at`, `updated_at`, `designation_status`) VALUES
(1, '9', NULL, 'DIRECTOR', '2019-06-27 02:15:33', '2019-06-27 02:15:33', 'active'),
(4, '2', NULL, 'MULTI TASKING STAFF', '2019-06-27 02:19:31', '2019-06-27 02:19:31', 'active'),
(5, '2', NULL, 'UPPER DIVISION CLERK', '2019-06-27 02:20:36', '2019-06-27 02:20:36', 'active'),
(6, '2', NULL, 'AAO', '2019-06-27 02:21:09', '2019-06-27 02:21:09', 'active'),
(7, '2', NULL, 'ASSISTANT DIRECTOR -I', '2019-10-29 12:14:49', '2019-10-29 06:44:49', 'active'),
(8, '2', NULL, 'GENERAL ASSISTANT', '2019-06-27 02:22:46', '2019-06-27 02:22:46', 'active'),
(9, '2', NULL, 'JUNIOR ACCOUNTANT', '2019-06-27 02:23:38', '2019-06-27 02:23:38', 'active'),
(12, '2', NULL, 'STENO GRADE III', '2019-06-27 02:28:33', '2019-06-27 02:28:33', 'active'),
(13, '6', NULL, 'UDC', '2019-06-27 02:29:24', '2019-06-27 02:29:24', 'active'),
(14, '6', NULL, 'ANALYST', '2019-06-27 02:29:55', '2019-06-27 02:29:55', 'active'),
(15, '6', NULL, 'LOWER DIVISION CLERK', '2019-06-27 03:49:48', '2019-06-27 03:49:48', 'active'),
(18, '7', NULL, 'SKILL DEVELOPMENT OFFICER', '2019-07-04 00:48:25', '2019-07-04 00:48:25', 'active'),
(19, '13', NULL, 'DEPUTY DIRECTOR', '2019-07-09 01:31:00', '2019-07-09 01:31:00', 'active'),
(20, '14', NULL, 'ADMIN CUM ACCOUNTS OFFICER', '2019-07-09 01:31:15', '2019-07-09 01:31:15', 'active'),
(21, '14', NULL, 'PA TO DIRECTOR', '2019-07-09 01:33:42', '2019-07-09 01:33:42', 'active'),
(22, '4', NULL, 'STENO GR-III', '2019-07-09 01:35:02', '2019-07-09 01:35:02', 'active'),
(23, '6', NULL, 'OFFICE SUPERINTENDENT', '2019-07-16 05:54:14', '2019-07-16 05:54:14', 'active'),
(25, '6', NULL, 'DEO', '2019-08-19 06:00:21', '2019-08-14 05:22:20', 'active'),
(26, '11', NULL, 'STENO GRADE II', '2019-09-23 05:26:05', '2019-09-23 05:26:05', 'active'),
(27, '13', NULL, 'HINDI ASSISTANT', '2019-09-23 05:26:37', '2019-09-23 05:26:37', 'active'),
(28, '11', NULL, 'STENO GRADE I', '2019-09-23 05:30:24', '2019-09-23 05:30:24', 'active'),
(29, '13', NULL, 'JUNIOR TRANSLATOR', '2019-09-23 05:33:31', '2019-09-23 05:33:31', 'active'),
(30, '7', NULL, 'ASSISTANT DIRECTOR-II', '2019-10-29 06:45:03', '2019-10-29 06:45:03', 'active'),
(31, '7', NULL, 'ASSISTANT DIRECTOR-III', '2019-10-29 06:45:18', '2019-10-29 06:45:18', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `district_master`
--

CREATE TABLE `district_master` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district_master`
--

INSERT INTO `district_master` (`id`, `name`, `state_id`, `created_at`, `updated_at`) VALUES
(1, 'Kolkata', 19, '2019-08-16 10:46:10', '2019-08-16 10:46:10'),
(2, 'Paschim Bardhaman', 19, '2019-08-16 10:46:29', '2019-08-16 10:46:29'),
(3, 'Jalpaiguri', 19, '2019-08-16 10:46:44', '2019-08-16 10:46:44'),
(4, 'Howrah', 19, '2019-08-16 10:46:58', '2019-08-16 10:46:58'),
(5, 'North 24 Pargana', 19, '2019-08-16 10:47:54', '2019-08-16 10:47:54'),
(6, 'South 24 Pargana', 19, '2019-08-16 10:49:00', '2019-08-16 10:49:00'),
(7, 'Paschim Medinipur', 19, '2019-08-16 10:49:22', '2019-08-16 10:49:22'),
(8, 'Purba Medinipur', 19, '2019-08-16 10:49:33', '2019-08-16 10:49:33'),
(9, 'Birbhum', 19, '2019-08-16 10:50:08', '2019-08-16 10:50:08'),
(10, 'Jhargram', 19, '2019-08-16 10:51:28', '2019-08-16 10:51:28'),
(11, 'Purulia', 19, '2019-08-16 10:52:00', '2019-08-16 10:52:00'),
(12, 'Nadia', 19, '2019-08-16 10:52:32', '2019-08-16 10:52:32'),
(13, 'Bankura', 19, '2019-08-16 10:53:46', '2019-08-16 10:53:46'),
(14, 'Alipurduar', 19, '2019-08-16 10:54:14', '2019-08-16 10:54:14'),
(15, 'Darjeeling', 19, '2019-08-16 10:54:53', '2019-08-16 10:54:53'),
(16, 'Kalimpong', 19, '2019-08-16 10:55:17', '2019-08-16 10:55:17'),
(17, 'Cooch Behar', 19, '2019-08-16 10:55:54', '2019-08-16 10:55:54'),
(18, 'Hooghly', 19, '2019-08-16 10:56:29', '2019-08-16 10:56:29'),
(19, 'Purba Bardhaman', 19, '2019-08-16 11:00:02', '2019-08-16 11:00:02'),
(20, 'Uttar Dinajpur', 19, '2019-08-16 11:00:38', '2019-08-16 11:00:38'),
(21, 'Dakshin Dinajpur', 19, '2019-08-16 11:00:56', '2019-08-16 11:00:56'),
(22, 'Murshidabad', 19, '2019-08-16 11:01:19', '2019-08-16 11:01:19'),
(23, 'Malda', 19, '2019-08-16 11:04:50', '2019-08-16 11:04:50');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
